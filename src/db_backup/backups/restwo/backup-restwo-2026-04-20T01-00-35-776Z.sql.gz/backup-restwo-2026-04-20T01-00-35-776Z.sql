--
-- PostgreSQL database dump
--

\restrict ATxPS2Neispih5iHhgmCw5QguCfVmyuWoWQ2HtrpIA4xg0o1CxBwMxmdgzGqh6i

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: item_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.item_type_enum AS ENUM (
    'PRODUCT',
    'CUSTOM'
);


--
-- Name: payroll_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payroll_status AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED'
);


--
-- Name: payroll_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payroll_type AS ENUM (
    'MONTHLY',
    'DAILY'
);


--
-- Name: status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.status_enum AS ENUM (
    'enabled',
    'disabled',
    'inactive',
    'active'
);


--
-- Name: set_dispatched_date(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_dispatched_date() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.order_status = 'dispatched' AND OLD.order_status IS DISTINCT FROM 'dispatched' THEN
    NEW.dispatched_date := NOW();
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: set_status_timestamps(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_status_timestamps() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.order_status = 'confirmed' AND OLD.order_status IS DISTINCT FROM 'confirmed' THEN
    NEW.confirmed_date := NOW();
  END IF;

  IF NEW.order_status = 'processing' AND OLD.order_status IS DISTINCT FROM 'processing' THEN
    NEW.processing_date := NOW();
  END IF;

  IF NEW.order_status = 'dispatched' AND OLD.order_status IS DISTINCT FROM 'dispatched' THEN
    NEW.dispatched_date := NOW();
  END IF;

  IF NEW.order_status = 'cancelled' AND OLD.order_status IS DISTINCT FROM 'cancelled' THEN
    NEW.cancelled_date := NOW();
  END IF;

  IF NEW.order_status = 'returned' AND OLD.order_status IS DISTINCT FROM 'returned' THEN
    NEW.returned_date := NOW();
  END IF;

  IF NEW.order_status = 'completed' AND OLD.order_status IS DISTINCT FROM 'completed' THEN
    NEW.delivery_completed_date := NOW();
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: update_accounts_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_accounts_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: update_admin_role_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_admin_role_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN

    NEW.updated_at = NOW();

    RETURN NEW;

END;

$$;


--
-- Name: update_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   NEW.updated_at = CURRENT_TIMESTAMP;
   RETURN NEW;
END;
$$;


--
-- Name: update_timestamp_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_timestamp_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN

    NEW.updated_at = NOW();

    RETURN NEW;

END;

$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN

    NEW.updated_at = NOW();

    RETURN NEW;

END;

$$;


--
-- Name: ingredients_stock_header_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ingredients_stock_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ingredients_stock_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredients_stock_header (
    id integer DEFAULT nextval('public.ingredients_stock_header_id_seq'::regclass) NOT NULL,
    user_id integer,
    stock_type text,
    remark text,
    created_at timestamp with time zone,
    outlet_id integer
);


--
-- Name: Ingredients_stock_header_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Ingredients_stock_header_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Ingredients_stock_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Ingredients_stock_header_id_seq" OWNED BY public.ingredients_stock_header.id;


--
-- Name: account_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_categories (
    category_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    note text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by bigint NOT NULL,
    is_default boolean DEFAULT false,
    CONSTRAINT account_categories_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: account_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_categories_category_id_seq OWNED BY public.account_categories.category_id;


--
-- Name: account_statement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_statement (
    acc_statement_id integer NOT NULL,
    account_id integer NOT NULL,
    transaction_type character varying(10) NOT NULL,
    amount numeric(12,2) NOT NULL,
    reference text,
    by integer NOT NULL,
    prev_balance numeric(12,2) DEFAULT 0.00,
    balance numeric(12,2) DEFAULT 0.00,
    status character varying(10) DEFAULT 'Active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    payer_payee integer,
    CONSTRAINT account_statement_transaction_type_check CHECK (((transaction_type)::text = ANY (ARRAY[('debit'::character varying)::text, ('credit'::character varying)::text])))
);


--
-- Name: account_statement_acc_statement_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_statement_acc_statement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_statement_acc_statement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_statement_acc_statement_id_seq OWNED BY public.account_statement.acc_statement_id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    by integer,
    name text,
    type text,
    p_method_id integer,
    description text,
    status text,
    balance numeric,
    outlet_id integer,
    bank_account boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_default boolean DEFAULT false
);


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: accounts_payer_payee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts_payer_payee (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    type character varying(50) NOT NULL,
    add_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_default boolean DEFAULT false,
    CONSTRAINT accounts_payer_payee_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text]))),
    CONSTRAINT accounts_payer_payee_type_check CHECK (((type)::text = ANY (ARRAY[('payer'::character varying)::text, ('payee'::character varying)::text])))
);


--
-- Name: accounts_payer_payee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_payer_payee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_payer_payee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_payer_payee_id_seq OWNED BY public.accounts_payer_payee.id;


--
-- Name: admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_log (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT timezone('Asia/Colombo'::text, now()) NOT NULL,
    module text NOT NULL,
    log text NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_log_id_seq OWNED BY public.admin_log.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id integer DEFAULT nextval('public.users_user_id_seq'::regclass) NOT NULL,
    first_name text,
    last_name text,
    username text NOT NULL,
    password text NOT NULL,
    mobile text,
    role_id integer,
    status character varying(50) DEFAULT 'Active'::character varying,
    email text,
    branch_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    merchant_id integer,
    outlet_id integer,
    picture text,
    otp character varying(6),
    otp_expires_at timestamp without time zone
);


--
-- Name: admin_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_user_id_seq OWNED BY public.users.user_id;


--
-- Name: appreciations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appreciations (
    appreciation_id integer NOT NULL,
    employee_id integer NOT NULL,
    subject text NOT NULL,
    description text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: appreciations_appreciation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.appreciations_appreciation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: appreciations_appreciation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.appreciations_appreciation_id_seq OWNED BY public.appreciations.appreciation_id;


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance (
    attendance_id integer NOT NULL,
    employee_id integer NOT NULL,
    name character varying(150) NOT NULL,
    check_in_date date NOT NULL,
    clock_in_time time without time zone NOT NULL,
    clock_out_time time without time zone NOT NULL,
    log_source character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    shift_id integer NOT NULL,
    roster_id integer,
    attendance_status_id integer,
    attendance_note text,
    check_out_date date,
    CONSTRAINT chk_log_source CHECK (((log_source)::text = ANY (ARRAY[('BIOMETRIC'::character varying)::text, ('HR_DASHBOARD'::character varying)::text])))
);


--
-- Name: attendance_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_attendance_id_seq OWNED BY public.attendance.attendance_id;


--
-- Name: attendance_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_status (
    status_id integer NOT NULL,
    holiday_id integer,
    day_off boolean DEFAULT false,
    present boolean DEFAULT false,
    halfday boolean DEFAULT false,
    late boolean DEFAULT false,
    absent boolean DEFAULT false,
    leave_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    holiday_name character varying(200)
);


--
-- Name: attendance_status_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_status_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_status_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_status_status_id_seq OWNED BY public.attendance_status.status_id;


--
-- Name: batch_management; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_management (
    batch_management_id integer NOT NULL,
    product_id integer NOT NULL,
    variant_id integer NOT NULL,
    batch_number character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    cost_price numeric(12,2) DEFAULT 0.00,
    selling_price numeric(12,2) DEFAULT 0.00,
    expiry_date date,
    manufacture_date date,
    supplier_id integer,
    status character varying(20) DEFAULT 'active'::character varying,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer
);


--
-- Name: batch_management_batch_management_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batch_management_batch_management_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_management_batch_management_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batch_management_batch_management_id_seq OWNED BY public.batch_management.batch_management_id;


--
-- Name: branch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branch (
    branch_id integer NOT NULL,
    branch_name character varying(100) NOT NULL
);


--
-- Name: branch_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branch_branch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branch_branch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branch_branch_id_seq OWNED BY public.branch.branch_id;


--
-- Name: brand; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brand (
    brand_id integer NOT NULL,
    name character varying(100) NOT NULL,
    logo_url character varying(255),
    logo_tile_url character varying(255),
    brand_tagline character varying(255),
    status character varying(20),
    description text,
    website_url character varying(255),
    seo_title character varying(100),
    seo_meta_desc character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT brand_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: brand_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.brand_brand_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: brand_brand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.brand_brand_id_seq OWNED BY public.brand.brand_id;


--
-- Name: branding_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_settings (
    id integer NOT NULL,
    company_name character varying(255) NOT NULL,
    logo_url text,
    favicon_url text,
    app_icon_android text,
    app_icon_ios text,
    slogan character varying(255),
    primary_color character varying(10) DEFAULT '#000000'::character varying,
    secondary_color character varying(10) DEFAULT '#FFFFFF'::character varying,
    title_color character varying(10) DEFAULT '#333333'::character varying,
    subtitle_color character varying(10) DEFAULT '#666666'::character varying,
    text_color character varying(10) DEFAULT '#000000'::character varying,
    button_primary_color character varying(10) DEFAULT '#007bff'::character varying,
    button_secondary_color character varying(10) DEFAULT '#6c757d'::character varying,
    button_success_color character varying(10) DEFAULT '#28a745'::character varying,
    button_warning_color character varying(10) DEFAULT '#ffc107'::character varying,
    button_danger_color character varying(10) DEFAULT '#dc3545'::character varying,
    font_family character varying(100) DEFAULT 'Arial, sans-serif'::character varying,
    font_size character varying(10) DEFAULT '14px'::character varying,
    background_color character varying(10) DEFAULT '#FFFFFF'::character varying,
    border_radius character varying(10) DEFAULT '5px'::character varying,
    box_shadow character varying(50) DEFAULT '0px 4px 6px rgba(0,0,0,0.1)'::character varying,
    hotline character varying(20) NOT NULL,
    customer_support_phone character varying(20),
    address_1 text,
    website_url text,
    facebook_url text,
    twitter_url text,
    instagram_url text,
    linkedin_url text,
    youtube_url text,
    support_email character varying(255),
    info_email character varying(255),
    billing_email character varying(255),
    terms_url text,
    privacy_url text,
    copyright_text character varying(255) DEFAULT '© 2025 Your Company. All Rights Reserved.'::character varying,
    seo_meta_title character varying(255),
    seo_meta_description text,
    seo_meta_keywords text,
    footer_text character varying(255) DEFAULT 'Powered by Spark Global Solutions'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    logo_url_white text,
    logo_name_dark text,
    logo_name_white text,
    address_2 text,
    client_portal_url text,
    admin_portal_url text,
    api_url text,
    geocode character varying(255),
    google_clientid text,
    copyright_link text,
    white_label boolean DEFAULT false,
    hover_color character varying(10) DEFAULT '#CCCCCC'::character varying,
    tiktok_url text,
    welcome_image text,
    footer_color text,
    seo_image text
);


--
-- Name: branding_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branding_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branding_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branding_settings_id_seq OWNED BY public.branding_settings.id;


--
-- Name: bulk_dispatched_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bulk_dispatched_history (
    bulk_id integer NOT NULL,
    generated_by integer,
    generated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    order_count integer DEFAULT 0 NOT NULL,
    partner_id integer NOT NULL
);


--
-- Name: bulk_dispatched_history_bulk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bulk_dispatched_history_bulk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bulk_dispatched_history_bulk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bulk_dispatched_history_bulk_id_seq OWNED BY public.bulk_dispatched_history.bulk_id;


--
-- Name: card_terminal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_terminal (
    id integer NOT NULL,
    mac_address text,
    ip text,
    name text,
    account_name text,
    account_id integer,
    status text,
    outlet_id integer
);


--
-- Name: card_terminal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_terminal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_terminal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_terminal_id_seq OWNED BY public.card_terminal.id;


--
-- Name: card_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_types (
    id integer NOT NULL,
    name text,
    status text
);


--
-- Name: card_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_types_id_seq OWNED BY public.card_types.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    category_id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    category_under double precision,
    related_ui integer,
    mobile_url text,
    desktop_url text,
    show_on_main_menu boolean DEFAULT false,
    status character varying(20) DEFAULT 'active'::character varying,
    merchant_id integer,
    CONSTRAINT categories_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_category_id_seq OWNED BY public.categories.category_id;


--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer (
    customer_id integer DEFAULT nextval('public.customer_customer_id_seq'::regclass) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    contact_number_1 character varying(20),
    contact_number_2 character varying(20),
    address text,
    city character varying(100),
    postal_code character varying(20),
    country character varying(100),
    email character varying(150),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    password text,
    status text DEFAULT 'active'::text,
    apartment text,
    guest boolean DEFAULT false,
    picture text,
    company_name character varying(255),
    otp text,
    expire_at timestamp without time zone,
    loyalty_point numeric(10,2) DEFAULT 0,
    birthday date,
    loyality_number numeric
);


--
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_client_id_seq OWNED BY public.customer.customer_id;


--
-- Name: collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections (
    collection_id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying,
    merchant_id integer,
    product_id integer[],
    mobile_url text,
    desktop_url text,
    CONSTRAINT collections_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: collections_collection_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.collections_collection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: collections_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.collections_collection_id_seq OWNED BY public.collections.collection_id;


--
-- Name: components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.components (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    json_schema jsonb NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: components_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.components_id_seq OWNED BY public.components.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    country_code character varying(2) NOT NULL,
    country_name character varying(128) NOT NULL,
    status text DEFAULT 'active'::text
);


--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: credit_card_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_card_transaction (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT now(),
    terminal_id integer,
    amount numeric,
    comment text,
    reference text,
    card_type integer,
    invoice_id integer
);


--
-- Name: credit_card_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_card_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_card_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_card_transaction_id_seq OWNED BY public.credit_card_transaction.id;


--
-- Name: dashboard_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_widgets (
    widget_id integer NOT NULL,
    name character varying(100) NOT NULL,
    show boolean DEFAULT true,
    package boolean DEFAULT true
);


--
-- Name: dashboard_widgets_widget_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dashboard_widgets_widget_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dashboard_widgets_widget_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dashboard_widgets_widget_id_seq OWNED BY public.dashboard_widgets.widget_id;


--
-- Name: delivery_fee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_fee (
    id integer NOT NULL,
    country_id integer,
    fee numeric,
    additional_fee numeric,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL
);


--
-- Name: delivery_fee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delivery_fee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delivery_fee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delivery_fee_id_seq OWNED BY public.delivery_fee.id;


--
-- Name: delivery_partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_partners (
    partner_id integer NOT NULL,
    name character varying(100) NOT NULL,
    logo character varying(255),
    contact_number character varying(100),
    email character varying(150),
    address text,
    status character varying(20),
    tracking_url character varying(255),
    tracking_para character varying(255),
    tracking_api_endpoint character varying(255),
    tracking_array jsonb,
    unuse_waybiils text[],
    last_use_waybill character varying(100),
    type character varying(50),
    react text,
    reply text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    title character varying(255),
    description text,
    api_key character varying(255),
    customer_id integer,
    api_status character varying(10) DEFAULT 'enable'::character varying NOT NULL,
    two_way_status text,
    two_way_url text,
    CONSTRAINT delivery_partners_api_status_check CHECK (((api_status)::text = ANY (ARRAY[('enable'::character varying)::text, ('disable'::character varying)::text]))),
    CONSTRAINT delivery_partners_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text]))),
    CONSTRAINT delivery_partners_type_check CHECK (((type)::text = ANY (ARRAY[('Bulk'::character varying)::text, ('API'::character varying)::text])))
);


--
-- Name: delivery_partners_partner_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delivery_partners_partner_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delivery_partners_partner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delivery_partners_partner_id_seq OWNED BY public.delivery_partners.partner_id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    department_id integer NOT NULL,
    department_name character varying(150) NOT NULL,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: departments_department_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.departments ALTER COLUMN department_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.departments_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: designations_designation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.designations_designation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: designations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.designations (
    designation_id integer DEFAULT nextval('public.designations_designation_id_seq'::regclass) NOT NULL,
    designation_name character varying(100) NOT NULL,
    department_name character varying(100),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    sick_leave integer DEFAULT 0,
    casual_leave integer DEFAULT 0,
    annual_leave integer DEFAULT 0,
    maternity_leave integer DEFAULT 0,
    paternity_leave integer DEFAULT 0,
    CONSTRAINT designations_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: designations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.designations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: designations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.designations_id_seq OWNED BY public.designations.designation_id;


--
-- Name: device_management_device_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_management_device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_management; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_management (
    device_id bigint DEFAULT nextval('public.device_management_device_id_seq'::regclass) NOT NULL,
    till_name character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    current_user_id bigint,
    display_id jsonb,
    device_model character varying(100),
    type character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    banner_files jsonb,
    enable_customer_input boolean DEFAULT true,
    CONSTRAINT device_management_status_check CHECK (((status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Inactive'::character varying)::text])))
);


--
-- Name: device_management_till_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_management_till_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_management_till_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_management_till_id_seq OWNED BY public.device_management.device_id;


--
-- Name: discount_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discount_usage (
    id integer NOT NULL,
    discount_id integer,
    order_id integer,
    user_id integer,
    used_at timestamp without time zone DEFAULT now(),
    is_guest boolean DEFAULT false,
    type text
);


--
-- Name: discount_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.discount_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: discount_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.discount_usage_id_seq OWNED BY public.discount_usage.id;


--
-- Name: discounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discounts (
    discount_id bigint NOT NULL,
    main_discount_type character varying(20),
    target_products integer[] DEFAULT '{}'::integer[],
    target_collections integer[] DEFAULT '{}'::integer[],
    target_categories integer[] DEFAULT '{}'::integer[],
    target_brands integer[] DEFAULT '{}'::integer[],
    prod_discount_method character varying(20),
    discount_title character varying(125),
    discount_value_type character varying(20),
    discount_value numeric(12,2),
    min_max_purchase_discount_limits boolean,
    min_purchase_amount numeric(12,2),
    max_discount_amount numeric(12,2),
    customer_eligibility character varying(20),
    is_guest_allowed boolean,
    usage_limit_total integer,
    unlimited_usage boolean,
    usage_limit_per_account integer,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    discount_code character varying(12),
    bxgy_max_limit integer,
    order_discount_method character varying(30),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    customer_buys_qty integer,
    customer_gets_qty integer,
    payment_method integer[] DEFAULT '{}'::integer[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT discounts_customer_eligibility_check CHECK (((customer_eligibility)::text = ANY (ARRAY[('all'::character varying)::text, ('new'::character varying)::text, ('existing'::character varying)::text]))),
    CONSTRAINT discounts_discount_value_type_check CHECK (((discount_value_type)::text = ANY (ARRAY[('percentage'::character varying)::text, ('fixed'::character varying)::text]))),
    CONSTRAINT discounts_main_discount_type_check CHECK (((main_discount_type)::text = ANY (ARRAY[('product'::character varying)::text, ('order'::character varying)::text]))),
    CONSTRAINT discounts_order_discount_method_check CHECK (((order_discount_method)::text = ANY (ARRAY[('general'::character varying)::text, ('code'::character varying)::text, ('shipping'::character varying)::text, ('payment_method'::character varying)::text]))),
    CONSTRAINT discounts_prod_discount_method_check CHECK (((prod_discount_method)::text = ANY (ARRAY[('general'::character varying)::text, ('code'::character varying)::text, ('buyxgety'::character varying)::text]))),
    CONSTRAINT discounts_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: discounts_discount_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.discounts_discount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: discounts_discount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.discounts_discount_id_seq OWNED BY public.discounts.discount_id;


--
-- Name: earnings_deductions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.earnings_deductions (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_by integer NOT NULL,
    created_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    calculation_type character varying(20) DEFAULT 'AMOUNT'::character varying NOT NULL,
    CONSTRAINT chk_calculation_type CHECK (((calculation_type)::text = ANY (ARRAY[('AMOUNT'::character varying)::text, ('PERCENTAGE'::character varying)::text]))),
    CONSTRAINT chk_status CHECK (((status)::text = ANY (ARRAY[('ACTIVE'::character varying)::text, ('INACTIVE'::character varying)::text]))),
    CONSTRAINT chk_type CHECK (((type)::text = ANY (ARRAY[('EARNINGS'::character varying)::text, ('DEDUCTIONS'::character varying)::text])))
);


--
-- Name: earnings_deductions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.earnings_deductions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: earnings_deductions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.earnings_deductions_id_seq OWNED BY public.earnings_deductions.id;


--
-- Name: email_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_template (
    id integer NOT NULL,
    subject character varying(255),
    msg text,
    action integer,
    admin character varying(255),
    client character varying(255),
    "user" character varying(255),
    status character varying(255) DEFAULT 'Active'::character varying,
    addby integer,
    createddate character varying(255),
    updateddate timestamp without time zone DEFAULT now(),
    employee character varying(10) DEFAULT ''::character varying
);


--
-- Name: email_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_template_id_seq OWNED BY public.email_template.id;


--
-- Name: employee_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_documents (
    document_id integer NOT NULL,
    employee_id integer NOT NULL,
    document_name character varying(150) NOT NULL,
    file_url text NOT NULL,
    uploaded_by integer NOT NULL,
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_documents_document_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_documents_document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_documents_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_documents_document_id_seq OWNED BY public.employee_documents.document_id;


--
-- Name: employee_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_logs (
    log_id integer NOT NULL,
    employee_id integer NOT NULL,
    log_date date DEFAULT CURRENT_DATE,
    log_time time without time zone DEFAULT CURRENT_TIME,
    module character varying(100) NOT NULL,
    comments text,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_logs_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_logs_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_logs_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_logs_log_id_seq OWNED BY public.employee_logs.log_id;


--
-- Name: employee_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_profiles (
    id integer NOT NULL,
    employee_id character varying(50) NOT NULL,
    first_name character varying(100) NOT NULL,
    middle_name character varying(100),
    last_name character varying(100) NOT NULL,
    nic character varying(20),
    contact_no character varying(20),
    email character varying(255) NOT NULL,
    date_of_birth date,
    marital_status character varying(20),
    gender character varying(20),
    nationality character varying(100),
    bank_account_no character varying(50),
    joined_date date NOT NULL,
    location character varying(100),
    employment_status character varying(30),
    probation_end_date date,
    date_of_permanency date,
    contract_start_date date,
    contract_end_date date,
    job_category character varying(100),
    comments text,
    designation_id integer
);


--
-- Name: employee_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_profiles_id_seq OWNED BY public.employee_profiles.id;


--
-- Name: employee_remarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_remarks (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    remark text NOT NULL,
    remark_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    remark_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    remark_type character varying(50) DEFAULT 'GENERAL'::character varying NOT NULL,
    CONSTRAINT check_remark_type CHECK (((remark_type)::text = ANY (ARRAY[('GENERAL'::character varying)::text, ('WARNING'::character varying)::text, ('APPRECIATION'::character varying)::text, ('DISCIPLINARY'::character varying)::text])))
);


--
-- Name: employee_remarks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_remarks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_remarks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_remarks_id_seq OWNED BY public.employee_remarks.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    middle_name character varying(100),
    last_name character varying(100) NOT NULL,
    nic character varying(20) NOT NULL,
    contact_no character varying(20) NOT NULL,
    email character varying(150) NOT NULL,
    date_of_birth date NOT NULL,
    marital_status character varying(20) NOT NULL,
    gender character varying(20) NOT NULL,
    nationality character varying(100) NOT NULL,
    address text NOT NULL,
    city character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    bank_account_no character varying(50) NOT NULL,
    joined_date date NOT NULL,
    job_specification text NOT NULL,
    employment_status character varying(50) NOT NULL,
    probation_start_date date,
    probation_end_date date,
    date_of_permanency date,
    contract_start_date date,
    contract_end_date date,
    job_category character varying(100),
    comments text,
    designation_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    shift_id integer,
    payroll_template_id integer,
    mobile_number character varying(20),
    passport_number character varying(50),
    account_type character varying(50),
    account_holder_name character varying(150),
    bank_branch character varying(150),
    department_id integer NOT NULL,
    special_note text,
    outlet_id integer NOT NULL,
    emergency_contact_full_name character varying(150) NOT NULL,
    emergency_contact_address text NOT NULL,
    emergency_contact_relationship character varying(100) NOT NULL,
    emergency_contact_mobile_no character varying(20) NOT NULL,
    net_salary_effective_date date,
    salary_start_day integer DEFAULT 1,
    first_salary_strategy character varying(20) DEFAULT 'CURRENT_MONTH'::character varying NOT NULL,
    salary_generation_type character varying(20) DEFAULT 'MANUAL'::character varying NOT NULL,
    salary_start_date date,
    CONSTRAINT chk_employment_status CHECK (((employment_status)::text = ANY (ARRAY[('PROBATION'::character varying)::text, ('PERMANENT'::character varying)::text, ('CONTRACT'::character varying)::text, ('RESIGNED'::character varying)::text, ('TERMINATED'::character varying)::text]))),
    CONSTRAINT chk_first_salary_strategy CHECK (((first_salary_strategy)::text = ANY (ARRAY[('CURRENT_MONTH'::character varying)::text, ('NEXT_MONTH'::character varying)::text]))),
    CONSTRAINT chk_gender CHECK (((gender)::text = ANY (ARRAY[('MALE'::character varying)::text, ('FEMALE'::character varying)::text, ('OTHER'::character varying)::text]))),
    CONSTRAINT chk_marital_status CHECK (((marital_status)::text = ANY (ARRAY[('SINGLE'::character varying)::text, ('MARRIED'::character varying)::text, ('DIVORCED'::character varying)::text, ('WIDOWED'::character varying)::text]))),
    CONSTRAINT chk_salary_generation_type CHECK (((salary_generation_type)::text = ANY (ARRAY[('AUTO'::character varying)::text, ('MANUAL'::character varying)::text])))
);


--
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_employee_id_seq OWNED BY public.employees.employee_id;


--
-- Name: employment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employment (
    id integer NOT NULL,
    name text,
    phone text,
    "position" integer
);


--
-- Name: employment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employment_id_seq OWNED BY public.employment.id;


--
-- Name: farder_webhook_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.farder_webhook_logs (
    id integer NOT NULL,
    delivery_partner_id integer,
    waybill_id character varying(100),
    ref_url text,
    response jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: farder_webhook_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.farder_webhook_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: farder_webhook_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.farder_webhook_logs_id_seq OWNED BY public.farder_webhook_logs.id;


--
-- Name: grn_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grn_header (
    grn_id bigint NOT NULL,
    grn_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    po_id bigint NOT NULL,
    supplier_id bigint NOT NULL,
    status text DEFAULT 'received'::text NOT NULL,
    total_received_qty integer DEFAULT 0 NOT NULL,
    total_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    remark text,
    received_by bigint NOT NULL,
    received_date timestamp without time zone,
    authorized_by bigint,
    authorized_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    returned_total numeric(12,2) DEFAULT 0.00 NOT NULL
);


--
-- Name: grn_header_grn_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grn_header_grn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grn_header_grn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grn_header_grn_id_seq OWNED BY public.grn_header.grn_id;


--
-- Name: grn_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grn_items (
    grn_item_id bigint NOT NULL,
    grn_id bigint NOT NULL,
    po_item_id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_id bigint,
    batch_number text,
    ordered_qty integer NOT NULL,
    received_qty integer NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    po_id bigint NOT NULL,
    returned_qty numeric(10,2) DEFAULT 0 NOT NULL,
    measurement_unit integer,
    amount_per_unit numeric(12,2),
    line_total numeric(14,2),
    CONSTRAINT grn_items_ordered_qty_check CHECK ((ordered_qty >= 0)),
    CONSTRAINT grn_items_received_qty_check CHECK ((received_qty >= 0)),
    CONSTRAINT grn_items_unit_cost_check CHECK ((unit_cost >= (0)::numeric))
);


--
-- Name: grn_items_grn_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grn_items_grn_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grn_items_grn_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grn_items_grn_item_id_seq OWNED BY public.grn_items.grn_item_id;


--
-- Name: hero_section; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_section (
    id integer NOT NULL,
    sub_title text,
    title text,
    icon text,
    icon_title text,
    image text,
    text_color text,
    bg_color text,
    status text
);


--
-- Name: hero_section_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hero_section_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hero_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hero_section_id_seq OWNED BY public.hero_section.id;


--
-- Name: holidays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.holidays (
    holiday_id integer NOT NULL,
    holiday_date date NOT NULL,
    holiday_name character varying(150) NOT NULL,
    holiday_type character varying(100) NOT NULL,
    occasion text,
    employment_status character varying(50) NOT NULL,
    department_ids integer[] NOT NULL,
    designation_ids integer[] NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_employment_status CHECK (((employment_status)::text = ANY (ARRAY[('PERMANENT'::character varying)::text, ('CONTRACT'::character varying)::text, ('PROBATION'::character varying)::text, ('INTERN'::character varying)::text, ('RESIGNED'::character varying)::text, ('TERMINATED'::character varying)::text])))
);


--
-- Name: holidays_holiday_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.holidays_holiday_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: holidays_holiday_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.holidays_holiday_id_seq OWNED BY public.holidays.holiday_id;


--
-- Name: increments_and_promotions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.increments_and_promotions (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    change_type character varying(20) NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    note text,
    effective_date date NOT NULL,
    new_designation_id integer,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_designation_usage CHECK (((((change_type)::text = ANY (ARRAY[('PROMOTION'::character varying)::text, ('DEMOTION'::character varying)::text])) AND (new_designation_id IS NOT NULL)) OR (((change_type)::text = ANY (ARRAY[('INCREMENT'::character varying)::text, ('SALARY_REVISION'::character varying)::text])) AND (new_designation_id IS NULL)))),
    CONSTRAINT increments_and_promotions_change_type_check CHECK (((change_type)::text = ANY (ARRAY[('INCREMENT'::character varying)::text, ('PROMOTION'::character varying)::text, ('DEMOTION'::character varying)::text, ('SALARY_REVISION'::character varying)::text])))
);


--
-- Name: increments_and_promotions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.increments_and_promotions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: increments_and_promotions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.increments_and_promotions_id_seq OWNED BY public.increments_and_promotions.id;


--
-- Name: ingredients_stock_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredients_stock_details (
    id integer NOT NULL,
    sheet_id integer,
    ingredient_id integer,
    prev_stock integer,
    change_stock integer,
    current_stock integer,
    created_at timestamp with time zone
);


--
-- Name: ingredients_stock_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ingredients_stock_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ingredients_stock_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ingredients_stock_details_id_seq OWNED BY public.ingredients_stock_details.id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory (
    inventory_id integer NOT NULL,
    variant_id integer,
    outlet_id integer,
    updated_by character varying(50),
    comment character varying(250),
    system_module character varying(50),
    previous_quantity integer,
    adjust_quantity integer NOT NULL,
    new_quantity integer,
    status character varying(20),
    last_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    merchant_id integer,
    user_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    batch_number character varying(50),
    CONSTRAINT inventory_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text]))),
    CONSTRAINT inventory_system_module_check CHECK (((system_module)::text = ANY (ARRAY[('stock in'::character varying)::text, ('stock out'::character varying)::text, ('no-change'::character varying)::text])))
);


--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_inventory_id_seq OWNED BY public.inventory.inventory_id;


--
-- Name: inventory_strategy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_strategy (
    inventory_strategy_id integer NOT NULL,
    name character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    CONSTRAINT inventory_strategy_status_check CHECK (((status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Inactive'::character varying)::text])))
);


--
-- Name: inventory_strategy_inventory_strategy_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_strategy_inventory_strategy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_strategy_inventory_strategy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_strategy_inventory_strategy_id_seq OWNED BY public.inventory_strategy.inventory_strategy_id;


--
-- Name: invoice_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_details (
    id bigint DEFAULT nextval('public.invoice_details_id_seq'::regclass) NOT NULL,
    invoice_id bigint,
    product_id bigint,
    variant_id bigint,
    name character varying(255),
    description text,
    item_weight numeric(10,2),
    quantity numeric,
    unit_price numeric(12,2),
    discount numeric(12,2) DEFAULT 0,
    total_price numeric(12,2),
    is_free boolean DEFAULT false,
    free_quantity integer DEFAULT 0,
    is_custom boolean DEFAULT false,
    amount_per_unit numeric DEFAULT 0,
    unit_type character varying(20),
    batch_no text,
    invoice_item_uid uuid DEFAULT gen_random_uuid() NOT NULL,
    return_qty numeric DEFAULT 0
);


--
-- Name: invoice_details_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_details_order_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_details_order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_details_order_item_id_seq OWNED BY public.invoice_details.id;


--
-- Name: invoice_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_header (
    id bigint NOT NULL,
    customer_id bigint,
    payment_method_id bigint,
    order_status character varying(50),
    total_value numeric(12,2),
    amount_paid numeric(12,2),
    total_item integer,
    total_weight numeric(10,2) DEFAULT 0,
    dimensions character varying(255),
    cod boolean,
    payment_gateway_responce text,
    payment_status character varying(50),
    currency character varying(10),
    sender_name character varying(255),
    sender_phone character varying(50),
    sender_email character varying(255),
    sender_address text,
    sender_city character varying(255),
    sender_postal_code character varying(50),
    sender_country character varying(100),
    recipient_contact_two character varying(50),
    cancelled_by character varying(50),
    cancelled_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    paid_at timestamp without time zone,
    updated_at timestamp without time zone,
    note character varying(255),
    delivery_fee numeric(12,2) DEFAULT 0,
    discount numeric(12,2),
    user_id bigint,
    tax_percentage numeric(5,2),
    full_amount numeric(12,2),
    bank_slip text,
    discount_type character varying(50),
    loyalty_points_earned numeric(10,2) DEFAULT 0,
    loyalty_points_spent numeric(10,2) DEFAULT 0,
    merchant_id integer,
    payment_reference text,
    tax jsonb,
    pos_terminal_id integer,
    interface text DEFAULT 'back_office'::text,
    payments jsonb,
    salespersons jsonb,
    discount_details jsonb,
    balance numeric DEFAULT 0,
    till_id text,
    add_to_points numeric,
    invoice_link text,
    inventory_deduct boolean DEFAULT true,
    sender_addrees_2 text,
    table_id integer,
    outlet_id integer
);


--
-- Name: invoice_header_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.invoice_header ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.invoice_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: invoice_header_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_header_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_header_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_header_order_id_seq OWNED BY public.invoice_header.id;


--
-- Name: invoice_payment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_payment_history (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT now(),
    invoice_id integer,
    user_id integer,
    method_id integer,
    amount numeric,
    reference text,
    doc text,
    status text DEFAULT 'active'::text,
    type text DEFAULT 'paid'::text,
    loyalty_points_earned numeric DEFAULT 0,
    loyalty_points_spent numeric DEFAULT 0,
    acc_id integer,
    till_id integer
);


--
-- Name: invoice_payment_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_payment_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_payment_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_payment_history_id_seq OWNED BY public.invoice_payment_history.id;


--
-- Name: job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job (
    id integer NOT NULL,
    job_name character varying(255) NOT NULL,
    job_description text,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    customer_id integer,
    hold_reason text,
    assigned_users jsonb DEFAULT '[]'::jsonb,
    admin_note text,
    deleted_at timestamp with time zone
);


--
-- Name: job_bill_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_bill_item (
    id integer NOT NULL,
    job_id integer NOT NULL,
    item_type public.item_type_enum NOT NULL,
    product_id integer,
    item_name character varying(255) NOT NULL,
    quantity integer DEFAULT 1,
    unit_price numeric(10,2) DEFAULT 0,
    total_price numeric(10,2) DEFAULT 0,
    CONSTRAINT job_bill_item_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT job_bill_item_unit_price_check CHECK ((unit_price >= (0)::numeric))
);


--
-- Name: job_bill_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_bill_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_bill_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_bill_item_id_seq OWNED BY public.job_bill_item.id;


--
-- Name: job_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.job ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: job_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_log (
    log_id integer NOT NULL,
    job_id integer NOT NULL,
    action character varying(255) NOT NULL,
    description text,
    performed_by character varying(100),
    user_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: job_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_log_log_id_seq OWNED BY public.job_log.log_id;


--
-- Name: job_other_service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_other_service (
    id integer NOT NULL,
    job_id integer NOT NULL,
    service_name character varying(255) NOT NULL,
    amount numeric(10,2) DEFAULT 0 NOT NULL,
    CONSTRAINT job_other_service_amount_check CHECK ((amount >= (0)::numeric))
);


--
-- Name: job_other_service_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_other_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_other_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_other_service_id_seq OWNED BY public.job_other_service.id;


--
-- Name: kitchen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kitchen (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    outlet_id integer NOT NULL,
    display_id character varying(50),
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    kot_printer_id integer,
    CONSTRAINT kitchen_status_check CHECK (((status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Inactive'::character varying)::text])))
);


--
-- Name: kitchen_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kitchen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kitchen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kitchen_id_seq OWNED BY public.kitchen.id;


--
-- Name: kitchen_order_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kitchen_order_lines (
    id integer NOT NULL,
    invoice_id integer,
    product_id integer,
    kitchen_id integer,
    qty numeric,
    is_reprint boolean,
    order_line_id integer
);


--
-- Name: kitchen_order_lines_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kitchen_order_lines_header (
    id integer NOT NULL,
    sent_by integer,
    sent_at timestamp without time zone,
    status text DEFAULT 'pending'::text
);


--
-- Name: kitchen_order_lines_header_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kitchen_order_lines_header_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kitchen_order_lines_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kitchen_order_lines_header_id_seq OWNED BY public.kitchen_order_lines_header.id;


--
-- Name: kitchen_order_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kitchen_order_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kitchen_order_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kitchen_order_lines_id_seq OWNED BY public.kitchen_order_lines.id;


--
-- Name: kitchen_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kitchen_products (
    kitchen_id integer NOT NULL,
    product_id integer NOT NULL,
    status text
);


--
-- Name: leave_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_types (
    leave_type_id integer NOT NULL,
    name character varying(50) NOT NULL,
    days_per_year integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: leave_types_leave_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_types_leave_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_types_leave_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_types_leave_type_id_seq OWNED BY public.leave_types.leave_type_id;


--
-- Name: leaves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leaves (
    leave_id integer NOT NULL,
    employee_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL,
    reason text NOT NULL,
    admin_note text,
    status character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    paid_status character varying(10) DEFAULT 'paid'::character varying NOT NULL,
    duration_type character varying(20) DEFAULT 'full_day'::character varying NOT NULL,
    designation_id integer,
    CONSTRAINT chk_date_valid CHECK ((to_date >= from_date)),
    CONSTRAINT chk_duration_type CHECK (((duration_type)::text = ANY (ARRAY[('full_day'::character varying)::text, ('first_half'::character varying)::text, ('second_half'::character varying)::text, ('multiple'::character varying)::text]))),
    CONSTRAINT chk_leave_status CHECK (((status)::text = ANY (ARRAY[('Pending'::character varying)::text, ('Approved'::character varying)::text, ('Rejected'::character varying)::text]))),
    CONSTRAINT chk_paid_status CHECK (((paid_status)::text = ANY (ARRAY[('paid'::character varying)::text, ('unpaid'::character varying)::text])))
);


--
-- Name: leaves_leave_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leaves_leave_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leaves_leave_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leaves_leave_id_seq OWNED BY public.leaves.leave_id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    user_id integer,
    log character varying(255),
    date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    title character varying(255)
);


--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: material_inventory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_inventory (
    id integer NOT NULL,
    material_id integer,
    prev_stock numeric,
    adjust_stock numeric,
    current_stock numeric,
    by integer,
    date timestamp without time zone,
    module text,
    outlet_id integer,
    note text,
    type text
);


--
-- Name: material_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_inventory_id_seq OWNED BY public.material_inventory.id;


--
-- Name: measurements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.measurements (
    measurement_id integer NOT NULL,
    measurement_value character varying(100) NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT measurements_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: measurements_measurement_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.measurements_measurement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: measurements_measurement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.measurements_measurement_id_seq OWNED BY public.measurements.measurement_id;


--
-- Name: merchant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.merchant_id_seq
    START WITH 20000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: merchants_merchant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.merchants_merchant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: merchants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.merchants (
    store_name character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    merchant_id integer DEFAULT nextval('public.merchants_merchant_id_seq'::regclass) NOT NULL,
    user_id integer
);


--
-- Name: merchants_merchant_id_int_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.merchants_merchant_id_int_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: merchants_merchant_id_int_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.merchants_merchant_id_int_seq OWNED BY public.merchants.merchant_id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    notification_id integer NOT NULL,
    user_id integer NOT NULL,
    module character varying(100) NOT NULL,
    event_type character varying(150) NOT NULL,
    channel character varying(50) NOT NULL,
    message_template text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(10) DEFAULT 'Unread'::character varying NOT NULL,
    CONSTRAINT notifications_status_check CHECK (((status)::text = ANY (ARRAY[('Unread'::character varying)::text, ('Read'::character varying)::text])))
);


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_notification_id_seq OWNED BY public.notifications.notification_id;


--
-- Name: order_bulk_prints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_bulk_prints (
    bulk_id integer NOT NULL,
    generated_by integer NOT NULL,
    generated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    order_count integer DEFAULT 0 NOT NULL
);


--
-- Name: order_bulk_prints_bulk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_bulk_prints_bulk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_bulk_prints_bulk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_bulk_prints_bulk_id_seq OWNED BY public.order_bulk_prints.bulk_id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    order_item_id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    variant_id integer NOT NULL,
    item_weght numeric(10,2) DEFAULT 0.00,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0.00,
    total_price numeric(10,2) NOT NULL,
    is_free boolean DEFAULT false,
    free_quantity integer DEFAULT 0,
    CONSTRAINT order_items_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT order_items_total_price_check CHECK ((total_price >= (0)::numeric)),
    CONSTRAINT order_items_unit_price_check CHECK ((unit_price >= (0)::numeric))
);


--
-- Name: order_items_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_order_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_order_item_id_seq OWNED BY public.order_items.order_item_id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    customer_id integer NOT NULL,
    merchant_id integer NOT NULL,
    payment_method_id integer NOT NULL,
    order_status character varying(50) NOT NULL,
    total_value numeric(10,2) DEFAULT 0.00,
    amount_paid numeric(10,2) DEFAULT 0 NOT NULL,
    total_item integer DEFAULT 0,
    total_weight numeric(10,2) DEFAULT 0.00,
    dimensions character varying(100),
    cod boolean DEFAULT false,
    payment_gateway_responce text,
    payment_status character varying(20) NOT NULL,
    currency character varying(50) DEFAULT 'USD'::character varying,
    sender_address text,
    delivery_partner_id integer,
    delivery_completed_date timestamp with time zone,
    delivery_type character varying(50),
    tracking_id character varying(100),
    currier_handover_date date,
    currier_status character varying(50) DEFAULT 'not_assigned'::character varying,
    currier_payment_status character varying(50) DEFAULT 'unpaid'::character varying,
    descline_orders text,
    cancelled_by character varying(100),
    cancelled_date timestamp without time zone,
    returned_date timestamp without time zone,
    returned_person character varying(100),
    confirmed_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    paid_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    recipient_name text,
    recipient_contact text,
    recipient_email text,
    recipient_address text,
    payment_reference text,
    order_module text,
    delivery_fee numeric DEFAULT 0,
    discount numeric DEFAULT 0,
    recipient_city text,
    recipient_postal_code text,
    recipient_country text,
    user_id integer,
    managed_by integer,
    confiremed_by integer,
    storepickup text DEFAULT 'No'::text,
    dispatched_date timestamp without time zone,
    processing_date timestamp without time zone,
    order_note character varying(250),
    reason_id text,
    bulk_id integer,
    bulk_dispatched_id integer,
    sender_name text,
    sender_city text,
    sender_phone text,
    sender_email text,
    sender_phone_two text,
    recipient_contact_two text,
    sender_country text,
    tax_percentage text,
    tax jsonb,
    purchase_count integer DEFAULT 0,
    full_amount numeric DEFAULT 0,
    bank_slip text,
    discount_type text,
    loyalty_points_earned numeric(10,2) DEFAULT 0,
    loyalty_points_spent numeric(10,2) DEFAULT 0,
    recipient_addrees_2 text,
    sender_addrees_2 text,
    outlet_id integer,
    CONSTRAINT orders_amount_paid_check CHECK ((amount_paid >= (0)::numeric)),
    CONSTRAINT orders_delivery_type_check CHECK (((delivery_type)::text = ANY (ARRAY[('standard'::character varying)::text, ('express'::character varying)::text]))),
    CONSTRAINT orders_order_status_check CHECK (((order_status)::text = ANY (ARRAY[('pending'::character varying)::text, ('confirmed'::character varying)::text, ('processing'::character varying)::text, ('dispatched'::character varying)::text, ('completed'::character varying)::text, ('cancelled'::character varying)::text, ('returned'::character varying)::text]))),
    CONSTRAINT orders_payment_status_check CHECK (((payment_status)::text = ANY (ARRAY[('unpaid'::character varying)::text, ('paid'::character varying)::text, ('refund'::character varying)::text, ('failed'::character varying)::text, ('discount'::character varying)::text])))
);


--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_order_id_seq OWNED BY public.orders.order_id;


--
-- Name: outlets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outlets (
    outlet_id integer NOT NULL,
    name character varying(100) NOT NULL,
    address text,
    geocode character varying(50),
    hotline character varying(50),
    email character varying(100),
    opening_hours_from time without time zone NOT NULL,
    opening_hours_to time without time zone NOT NULL,
    tel_number character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    merchant_id integer
);


--
-- Name: outlets_outlet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.outlets_outlet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: outlets_outlet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.outlets_outlet_id_seq OWNED BY public.outlets.outlet_id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    payment_method_id integer NOT NULL,
    method_name character varying(100) NOT NULL,
    payment_type character varying(20),
    logo character varying(255),
    tagline character varying(150),
    payment_intraduction text,
    transaction_fixed_fee numeric(10,2) DEFAULT 0.00,
    transaction_fee numeric(5,2) DEFAULT 0.00,
    discount numeric(5,2) DEFAULT 0.00,
    last_responce text,
    status character varying(20),
    api_array jsonb,
    category character varying(100),
    web_show boolean,
    pos_show boolean,
    CONSTRAINT payment_methods_payment_type_check CHECK (((payment_type)::text = ANY (ARRAY[('online'::character varying)::text, ('offline'::character varying)::text]))),
    CONSTRAINT payment_methods_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: payment_methods_payment_method_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_methods_payment_method_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_methods_payment_method_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_methods_payment_method_id_seq OWNED BY public.payment_methods.payment_method_id;


--
-- Name: payroll_template_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_template_details (
    id integer NOT NULL,
    earning_deduction_id integer NOT NULL,
    type character varying(20) NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    payroll_template_id integer,
    value numeric(12,2) DEFAULT 0,
    earning_deduction_name character varying(150),
    CONSTRAINT payroll_template_details_type_check CHECK (((type)::text = ANY (ARRAY[('EARNINGS'::character varying)::text, ('DEDUCTIONS'::character varying)::text])))
);


--
-- Name: payroll_template_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_template_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_template_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_template_details_id_seq OWNED BY public.payroll_template_details.id;


--
-- Name: payroll_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_templates (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_by integer NOT NULL,
    created_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    earnings numeric(12,2) DEFAULT 0,
    deductions numeric(12,2) DEFAULT 0,
    payroll_type public.payroll_type DEFAULT 'MONTHLY'::public.payroll_type NOT NULL,
    value numeric(12,2) DEFAULT 0,
    percentage_base character varying(150) DEFAULT 'BASIC_SALARY'::character varying,
    ot_hour_rate numeric(12,2) DEFAULT 0 NOT NULL,
    holiday_ot_hour_rate numeric(12,2) DEFAULT 0 NOT NULL,
    no_pay_deduction_rate numeric(12,2) DEFAULT 0 NOT NULL
);


--
-- Name: payroll_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_templates_id_seq OWNED BY public.payroll_templates.id;


--
-- Name: paysheet_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paysheet_details (
    paysheet_detail_id integer NOT NULL,
    paysheet_id integer NOT NULL,
    earning_deduction_id integer,
    type character varying(20) NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    earning_deduction_name character varying(200),
    CONSTRAINT paysheet_details_type_check CHECK (((type)::text = ANY (ARRAY[('EARNING'::character varying)::text, ('EARNINGS'::character varying)::text, ('DEDUCTION'::character varying)::text, ('DEDUCTIONS'::character varying)::text])))
);


--
-- Name: paysheet_details_paysheet_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paysheet_details_paysheet_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paysheet_details_paysheet_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paysheet_details_paysheet_detail_id_seq OWNED BY public.paysheet_details.paysheet_detail_id;


--
-- Name: paysheet_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paysheet_invoices (
    paysheet_invoice_id integer NOT NULL,
    paysheet_detail_id integer NOT NULL,
    payment_reference character varying(150) NOT NULL,
    paid_by character varying(100) NOT NULL,
    payment_status character varying(20) DEFAULT 'PAID'::character varying,
    admin_note text,
    payslip_url text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    account_id integer,
    account_name text,
    bank_account boolean DEFAULT true,
    payment_method character varying(50) DEFAULT 'BANK_TRANSFER'::character varying,
    CONSTRAINT payment_status_check CHECK (((payment_status)::text = ANY (ARRAY[('PAID'::character varying)::text, ('PENDING'::character varying)::text, ('FAILED'::character varying)::text])))
);


--
-- Name: paysheet_invoices_paysheet_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paysheet_invoices_paysheet_invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paysheet_invoices_paysheet_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paysheet_invoices_paysheet_invoice_id_seq OWNED BY public.paysheet_invoices.paysheet_invoice_id;


--
-- Name: paysheets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paysheets (
    paysheet_id integer NOT NULL,
    employee_id integer NOT NULL,
    employee_name character varying(200) NOT NULL,
    salary_range_start date NOT NULL,
    salary_range_end date NOT NULL,
    payroll_month integer NOT NULL,
    payroll_year integer NOT NULL,
    pay_date date,
    total_working_days integer DEFAULT 0,
    present_days integer DEFAULT 0,
    half_days integer DEFAULT 0,
    absent_days integer DEFAULT 0,
    paid_leave_days integer DEFAULT 0,
    unpaid_leave_days integer DEFAULT 0,
    late_count integer DEFAULT 0,
    total_earnings numeric(12,2) DEFAULT 0 NOT NULL,
    total_deductions numeric(12,2) DEFAULT 0 NOT NULL,
    net_salary numeric(12,2) DEFAULT 0 NOT NULL,
    payroll_status character varying(30) DEFAULT 'DRAFT'::character varying NOT NULL,
    generated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approved_at timestamp without time zone,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    payroll_template_id integer NOT NULL,
    CONSTRAINT chk_salary_range CHECK ((salary_range_end >= salary_range_start)),
    CONSTRAINT paysheets_payroll_month_check CHECK (((payroll_month >= 1) AND (payroll_month <= 12))),
    CONSTRAINT paysheets_payroll_status_check CHECK (((payroll_status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('GENERATED'::character varying)::text, ('APPROVED'::character varying)::text, ('PAID'::character varying)::text, ('CANCELLED'::character varying)::text]))),
    CONSTRAINT paysheets_payroll_year_check CHECK ((payroll_year >= 2020))
);


--
-- Name: paysheets_paysheet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paysheets_paysheet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paysheets_paysheet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paysheets_paysheet_id_seq OWNED BY public.paysheets.paysheet_id;


--
-- Name: pick_from_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pick_from_client (
    id integer NOT NULL,
    job_id integer NOT NULL,
    equipment_name character varying(255) NOT NULL,
    note text,
    serial_number character varying(100)
);


--
-- Name: pick_from_client_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pick_from_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pick_from_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pick_from_client_id_seq OWNED BY public.pick_from_client.id;


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugins (
    plugin_id integer NOT NULL,
    plugin_name character varying(255) NOT NULL,
    information text,
    logo character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: plugins_plugin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plugins_plugin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plugins_plugin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plugins_plugin_id_seq OWNED BY public.plugins.plugin_id;


--
-- Name: po_header_po_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.po_header_po_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: po_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_header (
    po_id bigint DEFAULT nextval('public.po_header_po_id_seq'::regclass) NOT NULL,
    po_date timestamp without time zone DEFAULT now() NOT NULL,
    expected_date date,
    status text NOT NULL,
    supplier_id bigint NOT NULL,
    po_qty integer,
    remark text,
    supplier_instructions text,
    po_total_amount numeric(12,2),
    generated_user bigint NOT NULL,
    authorized_by bigint,
    authorized_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT po_header_status_check CHECK ((status = ANY (ARRAY['approved'::text, 'rejected'::text, 'pending'::text])))
);


--
-- Name: po_header_po_header_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.po_header_po_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: po_header_po_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.po_header_po_header_id_seq OWNED BY public.po_header.po_id;


--
-- Name: po_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.po_items (
    po_item_id bigint NOT NULL,
    po_id bigint NOT NULL,
    variant_id bigint NOT NULL,
    product_id bigint NOT NULL,
    batch_number text,
    unit_cost numeric(12,2) NOT NULL,
    req_qty integer NOT NULL,
    measurement_unit integer,
    amount_per_unit numeric(12,4),
    line_total numeric(14,2),
    CONSTRAINT po_items_req_qty_check CHECK ((req_qty > 0)),
    CONSTRAINT po_items_unit_cost_check CHECK ((unit_cost >= (0)::numeric))
);


--
-- Name: po_items_po_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.po_items_po_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: po_items_po_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.po_items_po_item_id_seq OWNED BY public.po_items.po_item_id;


--
-- Name: points_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points_logs (
    id integer NOT NULL,
    comment text,
    prev_amount numeric(10,2),
    adjust_amount numeric(10,2),
    new_amount numeric(10,2),
    customer_id integer,
    date timestamp without time zone DEFAULT now()
);


--
-- Name: points_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_logs_id_seq OWNED BY public.points_logs.id;


--
-- Name: portal_interface; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_interface (
    interface_id integer NOT NULL,
    name character varying(150) NOT NULL,
    route character varying(255) NOT NULL,
    status character varying(10) DEFAULT 'active'::character varying NOT NULL,
    CONSTRAINT portal_interface_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: portal_interface_interface_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.portal_interface_interface_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: portal_interface_interface_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.portal_interface_interface_id_seq OWNED BY public.portal_interface.interface_id;


--
-- Name: pos_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_settings (
    id smallint DEFAULT 1 NOT NULL,
    sound boolean DEFAULT true NOT NULL,
    restaurant_mode boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    logo_url text,
    return_policy jsonb,
    quantity_dialog boolean DEFAULT false,
    scan_code text DEFAULT 'all'::text,
    CONSTRAINT pos_settings_singleton CHECK ((id = 1))
);


--
-- Name: prn_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prn_header (
    prn_id bigint NOT NULL,
    prn_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    grn_id bigint NOT NULL,
    po_id bigint NOT NULL,
    supplier_id bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    total_return_qty numeric(12,2) DEFAULT 0 NOT NULL,
    total_return_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    remark text,
    returned_by bigint NOT NULL,
    returned_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    authorized_by bigint,
    authorized_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: prn_header_prn_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.prn_header_prn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: prn_header_prn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.prn_header_prn_id_seq OWNED BY public.prn_header.prn_id;


--
-- Name: prn_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prn_items (
    prn_item_id bigint NOT NULL,
    prn_id bigint NOT NULL,
    grn_item_id bigint NOT NULL,
    po_item_id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_id bigint,
    batch_number text,
    ordered_qty integer NOT NULL,
    received_qty integer NOT NULL,
    return_qty numeric(10,2) NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    line_total numeric(12,2) GENERATED ALWAYS AS ((return_qty * unit_cost)) STORED,
    reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT prn_items_ordered_qty_check CHECK ((ordered_qty >= 0)),
    CONSTRAINT prn_items_received_qty_check CHECK ((received_qty >= 0)),
    CONSTRAINT prn_items_return_qty_check CHECK ((return_qty > (0)::numeric)),
    CONSTRAINT prn_items_unit_cost_check CHECK ((unit_cost >= (0)::numeric))
);


--
-- Name: prn_items_prn_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.prn_items_prn_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: prn_items_prn_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.prn_items_prn_item_id_seq OWNED BY public.prn_items.prn_item_id;


--
-- Name: product_brands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_brands (
    product_id integer NOT NULL,
    brand_id integer NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    CONSTRAINT product_brands_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: product_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_category (
    category_id integer NOT NULL,
    product_id integer
);


--
-- Name: product_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_collections (
    collection_id integer NOT NULL,
    product_id integer
);


--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_media (
    media_id integer NOT NULL,
    media_url character varying(255) NOT NULL,
    media_type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    product_id integer,
    status character varying(20) DEFAULT 'active'::character varying,
    variant_id integer,
    main boolean DEFAULT false,
    CONSTRAINT product_media_media_type_check CHECK (((media_type)::text = ANY (ARRAY[('image'::character varying)::text, ('video'::character varying)::text, ('3d'::character varying)::text]))),
    CONSTRAINT product_media_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: product_media_media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_media_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_media_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_media_media_id_seq OWNED BY public.product_media.media_id;


--
-- Name: product_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_reviews (
    review_id integer NOT NULL,
    customer_name character varying(100) NOT NULL,
    user_id integer,
    review numeric(2,1),
    comment text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    product_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: product_reviews_review_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_reviews_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_reviews_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_reviews_review_id_seq OWNED BY public.product_reviews.review_id;


--
-- Name: product_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_tags (
    tag_id integer NOT NULL,
    product_id integer,
    status character varying(20) DEFAULT 'active'::character varying,
    CONSTRAINT product_tags_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: product_variants_variant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_variants_variant_id_seq
    START WITH 500000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variants (
    variant_type character varying(50),
    variant_value character varying(50),
    sku character varying(50),
    barcode character varying(50),
    price numeric(10,2) NOT NULL,
    compare_at_price numeric(10,2),
    inventory_quantity integer DEFAULT 0,
    track_quantity boolean DEFAULT true,
    shop_location_selling character varying(100),
    continue_selling_oos boolean DEFAULT false,
    is_physical_product boolean DEFAULT true,
    weight numeric(10,2),
    weight_unit character varying(10),
    customs_info text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    product_id integer,
    variant_id integer DEFAULT nextval('public.product_variants_variant_id_seq'::regclass) NOT NULL,
    cost_per_item numeric(10,2) NOT NULL,
    system_barcode uuid DEFAULT gen_random_uuid() NOT NULL,
    reorder_level integer,
    status character varying(20) DEFAULT 'active'::character varying,
    view_count integer DEFAULT 0,
    CONSTRAINT product_variants_weight_unit_check CHECK (((weight_unit)::text = ANY (ARRAY[('kg'::character varying)::text, ('g'::character varying)::text, ('lb'::character varying)::text, ('oz'::character varying)::text])))
);


--
-- Name: production_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_details (
    id integer NOT NULL,
    production_id integer,
    ingredient_id integer,
    quantity numeric,
    unit integer
);


--
-- Name: production_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_details_id_seq OWNED BY public.production_details.id;


--
-- Name: production_details_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_details_product (
    id integer NOT NULL,
    production_id integer,
    product_id integer,
    quantity numeric,
    unit numeric,
    raw_id integer
);


--
-- Name: production_details_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_details_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_details_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_details_product_id_seq OWNED BY public.production_details_product.id;


--
-- Name: production_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_header (
    id integer NOT NULL,
    kitchen_id integer,
    created_at timestamp without time zone,
    by integer,
    status text
);


--
-- Name: production_header_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_header_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_header_id_seq OWNED BY public.production_header.id;


--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_product_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    title character varying(100) NOT NULL,
    description text,
    status character varying(20),
    publishing_online boolean DEFAULT true,
    price numeric(10,2) NOT NULL,
    compare_at_price numeric(10,2),
    charge_tax_on_product boolean DEFAULT false,
    cost_per_item numeric(10,2),
    profit numeric(10,2),
    margin numeric(10,2),
    search_engine_title character varying(70),
    search_engine_desc character varying(160),
    type character varying(50),
    vendor character varying(50),
    theme_template character varying(50) DEFAULT 'default product'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    publishing_pos boolean DEFAULT true,
    product_id integer DEFAULT nextval('public.products_product_id_seq'::regclass) NOT NULL,
    merchant_id integer,
    measurement_id integer,
    default_weight numeric DEFAULT 0,
    view_count integer DEFAULT 0,
    amount_per_unit integer,
    default_barcode text,
    publish_to_web boolean DEFAULT false NOT NULL,
    similar_keywords text[],
    CONSTRAINT products_publishing_online_check CHECK ((publishing_online = ANY (ARRAY[true, false]))),
    CONSTRAINT products_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text, ('draft'::character varying)::text])))
);


--
-- Name: quotation_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotation_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotation_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotation_details (
    id bigint DEFAULT nextval('public.quotation_details_id_seq'::regclass) NOT NULL,
    quotation_id bigint,
    product_id bigint,
    variant_id bigint,
    name character varying(255),
    description text,
    item_weight numeric(10,2),
    quantity integer,
    unit_price numeric(12,2),
    discount numeric(12,2) DEFAULT 0,
    total_price numeric(12,2),
    is_free boolean DEFAULT false,
    free_quantity integer DEFAULT 0,
    is_custom boolean DEFAULT false,
    amount_per_unit numeric DEFAULT 0,
    unit_type character varying(50)
);


--
-- Name: quotation_header_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotation_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotation_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotation_header (
    id bigint DEFAULT nextval('public.quotation_header_id_seq'::regclass) NOT NULL,
    customer_id bigint,
    status character varying(50),
    total_value numeric(12,2),
    total_item integer,
    total_weight numeric(10,2),
    currency character varying(10),
    sender_name character varying(255),
    sender_phone character varying(50),
    sender_email character varying(255),
    sender_address text,
    sender_city character varying(255),
    sender_postal_code character varying(50),
    sender_country character varying(100),
    cancelled_by character varying(50),
    cancelled_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone,
    note character varying(255),
    discount numeric(12,2),
    user_id bigint,
    tax_percentage numeric(5,2),
    tax text,
    time_period integer,
    full_amount numeric(12,2),
    discount_type character varying(50),
    merchant_id integer,
    recipent_note text,
    quotation_date date,
    quotation_link text,
    discount_id integer,
    invoice_id integer
);


--
-- Name: raw_material; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.raw_material (
    id integer NOT NULL,
    name text,
    weight numeric,
    reorder_level integer,
    measurement_unit integer,
    status text
);


--
-- Name: raw_material_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.raw_material_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: raw_material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.raw_material_id_seq OWNED BY public.raw_material.id;


--
-- Name: reasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reasons (
    reason_id integer NOT NULL,
    reason_type character varying(100) NOT NULL,
    reason_detail character varying(250),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT reasons_reason_type_check CHECK (((reason_type)::text = ANY (ARRAY[('cancel'::character varying)::text, ('return'::character varying)::text, ('reschedule'::character varying)::text])))
);


--
-- Name: reasons_reason_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reasons_reason_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reasons_reason_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reasons_reason_id_seq OWNED BY public.reasons.reason_id;


--
-- Name: recipe; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe (
    id integer NOT NULL,
    product_id integer,
    variant_id integer,
    raw_id integer,
    quantity numeric,
    measurement_unit integer,
    by integer,
    date timestamp without time zone,
    status text
);


--
-- Name: recipe_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recipe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recipe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recipe_id_seq OWNED BY public.recipe.id;


--
-- Name: reorder_level_removed_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reorder_level_removed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reorder_level_removed; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reorder_level_removed (
    id integer DEFAULT nextval('public.reorder_level_removed_id_seq'::regclass) NOT NULL,
    product_id integer NOT NULL,
    variant_id integer NOT NULL,
    outlet_id integer NOT NULL,
    reorder_level integer NOT NULL,
    reorder_level_reached_days integer,
    current_stock integer NOT NULL,
    last_ordered_date date,
    last_ordered_quantity integer,
    action character varying(255),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: reorder_level_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reorder_level_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reorder_level_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reorder_level_id_seq OWNED BY public.reorder_level_removed.id;


--
-- Name: reorder_level; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reorder_level (
    id integer DEFAULT nextval('public.reorder_level_id_seq'::regclass) NOT NULL,
    product_id integer NOT NULL,
    variant_id integer NOT NULL,
    outlet_id integer NOT NULL,
    reorder_level integer NOT NULL,
    reorder_level_reached_days integer,
    current_stock integer NOT NULL,
    last_ordered_date date,
    last_ordered_quantity integer,
    action character varying(255),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: restaurant_tables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_tables (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    table_id character varying(50),
    note text,
    seats integer DEFAULT 1 NOT NULL,
    outlet_id integer NOT NULL,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT restaurant_tables_status_check CHECK (((status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Inactive'::character varying)::text])))
);


--
-- Name: restaurant_tables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_tables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_tables_id_seq OWNED BY public.restaurant_tables.id;


--
-- Name: return_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_token (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT now(),
    by integer,
    amount numeric,
    old_inv_id integer,
    used_amount numeric DEFAULT 0,
    used_inv_id jsonb,
    status text DEFAULT 'active'::text,
    returned_items jsonb,
    comment text,
    type text DEFAULT 'token'::text
);


--
-- Name: return_token_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.return_token_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: return_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.return_token_id_seq OWNED BY public.return_token.id;


--
-- Name: role_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_list (
    id integer NOT NULL,
    role_name character varying(255) NOT NULL,
    date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'active'::character varying,
    privileges text[] NOT NULL,
    dashboard_access text[] DEFAULT ARRAY[]::text[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    user_id integer,
    portal_interface integer
);


--
-- Name: role_list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_list_id_seq OWNED BY public.role_list.id;


--
-- Name: sales_channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_channel (
    id integer NOT NULL,
    sales_name text,
    outlet_id integer,
    comment text,
    added_by integer,
    type text,
    login_url text,
    store_domain text,
    merchant_id integer,
    template_id integer,
    updated_at timestamp without time zone
);


--
-- Name: sales_channel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_channel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_channel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_channel_id_seq OWNED BY public.sales_channel.id;


--
-- Name: send_email_temp_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.send_email_temp_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: send_email_temp_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.send_email_temp_log (
    id integer DEFAULT nextval('public.send_email_temp_log_id_seq'::regclass) NOT NULL,
    email character varying(255),
    msg text,
    status character varying(255) DEFAULT 'Pending'::character varying NOT NULL,
    date timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    sentdate character varying(255),
    batche_id integer,
    action character varying(255),
    subject character varying(255)
);


--
-- Name: send_sms_temp_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.send_sms_temp_log (
    id integer NOT NULL,
    mobileno character varying(255) COLLATE pg_catalog."C",
    msg text COLLATE pg_catalog."C",
    status character varying(255) DEFAULT 'Pending'::character varying NOT NULL COLLATE pg_catalog."C",
    date timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    sentdate character varying(255) COLLATE pg_catalog."C",
    batche_id integer,
    action character varying(255)
);


--
-- Name: send_sms_temp_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.send_sms_temp_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: send_sms_temp_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.send_sms_temp_log_id_seq OWNED BY public.send_sms_temp_log.id;


--
-- Name: shift_roster; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shift_roster (
    roster_id integer NOT NULL,
    employee_id integer NOT NULL,
    shift_id integer NOT NULL,
    roster_date date NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: shift_roster_roster_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shift_roster_roster_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shift_roster_roster_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shift_roster_roster_id_seq OWNED BY public.shift_roster.roster_id;


--
-- Name: shifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shifts (
    id integer NOT NULL,
    shift_name character varying(255) NOT NULL,
    weekday character varying(20) NOT NULL,
    shift_in_time time without time zone NOT NULL,
    shift_out_time time without time zone NOT NULL,
    grace_period_minutes integer DEFAULT 15,
    early_ot_minutes integer DEFAULT 30,
    after_ot_minutes integer DEFAULT 60,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    max_ot_minutes integer DEFAULT 0,
    holiday_ot_minutes integer DEFAULT 0
);


--
-- Name: shifts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shifts_id_seq OWNED BY public.shifts.id;


--
-- Name: shopping_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_list (
    id integer NOT NULL,
    production_id integer,
    ingredient_id integer,
    quantity numeric,
    unit integer,
    date timestamp without time zone DEFAULT now()
);


--
-- Name: shopping_list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shopping_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shopping_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shopping_list_id_seq OWNED BY public.shopping_list.id;


--
-- Name: site_section_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_section_configs (
    id bigint NOT NULL,
    merchant_id integer NOT NULL,
    template_id integer NOT NULL,
    template_section_id integer NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_section_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_section_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_section_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_section_configs_id_seq OWNED BY public.site_section_configs.id;


--
-- Name: sms_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_action (
    id integer NOT NULL,
    name character varying(255),
    status character varying(255) DEFAULT 'Active'::character varying
);


--
-- Name: sms_action_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_action_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_action_id_seq OWNED BY public.sms_action.id;


--
-- Name: sms_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_template (
    id integer NOT NULL,
    msg text,
    action integer,
    admin character varying(255),
    client character varying(255),
    "user" character varying(255),
    status character varying(255) DEFAULT 'Active'::character varying,
    addby integer,
    createddate character varying(255),
    updateddate timestamp without time zone DEFAULT now(),
    employee character varying(10) DEFAULT ''::character varying
);


--
-- Name: sms_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_template_id_seq OWNED BY public.sms_template.id;


--
-- Name: stock_sheet_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_sheet_details (
    sheet_details_id integer NOT NULL,
    sheet_id integer NOT NULL,
    product_id integer NOT NULL,
    variant_id integer NOT NULL,
    previous_stock integer DEFAULT 0 NOT NULL,
    current_stock integer DEFAULT 0 NOT NULL,
    changed_qty integer NOT NULL,
    sku character varying(50),
    batch_number character varying(50),
    barcode character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: stock_sheet_details_sheet_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_sheet_details_sheet_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_sheet_details_sheet_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_sheet_details_sheet_details_id_seq OWNED BY public.stock_sheet_details.sheet_details_id;


--
-- Name: stock_sheet_header; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_sheet_header (
    sheet_id integer NOT NULL,
    user_id integer NOT NULL,
    stock_type character varying(50) NOT NULL,
    remark text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    outlet_id integer
);


--
-- Name: stock_sheet_header_sheet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_sheet_header_sheet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_sheet_header_sheet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_sheet_header_sheet_id_seq OWNED BY public.stock_sheet_header.sheet_id;


--
-- Name: supplier_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_payments (
    payment_id integer NOT NULL,
    paid_amount numeric(14,2) NOT NULL,
    po_id integer NOT NULL,
    supplier_id integer NOT NULL,
    payment_note text,
    slip_url text,
    voucher_id character varying(100),
    status character varying(50) DEFAULT 'PENDING'::character varying,
    grn_id integer,
    po_amount numeric(14,2),
    due_amount numeric(14,2),
    by_user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: supplier_payments_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplier_payments_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplier_payments_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplier_payments_payment_id_seq OWNED BY public.supplier_payments.payment_id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    supplier_id bigint NOT NULL,
    business_name text NOT NULL,
    address text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    responsible_person text,
    mobile_no text,
    contact_no text,
    email text,
    credit_limit numeric(14,2) DEFAULT 0,
    credit numeric(14,2) DEFAULT 0,
    reg_date date DEFAULT CURRENT_DATE,
    reg_by bigint,
    account_no text,
    bank text,
    branch text,
    acc_holders_name text,
    country text,
    city text,
    note text,
    CONSTRAINT suppliers_credit_check CHECK ((credit >= (0)::numeric)),
    CONSTRAINT suppliers_credit_limit_check CHECK ((credit_limit >= (0)::numeric)),
    CONSTRAINT suppliers_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text])))
);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_supplier_id_seq OWNED BY public.suppliers.supplier_id;


--
-- Name: system_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_log (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT timezone('Asia/Colombo'::text, now()) NOT NULL,
    module text NOT NULL,
    log text NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: system_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.system_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.system_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    default_timezone character varying(100),
    date_format character varying(20),
    currency character varying(100),
    auto_logout_time interval,
    sms_gateway_name character varying(100),
    sms_user_id character varying(50),
    sms_sender_id character varying(100),
    sms_api_endpoint text,
    sms_api_key text,
    sms_notification_status public.status_enum,
    billing_email character varying(255),
    system_email character varying(255),
    support_email character varying(255),
    email_notification_status public.status_enum,
    postmark_server_token text,
    smtp_host character varying(255),
    smtp_port integer,
    smtp_username character varying(255),
    smtp_password text,
    smtp_encryption character varying(10),
    new_client_sms_status public.status_enum DEFAULT 'inactive'::public.status_enum,
    new_client_email_status public.status_enum DEFAULT 'inactive'::public.status_enum,
    new_client_activation_sms_status public.status_enum DEFAULT 'inactive'::public.status_enum,
    new_client_activation_email_status public.status_enum DEFAULT 'inactive'::public.status_enum,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    backoffice_maintenance_status public.status_enum DEFAULT 'disabled'::public.status_enum,
    backoffice_maintenance_msg text,
    webstore_maintenance_status public.status_enum DEFAULT 'disabled'::public.status_enum,
    pos_maintenance_status public.status_enum DEFAULT 'disabled'::public.status_enum,
    pos_maintenance_msg text,
    full_maintenance_status public.status_enum DEFAULT 'disabled'::public.status_enum,
    full_maintenance_msg text,
    sell_international boolean DEFAULT false,
    tax boolean DEFAULT false,
    tax_value jsonb,
    tax_on_web boolean DEFAULT false,
    default_country character varying(100),
    enabled_google boolean DEFAULT false,
    google_mode text DEFAULT 'gtm'::text,
    gtm_container_id text,
    ga4_measurement_id text,
    enabled_meta boolean DEFAULT false,
    meta_pixel_id text,
    meta_capi_enabled boolean DEFAULT false,
    meta_capi_access_token text,
    terms_conditions text DEFAULT ''::text,
    enabled_google_tag boolean DEFAULT false,
    admin_alert_sms_status public.status_enum DEFAULT 'inactive'::public.status_enum NOT NULL,
    admin_alert_email_status public.status_enum DEFAULT 'inactive'::public.status_enum NOT NULL,
    notification_mobile_numbers text[] DEFAULT '{}'::text[] NOT NULL,
    notification_emails text[] DEFAULT '{}'::text[] NOT NULL,
    webstore_maintenance_msg text,
    suspend_status boolean DEFAULT false,
    suspend_reason text,
    billing_pay_status text,
    suspend_date date,
    loyalty_point boolean DEFAULT false,
    points_given numeric(10,2) DEFAULT 0,
    amount_spend numeric(10,2) DEFAULT 0,
    field_config jsonb DEFAULT '{}'::jsonb,
    terms_conditions_quotations text,
    time_period integer,
    time_period_enabled boolean DEFAULT false,
    inventory_strategy_id integer,
    s3_region text,
    s3_endpoint text,
    s3_access_key text,
    s3_secret_key text,
    s3_bucket_name text,
    s3_public_key text,
    billing_client_id integer,
    billing_servise_id integer,
    billing_pid text,
    billing_base_url text,
    CONSTRAINT system_settings_google_mode_check CHECK ((google_mode = ANY (ARRAY['gtm'::text, 'ga4'::text])))
);


--
-- Name: system_settings_billing_servise_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_billing_servise_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_billing_servise_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_billing_servise_id_seq OWNED BY public.system_settings.billing_servise_id;


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: table_management; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_management (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    chairs integer NOT NULL,
    assignto bigint,
    ongoing_status character varying(20) DEFAULT 'Inactive'::character varying NOT NULL,
    session_start_time timestamp without time zone,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT table_management_chairs_check CHECK ((chairs > 0)),
    CONSTRAINT table_management_ongoing_status_check CHECK (((ongoing_status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Inactive'::character varying)::text]))),
    CONSTRAINT table_management_status_check CHECK (((status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Inactive'::character varying)::text])))
);


--
-- Name: table_management_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_management_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_management_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_management_id_seq OWNED BY public.table_management.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    tag_id integer NOT NULL,
    name character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    merchant_id integer,
    CONSTRAINT tags_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: tags_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_tag_id_seq OWNED BY public.tags.tag_id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    transaction_id bigint NOT NULL,
    transaction_type character varying(20) NOT NULL,
    category_id bigint NOT NULL,
    account_id bigint NOT NULL,
    transaction_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    transaction_fee numeric(15,2) DEFAULT 0,
    note character varying(250),
    by bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(10) DEFAULT 'active'::character varying NOT NULL,
    reference_id bigint,
    payer_payee_id bigint,
    payment_status character varying(20),
    file_url text,
    outlet_id integer,
    CONSTRAINT transactions_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT transactions_payment_status_check CHECK (((payment_status)::text = ANY (ARRAY[('approved'::character varying)::text, ('rejected'::character varying)::text, ('pending'::character varying)::text]))),
    CONSTRAINT transactions_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text]))),
    CONSTRAINT transactions_transaction_fee_check CHECK ((transaction_fee >= (0)::numeric)),
    CONSTRAINT transactions_transaction_type_check CHECK (((transaction_type)::text = ANY (ARRAY[('income'::character varying)::text, ('expense'::character varying)::text, ('transfer'::character varying)::text])))
);


--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_transaction_id_seq OWNED BY public.transactions.transaction_id;


--
-- Name: uimenudata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uimenudata (
    id integer NOT NULL,
    parent_id integer,
    name character varying(255) NOT NULL,
    route character varying(255) NOT NULL,
    icon character varying(255),
    sidebar_order numeric,
    show boolean DEFAULT false,
    package_show boolean DEFAULT true
);


--
-- Name: uimenudata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uimenudata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uimenudata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uimenudata_id_seq OWNED BY public.uimenudata.id;


--
-- Name: user_backup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_backup (
    user_id uuid DEFAULT gen_random_uuid() NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    username character varying(100) NOT NULL,
    password text NOT NULL,
    mobile character varying(15),
    role_id integer NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    email character varying(150),
    outlet_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    merchant_id_int integer
);


--
-- Name: variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.variants (
    id integer NOT NULL,
    option_name character varying(255) NOT NULL,
    "values" text[] NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    CONSTRAINT variants_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.variants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.variants_id_seq OWNED BY public.variants.id;


--
-- Name: voucher_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.voucher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: voucher; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.voucher (
    id integer DEFAULT nextval('public.voucher_id_seq'::regclass) NOT NULL,
    date timestamp without time zone DEFAULT now(),
    by integer,
    amount numeric,
    used_amount numeric DEFAULT 0,
    used_inv_id jsonb,
    status text DEFAULT 'active'::text,
    voucher_id text NOT NULL
);


--
-- Name: waybills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waybills (
    waybill_id integer NOT NULL,
    d_partner_id integer,
    waybill character varying(100) NOT NULL,
    status character varying(50),
    order_id integer,
    upload_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    import_by integer,
    customer_id integer,
    CONSTRAINT waybills_status_check CHECK (((status)::text = ANY (ARRAY[('use'::character varying)::text, ('unuse'::character varying)::text])))
);


--
-- Name: waybills_waybill_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.waybills_waybill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: waybills_waybill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.waybills_waybill_id_seq OWNED BY public.waybills.waybill_id;


--
-- Name: web_page_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_page_components (
    id integer NOT NULL,
    page_id integer NOT NULL,
    component_id integer NOT NULL,
    "order" integer NOT NULL,
    props_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: web_page_components_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.web_page_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: web_page_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.web_page_components_id_seq OWNED BY public.web_page_components.id;


--
-- Name: web_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_pages (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    content_html text NOT NULL,
    is_homepage boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(12) DEFAULT 'active'::character varying
);


--
-- Name: web_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.web_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: web_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.web_pages_id_seq OWNED BY public.web_pages.id;


--
-- Name: web_template_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_template_sections (
    id integer NOT NULL,
    template_id integer,
    section_key character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    image character varying(255),
    status character varying(8) DEFAULT 'active'::character varying,
    "order" integer DEFAULT 0,
    display boolean,
    updated_at timestamp without time zone,
    config_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    ui_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    default_config jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: web_template_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.web_template_sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: web_template_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.web_template_sections_id_seq OWNED BY public.web_template_sections.id;


--
-- Name: web_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_templates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    image character varying(255),
    status character varying(8) DEFAULT 'active'::character varying NOT NULL,
    CONSTRAINT web_templates_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


--
-- Name: web_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.web_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: web_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.web_templates_id_seq OWNED BY public.web_templates.id;


--
-- Name: zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.zone (
    id integer NOT NULL,
    zone_name character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'Active'::character varying
);


--
-- Name: zone_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.zone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.zone_id_seq OWNED BY public.zone.id;


--
-- Name: account_categories category_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_categories ALTER COLUMN category_id SET DEFAULT nextval('public.account_categories_category_id_seq'::regclass);


--
-- Name: account_statement acc_statement_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_statement ALTER COLUMN acc_statement_id SET DEFAULT nextval('public.account_statement_acc_statement_id_seq'::regclass);


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: accounts_payer_payee id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payer_payee ALTER COLUMN id SET DEFAULT nextval('public.accounts_payer_payee_id_seq'::regclass);


--
-- Name: admin_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_log ALTER COLUMN id SET DEFAULT nextval('public.admin_log_id_seq'::regclass);


--
-- Name: appreciations appreciation_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appreciations ALTER COLUMN appreciation_id SET DEFAULT nextval('public.appreciations_appreciation_id_seq'::regclass);


--
-- Name: attendance attendance_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance ALTER COLUMN attendance_id SET DEFAULT nextval('public.attendance_attendance_id_seq'::regclass);


--
-- Name: attendance_status status_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_status ALTER COLUMN status_id SET DEFAULT nextval('public.attendance_status_status_id_seq'::regclass);


--
-- Name: batch_management batch_management_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_management ALTER COLUMN batch_management_id SET DEFAULT nextval('public.batch_management_batch_management_id_seq'::regclass);


--
-- Name: branch branch_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branch ALTER COLUMN branch_id SET DEFAULT nextval('public.branch_branch_id_seq'::regclass);


--
-- Name: brand brand_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand ALTER COLUMN brand_id SET DEFAULT nextval('public.brand_brand_id_seq'::regclass);


--
-- Name: branding_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_settings ALTER COLUMN id SET DEFAULT nextval('public.branding_settings_id_seq'::regclass);


--
-- Name: bulk_dispatched_history bulk_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_dispatched_history ALTER COLUMN bulk_id SET DEFAULT nextval('public.bulk_dispatched_history_bulk_id_seq'::regclass);


--
-- Name: card_terminal id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_terminal ALTER COLUMN id SET DEFAULT nextval('public.card_terminal_id_seq'::regclass);


--
-- Name: card_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_types ALTER COLUMN id SET DEFAULT nextval('public.card_types_id_seq'::regclass);


--
-- Name: categories category_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN category_id SET DEFAULT nextval('public.categories_category_id_seq'::regclass);


--
-- Name: collections collection_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections ALTER COLUMN collection_id SET DEFAULT nextval('public.collections_collection_id_seq'::regclass);


--
-- Name: components id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.components ALTER COLUMN id SET DEFAULT nextval('public.components_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: credit_card_transaction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_card_transaction ALTER COLUMN id SET DEFAULT nextval('public.credit_card_transaction_id_seq'::regclass);


--
-- Name: dashboard_widgets widget_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets ALTER COLUMN widget_id SET DEFAULT nextval('public.dashboard_widgets_widget_id_seq'::regclass);


--
-- Name: delivery_fee id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_fee ALTER COLUMN id SET DEFAULT nextval('public.delivery_fee_id_seq'::regclass);


--
-- Name: delivery_partners partner_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_partners ALTER COLUMN partner_id SET DEFAULT nextval('public.delivery_partners_partner_id_seq'::regclass);


--
-- Name: discount_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_usage ALTER COLUMN id SET DEFAULT nextval('public.discount_usage_id_seq'::regclass);


--
-- Name: discounts discount_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discounts ALTER COLUMN discount_id SET DEFAULT nextval('public.discounts_discount_id_seq'::regclass);


--
-- Name: earnings_deductions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earnings_deductions ALTER COLUMN id SET DEFAULT nextval('public.earnings_deductions_id_seq'::regclass);


--
-- Name: email_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_template ALTER COLUMN id SET DEFAULT nextval('public.email_template_id_seq'::regclass);


--
-- Name: employee_documents document_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents ALTER COLUMN document_id SET DEFAULT nextval('public.employee_documents_document_id_seq'::regclass);


--
-- Name: employee_logs log_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_logs ALTER COLUMN log_id SET DEFAULT nextval('public.employee_logs_log_id_seq'::regclass);


--
-- Name: employee_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_profiles ALTER COLUMN id SET DEFAULT nextval('public.employee_profiles_id_seq'::regclass);


--
-- Name: employee_remarks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_remarks ALTER COLUMN id SET DEFAULT nextval('public.employee_remarks_id_seq'::regclass);


--
-- Name: employees employee_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN employee_id SET DEFAULT nextval('public.employees_employee_id_seq'::regclass);


--
-- Name: employment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employment ALTER COLUMN id SET DEFAULT nextval('public.employment_id_seq'::regclass);


--
-- Name: farder_webhook_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farder_webhook_logs ALTER COLUMN id SET DEFAULT nextval('public.farder_webhook_logs_id_seq'::regclass);


--
-- Name: grn_header grn_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_header ALTER COLUMN grn_id SET DEFAULT nextval('public.grn_header_grn_id_seq'::regclass);


--
-- Name: grn_items grn_item_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items ALTER COLUMN grn_item_id SET DEFAULT nextval('public.grn_items_grn_item_id_seq'::regclass);


--
-- Name: hero_section id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_section ALTER COLUMN id SET DEFAULT nextval('public.hero_section_id_seq'::regclass);


--
-- Name: holidays holiday_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.holidays ALTER COLUMN holiday_id SET DEFAULT nextval('public.holidays_holiday_id_seq'::regclass);


--
-- Name: increments_and_promotions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.increments_and_promotions ALTER COLUMN id SET DEFAULT nextval('public.increments_and_promotions_id_seq'::regclass);


--
-- Name: ingredients_stock_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_stock_details ALTER COLUMN id SET DEFAULT nextval('public.ingredients_stock_details_id_seq'::regclass);


--
-- Name: inventory inventory_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory ALTER COLUMN inventory_id SET DEFAULT nextval('public.inventory_inventory_id_seq'::regclass);


--
-- Name: inventory_strategy inventory_strategy_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_strategy ALTER COLUMN inventory_strategy_id SET DEFAULT nextval('public.inventory_strategy_inventory_strategy_id_seq'::regclass);


--
-- Name: invoice_payment_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payment_history ALTER COLUMN id SET DEFAULT nextval('public.invoice_payment_history_id_seq'::regclass);


--
-- Name: job_bill_item id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_bill_item ALTER COLUMN id SET DEFAULT nextval('public.job_bill_item_id_seq'::regclass);


--
-- Name: job_log log_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_log ALTER COLUMN log_id SET DEFAULT nextval('public.job_log_log_id_seq'::regclass);


--
-- Name: job_other_service id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_other_service ALTER COLUMN id SET DEFAULT nextval('public.job_other_service_id_seq'::regclass);


--
-- Name: kitchen id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kitchen ALTER COLUMN id SET DEFAULT nextval('public.kitchen_id_seq'::regclass);


--
-- Name: kitchen_order_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kitchen_order_lines ALTER COLUMN id SET DEFAULT nextval('public.kitchen_order_lines_id_seq'::regclass);


--
-- Name: kitchen_order_lines_header id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kitchen_order_lines_header ALTER COLUMN id SET DEFAULT nextval('public.kitchen_order_lines_header_id_seq'::regclass);


--
-- Name: leave_types leave_type_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types ALTER COLUMN leave_type_id SET DEFAULT nextval('public.leave_types_leave_type_id_seq'::regclass);


--
-- Name: leaves leave_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leaves ALTER COLUMN leave_id SET DEFAULT nextval('public.leaves_leave_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: material_inventory id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_inventory ALTER COLUMN id SET DEFAULT nextval('public.material_inventory_id_seq'::regclass);


--
-- Name: measurements measurement_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.measurements ALTER COLUMN measurement_id SET DEFAULT nextval('public.measurements_measurement_id_seq'::regclass);


--
-- Name: notifications notification_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN notification_id SET DEFAULT nextval('public.notifications_notification_id_seq'::regclass);


--
-- Name: order_bulk_prints bulk_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_bulk_prints ALTER COLUMN bulk_id SET DEFAULT nextval('public.order_bulk_prints_bulk_id_seq'::regclass);


--
-- Name: order_items order_item_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN order_item_id SET DEFAULT nextval('public.order_items_order_item_id_seq'::regclass);


--
-- Name: orders order_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN order_id SET DEFAULT nextval('public.orders_order_id_seq'::regclass);


--
-- Name: outlets outlet_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outlets ALTER COLUMN outlet_id SET DEFAULT nextval('public.outlets_outlet_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: payment_methods payment_method_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN payment_method_id SET DEFAULT nextval('public.payment_methods_payment_method_id_seq'::regclass);


--
-- Name: payroll_template_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_template_details ALTER COLUMN id SET DEFAULT nextval('public.payroll_template_details_id_seq'::regclass);


--
-- Name: payroll_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_templates ALTER COLUMN id SET DEFAULT nextval('public.payroll_templates_id_seq'::regclass);


--
-- Name: paysheet_details paysheet_detail_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_details ALTER COLUMN paysheet_detail_id SET DEFAULT nextval('public.paysheet_details_paysheet_detail_id_seq'::regclass);


--
-- Name: paysheet_invoices paysheet_invoice_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_invoices ALTER COLUMN paysheet_invoice_id SET DEFAULT nextval('public.paysheet_invoices_paysheet_invoice_id_seq'::regclass);


--
-- Name: paysheets paysheet_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheets ALTER COLUMN paysheet_id SET DEFAULT nextval('public.paysheets_paysheet_id_seq'::regclass);


--
-- Name: pick_from_client id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pick_from_client ALTER COLUMN id SET DEFAULT nextval('public.pick_from_client_id_seq'::regclass);


--
-- Name: plugins plugin_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins ALTER COLUMN plugin_id SET DEFAULT nextval('public.plugins_plugin_id_seq'::regclass);


--
-- Name: po_items po_item_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_items ALTER COLUMN po_item_id SET DEFAULT nextval('public.po_items_po_item_id_seq'::regclass);


--
-- Name: points_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_logs ALTER COLUMN id SET DEFAULT nextval('public.points_logs_id_seq'::regclass);


--
-- Name: portal_interface interface_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_interface ALTER COLUMN interface_id SET DEFAULT nextval('public.portal_interface_interface_id_seq'::regclass);


--
-- Name: prn_header prn_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_header ALTER COLUMN prn_id SET DEFAULT nextval('public.prn_header_prn_id_seq'::regclass);


--
-- Name: prn_items prn_item_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_items ALTER COLUMN prn_item_id SET DEFAULT nextval('public.prn_items_prn_item_id_seq'::regclass);


--
-- Name: product_media media_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_media ALTER COLUMN media_id SET DEFAULT nextval('public.product_media_media_id_seq'::regclass);


--
-- Name: product_reviews review_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews ALTER COLUMN review_id SET DEFAULT nextval('public.product_reviews_review_id_seq'::regclass);


--
-- Name: production_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_details ALTER COLUMN id SET DEFAULT nextval('public.production_details_id_seq'::regclass);


--
-- Name: production_details_product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_details_product ALTER COLUMN id SET DEFAULT nextval('public.production_details_product_id_seq'::regclass);


--
-- Name: production_header id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_header ALTER COLUMN id SET DEFAULT nextval('public.production_header_id_seq'::regclass);


--
-- Name: raw_material id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.raw_material ALTER COLUMN id SET DEFAULT nextval('public.raw_material_id_seq'::regclass);


--
-- Name: reasons reason_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reasons ALTER COLUMN reason_id SET DEFAULT nextval('public.reasons_reason_id_seq'::regclass);


--
-- Name: recipe id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe ALTER COLUMN id SET DEFAULT nextval('public.recipe_id_seq'::regclass);


--
-- Name: restaurant_tables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_tables ALTER COLUMN id SET DEFAULT nextval('public.restaurant_tables_id_seq'::regclass);


--
-- Name: return_token id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_token ALTER COLUMN id SET DEFAULT nextval('public.return_token_id_seq'::regclass);


--
-- Name: role_list id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_list ALTER COLUMN id SET DEFAULT nextval('public.role_list_id_seq'::regclass);


--
-- Name: sales_channel id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_channel ALTER COLUMN id SET DEFAULT nextval('public.sales_channel_id_seq'::regclass);


--
-- Name: send_sms_temp_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.send_sms_temp_log ALTER COLUMN id SET DEFAULT nextval('public.send_sms_temp_log_id_seq'::regclass);


--
-- Name: shift_roster roster_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_roster ALTER COLUMN roster_id SET DEFAULT nextval('public.shift_roster_roster_id_seq'::regclass);


--
-- Name: shifts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shifts ALTER COLUMN id SET DEFAULT nextval('public.shifts_id_seq'::regclass);


--
-- Name: shopping_list id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list ALTER COLUMN id SET DEFAULT nextval('public.shopping_list_id_seq'::regclass);


--
-- Name: site_section_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_section_configs ALTER COLUMN id SET DEFAULT nextval('public.site_section_configs_id_seq'::regclass);


--
-- Name: sms_action id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_action ALTER COLUMN id SET DEFAULT nextval('public.sms_action_id_seq'::regclass);


--
-- Name: sms_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_template ALTER COLUMN id SET DEFAULT nextval('public.sms_template_id_seq'::regclass);


--
-- Name: stock_sheet_details sheet_details_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_details ALTER COLUMN sheet_details_id SET DEFAULT nextval('public.stock_sheet_details_sheet_details_id_seq'::regclass);


--
-- Name: stock_sheet_header sheet_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_header ALTER COLUMN sheet_id SET DEFAULT nextval('public.stock_sheet_header_sheet_id_seq'::regclass);


--
-- Name: supplier_payments payment_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments ALTER COLUMN payment_id SET DEFAULT nextval('public.supplier_payments_payment_id_seq'::regclass);


--
-- Name: suppliers supplier_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN supplier_id SET DEFAULT nextval('public.suppliers_supplier_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: system_settings billing_servise_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN billing_servise_id SET DEFAULT nextval('public.system_settings_billing_servise_id_seq'::regclass);


--
-- Name: table_management id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_management ALTER COLUMN id SET DEFAULT nextval('public.table_management_id_seq'::regclass);


--
-- Name: tags tag_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN tag_id SET DEFAULT nextval('public.tags_tag_id_seq'::regclass);


--
-- Name: transactions transaction_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN transaction_id SET DEFAULT nextval('public.transactions_transaction_id_seq'::regclass);


--
-- Name: uimenudata id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uimenudata ALTER COLUMN id SET DEFAULT nextval('public.uimenudata_id_seq'::regclass);


--
-- Name: variants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variants ALTER COLUMN id SET DEFAULT nextval('public.variants_id_seq'::regclass);


--
-- Name: waybills waybill_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills ALTER COLUMN waybill_id SET DEFAULT nextval('public.waybills_waybill_id_seq'::regclass);


--
-- Name: web_page_components id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_components ALTER COLUMN id SET DEFAULT nextval('public.web_page_components_id_seq'::regclass);


--
-- Name: web_pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_pages ALTER COLUMN id SET DEFAULT nextval('public.web_pages_id_seq'::regclass);


--
-- Name: web_template_sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_template_sections ALTER COLUMN id SET DEFAULT nextval('public.web_template_sections_id_seq'::regclass);


--
-- Name: web_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_templates ALTER COLUMN id SET DEFAULT nextval('public.web_templates_id_seq'::regclass);


--
-- Name: zone id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zone ALTER COLUMN id SET DEFAULT nextval('public.zone_id_seq'::regclass);


--
-- Data for Name: account_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_categories (category_id, name, note, status, created_at, updated_at, created_by, is_default) FROM stdin;
1	Sales Income	all sales income	active	2026-03-02 04:17:41.613177	2026-03-02 04:17:41.613177	1	t
2	Web Sales	All liability accounts	active	2026-03-02 04:17:41.613177	2026-03-12 11:47:17.068913	1	t
3	Employee Salary	Employee Salary category	active	2026-03-02 04:17:41.613177	2026-03-12 11:50:10.288947	1	t
\.


--
-- Data for Name: account_statement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_statement (acc_statement_id, account_id, transaction_type, amount, reference, by, prev_balance, balance, status, created_at, updated_at, payer_payee) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, date, by, name, type, p_method_id, description, status, balance, outlet_id, bank_account, updated_at, is_default) FROM stdin;
4	2025-12-17 08:41:27.116109	1	Main Stripe	online	2	Default Stripe payment account	active	0	1	f	2026-04-06 16:03:40.175874	t
1	2025-12-17 08:41:27.116109	1	Main Cash	offline	5	Default cash account	active	0	1	f	2026-04-06 16:03:40.175874	t
2	2025-12-17 08:41:27.116109	1	Main COD	offline	3	Default cash on delivery account	active	0	1	f	2026-04-06 16:03:40.175874	t
5	2025-12-17 08:41:27.116109	1	Main PayHere	online	1	Default PayHere payment account	active	0	1	f	2026-04-06 16:03:40.175874	t
3	2025-12-17 08:41:27.116109	1	Main Bank Transfer	offline	4	Default bank transfer account	active	0	1	t	2026-04-06 16:04:16.800685	t
\.


--
-- Data for Name: accounts_payer_payee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts_payer_payee (id, name, type, add_by, created_at, status, is_default) FROM stdin;
1	POS Client	payer	1	2026-04-06 16:57:54.765065	active	t
\.


--
-- Data for Name: admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_log (id, date, module, log, user_id) FROM stdin;
\.


--
-- Data for Name: appreciations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appreciations (appreciation_id, employee_id, subject, description, created_at) FROM stdin;
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance (attendance_id, employee_id, name, check_in_date, clock_in_time, clock_out_time, log_source, created_at, shift_id, roster_id, attendance_status_id, attendance_note, check_out_date) FROM stdin;
\.


--
-- Data for Name: attendance_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_status (status_id, holiday_id, day_off, present, halfday, late, absent, leave_id, created_at, updated_at, holiday_name) FROM stdin;
\.


--
-- Data for Name: batch_management; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_management (batch_management_id, product_id, variant_id, batch_number, created_at, cost_price, selling_price, expiry_date, manufacture_date, supplier_id, status, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branch (branch_id, branch_name) FROM stdin;
\.


--
-- Data for Name: brand; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brand (brand_id, name, logo_url, logo_tile_url, brand_tagline, status, description, website_url, seo_title, seo_meta_desc, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: branding_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branding_settings (id, company_name, logo_url, favicon_url, app_icon_android, app_icon_ios, slogan, primary_color, secondary_color, title_color, subtitle_color, text_color, button_primary_color, button_secondary_color, button_success_color, button_warning_color, button_danger_color, font_family, font_size, background_color, border_radius, box_shadow, hotline, customer_support_phone, address_1, website_url, facebook_url, twitter_url, instagram_url, linkedin_url, youtube_url, support_email, info_email, billing_email, terms_url, privacy_url, copyright_text, seo_meta_title, seo_meta_description, seo_meta_keywords, footer_text, created_at, updated_at, logo_url_white, logo_name_dark, logo_name_white, address_2, client_portal_url, admin_portal_url, api_url, geocode, google_clientid, copyright_link, white_label, hover_color, tiktok_url, welcome_image, footer_color, seo_image) FROM stdin;
1	testcompany1	https://d8y1.c2.e2-9.dev/ozonefiles/1754556664325-20250807085104-logo_url.png	https://d8y1.c2.e2-9.dev/ozonefiles/1754556703058-20250807085143-favicon_url.png	https://d8y1.c2.e2-9.dev/ozonefiles/1748071396072-20250524072316-app_icon_android.png	https://d8y1.c2.e2-9.dev/ozonefiles/1748071412036-20250524072332-app_icon_ios.png	test	#413e3e	#707070	#9500b3	#31039b	#b60707	#c70a0a	#858585	#22c55e	#ebac00	#c70a0a	Segoe UI,Frutiger,Frutiger Linotype,Dejavu Sans,Helvetica Neue,Arial,sans-serif	12	#f0f0f0	23	21	23142342423	2342344234234	testcompany	https://sparkglobalsolutionspvtltd.eu.teamwork.com/app/home/inbox?from=homepage	https://www.facebook.com/	https://www.x.com/	https://www.instagram.com/	https://www.linkedin.com/	https://www.youtube.com/	testcompany@gmail.com	testcompany@gmail.com	testcompany@gmail.com	https://testurl.com	https://testurl.com	sample text	ozondesk	ozondesk	ozondesk	ozondesk	2025-02-06 11:02:17.771606	2025-12-02 12:07:25.6727	https://d8y1.c2.e2-9.dev/ozonefiles/1755687106741-20250820105146-logo_url_white.png	https://d8y1.c2.e2-9.dev/ozonefiles/1755687112210-20250820105152-logo_name_dark.png	https://d8y1.c2.e2-9.dev/ozonefiles/1752230596521-20250711104316-logo_name_white.webp	testcompany	https://sparkglobalsolutionspvtltd.eu.teamwork.com/app/home/inbox?from=homepage	https://sparkglobalsolutionspvtltd.eu.teamwork.com/app/home/inbox?from=homepage	https://sparkglobalsolutionspvtltd.eu.teamwork.com/app/home/inbox?from=homepage	\N	760212008548-duregdva40vn89f5h55u8jaq451398ea.apps.googleusercontent.com	\N	f	#CCCCCC	\N	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/2025-12-02/17-30-02-welcome.png	\N	\N
\.


--
-- Data for Name: bulk_dispatched_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bulk_dispatched_history (bulk_id, generated_by, generated_at, order_count, partner_id) FROM stdin;
\.


--
-- Data for Name: card_terminal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.card_terminal (id, mac_address, ip, name, account_name, account_id, status, outlet_id) FROM stdin;
1	00:1A:2B:3C:4D:5E	192.168.1.10	Terminal 1	Main Account	1	active	1
\.


--
-- Data for Name: card_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.card_types (id, name, status) FROM stdin;
1	Master	Active
2	Visa	Active
3	Amex	Active
4	Other	Active
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (category_id, name, description, created_at, category_under, related_ui, mobile_url, desktop_url, show_on_main_menu, status, merchant_id) FROM stdin;
\.


--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections (collection_id, name, description, created_at, status, merchant_id, product_id, mobile_url, desktop_url) FROM stdin;
1	Featured	Featured products	2025-08-12 13:30:00.857776	active	20001	\N	\N	\N
2	New Arrivals	Latest arrivals	2025-08-12 13:30:00.857776	active	20001	\N	\N	\N
3	Sale	Discounted items	2025-08-12 13:30:00.857776	active	20001	\N	\N	\N
4	Best Selling	Top selling products	2025-05-30 09:57:57.566041	active	20001	\N	\N	\N
5	Special Offers	Best-selling tech gadgets and accessories9	2025-05-30 09:57:57.566041	active	20001	\N	\N	\N
\.


--
-- Data for Name: components; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.components (id, name, description, json_schema, status, created_at, updated_at) FROM stdin;
1	Navbar		{"cta": {"url": "/signup", "label": "Sign Up"}, "type": "navbar", "brand": {"logo": "/logo.png", "title": "MyShop"}, "links": [{"url": "/", "label": "Home"}, {"url": "/products", "label": "Products"}, {"url": "/contact", "label": "Contact"}], "mobileMenu": true}	active	2025-07-21 07:21:34.824331	2025-07-21 07:21:34.824331
2	Hero Section		{"slides": [{"align": "center", "title": "Welcome to Our Store!", "overlay": true, "cta_link": "/shop", "cta_text": "Shop Now", "subtitle": "Spring Collection 2025", "image_url": "https://example.com/banner1.jpg", "description": "Discover the latest trends with exclusive offers."}, {"align": "left", "title": "Free Shipping", "overlay": false, "cta_link": "/shipping-info", "cta_text": "Learn More", "subtitle": "", "image_url": "https://example.com/banner2.jpg", "description": "On all orders above $100"}], "autoplay": true, "interval": 5000}	active	2025-07-21 10:13:08.294423	2025-07-21 10:13:08.294423
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.countries (id, country_code, country_name, status) FROM stdin;
1	AF	Afghanistan	active
2	AL	Albania	active
3	DZ	Algeria	active
4	AS	American Samoa	active
5	AD	Andorra	active
6	AO	Angola	active
7	AI	Anguilla	active
8	AG	Antigua and Barbuda	active
9	AR	Argentina	active
10	AM	Armenia	active
11	AW	Aruba	active
12	AU	Australia	active
13	AT	Austria	active
14	AZ	Azerbaijan	active
15	BS	Bahamas	active
16	BH	Bahrain	active
17	BD	Bangladesh	active
18	BB	Barbados	active
19	BY	Belarus	active
20	BE	Belgium	active
21	BZ	Belize	active
22	BJ	Benin	active
23	BM	Bermuda	active
24	BT	Bhutan	active
25	BO	Bolivia	active
26	BA	Bosnia and Herzegovina	active
27	BW	Botswana	active
28	BR	Brazil	active
29	BN	Brunei Darussalam	active
30	BG	Bulgaria	active
31	BF	Burkina Faso	active
32	BI	Burundi	active
33	CV	Cabo Verde	active
34	KH	Cambodia	active
35	CM	Cameroon	active
36	CA	Canada	active
37	KY	Cayman Islands	active
38	CF	Central African Republic	active
39	TD	Chad	active
40	CL	Chile	active
41	CN	China	active
42	CO	Colombia	active
43	KM	Comoros	active
44	CG	Congo	active
45	CR	Costa Rica	active
46	HR	Croatia	active
47	CU	Cuba	active
48	CY	Cyprus	active
49	DK	Denmark	active
50	DJ	Djibouti	active
51	DM	Dominica	active
52	DO	Dominican Republic	active
53	EC	Ecuador	active
54	EG	Egypt	active
55	SV	El Salvador	active
56	GQ	Equatorial Guinea	active
57	ER	Eritrea	active
58	EE	Estonia	active
59	ET	Ethiopia	active
60	FJ	Fiji	active
61	FI	Finland	active
62	FR	France	active
63	GA	Gabon	active
64	GM	Gambia	active
65	GE	Georgia	active
66	DE	Germany	active
67	GH	Ghana	active
68	GR	Greece	active
69	GL	Greenland	active
70	GD	Grenada	active
71	GU	Guam	active
72	GT	Guatemala	active
73	GN	Guinea	active
74	GW	Guinea Bissau	active
75	GY	Guyana	active
76	HT	Haiti	active
77	HN	Honduras	active
78	HK	Hong Kong	active
79	HU	Hungary	active
80	IS	Iceland	active
81	IN	India	active
82	ID	Indonesia	active
83	IQ	Iraq	active
84	IE	Ireland	active
85	IL	Israel	active
86	IT	Italy	active
87	JM	Jamaica	active
88	JP	Japan	active
89	JO	Jordan	active
90	KZ	Kazakhstan	active
91	KE	Kenya	active
92	KI	Kiribati	active
93	KR	Korea Republic of	active
94	KW	Kuwait	active
95	KG	Kyrgyzstan	active
96	LA	Lao Peoples Democratic Republic	active
97	LV	Latvia	active
98	LB	Lebanon	active
99	LS	Lesotho	active
100	LR	Liberia	active
101	LY	Libya	active
102	LI	Liechtenstein	active
103	LT	Lithuania	active
104	LU	Luxembourg	active
105	MG	Madagascar	active
106	MW	Malawi	active
107	MY	Malaysia	active
108	MV	Maldives	active
109	ML	Mali	active
110	MT	Malta	active
111	MH	Marshall Islands	active
112	MR	Mauritania	active
113	MU	Mauritius	active
114	MX	Mexico	active
115	FM	Micronesia	active
116	MD	Moldova	active
117	MC	Monaco	active
118	MN	Mongolia	active
119	ME	Montenegro	active
120	MA	Morocco	active
121	MZ	Mozambique	active
122	MM	Myanmar	active
123	NA	Namibia	active
124	NR	Nauru	active
125	NP	Nepal	active
126	NL	Netherlands	active
127	NZ	New Zealand	active
128	NI	Nicaragua	active
129	NE	Niger	active
130	NG	Nigeria	active
131	NO	Norway	active
132	OM	Oman	active
133	PK	Pakistan	active
134	PW	Palau	active
135	PA	Panama	active
136	PG	Papua New Guinea	active
137	PY	Paraguay	active
138	PE	Peru	active
139	PH	Philippines	active
140	PL	Poland	active
141	PT	Portugal	active
142	PR	Puerto Rico	active
143	QA	Qatar	active
144	RO	Romania	active
145	RU	Russian Federation	active
146	RW	Rwanda	active
147	WS	Samoa	active
148	SM	San Marino	active
149	SA	Saudi Arabia	active
150	SN	Senegal	active
151	RS	Serbia	active
152	SC	Seychelles	active
153	SL	Sierra Leone	active
154	SG	Singapore	active
155	SK	Slovakia	active
156	SI	Slovenia	active
157	SB	Solomon Islands	active
158	SO	Somalia	active
159	ZA	South Africa	active
160	SS	South Sudan	active
161	ES	Spain	active
162	LK	Sri Lanka	active
163	SD	Sudan	active
164	SR	Suriname	active
165	SE	Sweden	active
166	CH	Switzerland	active
167	TW	Taiwan	active
168	TJ	Tajikistan	active
169	TZ	Tanzania	active
170	TH	Thailand	active
171	TG	Togo	active
172	TO	Tonga	active
173	TT	Trinidad and Tobago	active
174	TN	Tunisia	active
175	TR	Turkey	active
176	TM	Turkmenistan	active
177	TV	Tuvalu	active
178	UG	Uganda	active
179	UA	Ukraine	active
180	AE	United Arab Emirates	active
181	US	United States of America	active
182	UY	Uruguay	active
183	UZ	Uzbekistan	active
184	VU	Vanuatu	active
185	VE	Venezuela	active
186	VN	Viet Nam	active
187	YE	Yemen	active
188	ZM	Zambia	active
189	ZW	Zimbabwe	active
\.


--
-- Data for Name: credit_card_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_card_transaction (id, date, terminal_id, amount, comment, reference, card_type, invoice_id) FROM stdin;
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer (customer_id, first_name, last_name, contact_number_1, contact_number_2, address, city, postal_code, country, email, created_at, password, status, apartment, guest, picture, company_name, otp, expire_at, loyalty_point, birthday, loyality_number) FROM stdin;
\.


--
-- Data for Name: dashboard_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_widgets (widget_id, name, show, package) FROM stdin;
7	Recent Reviews	t	t
3	Delivery Insights	t	t
4	Recent Orders	t	t
6	Top Customers	t	t
8	Recent Invoices	t	t
9	Moving Report	t	t
1	Operation Overview	t	t
2	Orders Trend	t	t
5	Stock Status	t	t
10	Upcoming Leaves	t	t
\.


--
-- Data for Name: delivery_fee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delivery_fee (id, country_id, fee, additional_fee, status) FROM stdin;
1	0	300	100	active
2	162	400	200	active
\.


--
-- Data for Name: delivery_partners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delivery_partners (partner_id, name, logo, contact_number, email, address, status, tracking_url, tracking_para, tracking_api_endpoint, tracking_array, unuse_waybiils, last_use_waybill, type, react, reply, created_at, title, description, api_key, customer_id, api_status, two_way_status, two_way_url) FROM stdin;
1	Store Pickup	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/2025-11-27/13-23-47-store.png	\N	\N	\N	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enable	\N	\N
3	Koombiyo	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1751628571408-logo.png	0117886786	\N	\N	active	https://koombiyodelivery.lk/	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-07 05:49:49.758199	Sri Lankas Fastest & Largest Delivery Network	Operating in Sri Lanka since 2018. Koombiyo was originally about leveraging the sharing economy & specialize in providing innovative services to e-commerce companies. Koombiyo Delivery is offering lowest rate ever in Sri Lanka for COD or Non-COD deliveries.	45896741	3	disable	\N	\N
2	FARDER	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1751627402061-logo-light.png	0112812512	\N	\N	inactive	https://www.fdedomestic.com/#track	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-07 05:49:49.758199	Fastest & Largest Delivery Network in Sri lanka Fardar !	To be the market leader in the courier industry in Sri Lanka through customer centered operation with the largest branch network to cover every corner of the Island. Be technically advanced with a more improved computerized system and a mobile app that allows our customers track their package real time	458967	6	enable	\N	\N
4	Simple Express	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1751627453289-123.webp	0704707700	\N	\N	active	https://simpleexpress.lk/	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-07 05:49:49.758199	Fast & Reliable Deliveries Anytime, Anywhere!	At Simple Express (Pvt) Ltd, we believe in making deliveries simple, fast, and reliable. Whether youre a business owner, an online seller, or an individual sender, our mission is to provide seamless courier solutions that keep your world moving.	0xYUJUUZCc5TJXkl	501	enable	\N	\N
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (department_id, department_name, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: designations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.designations (designation_id, designation_name, department_name, status, created_at, updated_at, sick_leave, casual_leave, annual_leave, maternity_leave, paternity_leave) FROM stdin;
\.


--
-- Data for Name: device_management; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_management (device_id, till_name, status, current_user_id, display_id, device_model, type, created_at, updated_at, banner_files, enable_customer_input) FROM stdin;
1	Main Counter	Active	1	[2]	Sunmi T2 Mini	till	2026-04-06 15:18:47.147953	2026-04-06 15:18:47.147953	\N	\N
2	Main Counter Display	Active	1	[1]	Dell	display	2026-04-06 15:26:49.437368	2026-04-06 15:26:49.437368	\N	t
3	Main Kitchen	Active	1	[4]	Sunmi T2	kot_display	2026-04-06 15:28:48.405281	2026-04-06 15:28:48.405281	\N	t
4	Main Kitchen Printer	Active	1	[3]	Dell Monitor	kot_printer	2026-04-06 15:30:17.982803	2026-04-06 15:30:17.982803	\N	\N
\.


--
-- Data for Name: discount_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discount_usage (id, discount_id, order_id, user_id, used_at, is_guest, type) FROM stdin;
\.


--
-- Data for Name: discounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discounts (discount_id, main_discount_type, target_products, target_collections, target_categories, target_brands, prod_discount_method, discount_title, discount_value_type, discount_value, min_max_purchase_discount_limits, min_purchase_amount, max_discount_amount, customer_eligibility, is_guest_allowed, usage_limit_total, unlimited_usage, usage_limit_per_account, start_date, end_date, discount_code, bxgy_max_limit, order_discount_method, status, customer_buys_qty, customer_gets_qty, payment_method, created_at) FROM stdin;
\.


--
-- Data for Name: earnings_deductions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.earnings_deductions (id, name, type, status, created_by, created_date, calculation_type) FROM stdin;
\.


--
-- Data for Name: email_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_template (id, subject, msg, action, admin, client, "user", status, addby, createddate, updateddate, employee) FROM stdin;
6	Your Return Request on order has been  received to us	<p>Hi [name], your order ID [order_id] placed, has been cancelled due to [reason] . For support or reorder, Please contact [Hotline]</p><p>&nbsp;</p><p>Thank You !</p><p><span style="color: rgb(150, 160, 181);">[Webname] Team.</span></p>	6	Yes	Yes	1	Active	1	2025-11-10 04:31:43.720976+00	2025-11-28 11:15:04.583294	
5	Your order has been cancelled 	<p>Hi [name], your order [order_id] placed, has been cancelled due to [reason] . For support or reorder, Please contact [Hotline]</p><p>&nbsp;</p><p>Thank You !</p><p><span style="color: rgb(150, 160, 181);">[Webname] Team.</span></p>	5	Yes	Yes	1	Active	1	2025-11-10 04:31:08.290257+00	2025-11-28 11:15:12.74046	
4	Your order has been successfully delivered 	<p>Hi [name],</p><p>Your order has been successfully delivered. We hope you love your purchase! For any questions or feedback, please contact us via <span style="color: rgb(150, 160, 181);">[Hotline]</span></p><p><br></p><p>Thank You !</p><p><span style="color: rgb(150, 160, 181);">[Webname] Team.</span></p>	4	Yes	Yes	1	Active	1	2025-11-10 04:29:21.837704+00	2025-11-28 11:15:21.945094	
3	Your Order has been dispatched 	<p>Hi [name],</p><p>Your order ID [order_id] has been dispatched and is on its way to you.&nbsp;For any clarification please contact us via [Hotline]</p><p><br></p><p>Thank you for shopping with us !</p><p><span style="color: rgb(150, 160, 181);">[Webname] Team.</span></p>	3	Yes	Yes	1	Active	1	2025-11-10 04:28:08.998582+00	2025-11-28 11:15:40.309507	
2	Your Order has been  Confirmed & Assigned to Courier 	<p>Hi [name],</p><p>We’re excited to let you know that your order ID [order_id] has been <strong>confirmed</strong> and assigned for delivery. Thank you for choosing [Webname]. We hope you enjoy your purchase!&nbsp;For any clarification please contact us [Hotline]</p><p><br></p><p>Best regards,</p><p><span style="color: rgb(150, 160, 181);">[Webname] Team.</span></p>	2	Yes	Yes	1	Active	1	2025-11-10 04:27:00.166031+00	2025-11-28 11:15:55.609012	
1	Your Order has been placed	<p class="ql-align-justify"><span style="background-color: transparent;">Hi [name],</span></p><p><span style="background-color: transparent;">Thank you for your order! We’ve received your order and we are getting it ready for you.</span></p><p class="ql-align-justify"><span style="background-color: transparent;">You’ll get another email once your order status updates</span>. For any clarification please contact us via [Hotline]. View Your Invoice here [invoice_link] .</p><p class="ql-align-justify"><br></p><p class="ql-align-justify"><span style="background-color: transparent;">Thank you for shopping with us! </span></p><p class="ql-align-justify"><span style="color: rgb(150, 160, 181);">[Webname] Team.</span></p>	1	Yes	Yes	1	Active	1	2025-11-10 04:25:53.906035+00	2025-11-28 11:16:08.062394	
\.


--
-- Data for Name: employee_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_documents (document_id, employee_id, document_name, file_url, uploaded_by, uploaded_at) FROM stdin;
\.


--
-- Data for Name: employee_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_logs (log_id, employee_id, log_date, log_time, module, comments, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_profiles (id, employee_id, first_name, middle_name, last_name, nic, contact_no, email, date_of_birth, marital_status, gender, nationality, bank_account_no, joined_date, location, employment_status, probation_end_date, date_of_permanency, contract_start_date, contract_end_date, job_category, comments, designation_id) FROM stdin;
\.


--
-- Data for Name: employee_remarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_remarks (id, employee_id, remark, remark_date, remark_by, created_at, updated_at, remark_type) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (employee_id, first_name, middle_name, last_name, nic, contact_no, email, date_of_birth, marital_status, gender, nationality, address, city, country, bank_account_no, joined_date, job_specification, employment_status, probation_start_date, probation_end_date, date_of_permanency, contract_start_date, contract_end_date, job_category, comments, designation_id, created_at, updated_at, shift_id, payroll_template_id, mobile_number, passport_number, account_type, account_holder_name, bank_branch, department_id, special_note, outlet_id, emergency_contact_full_name, emergency_contact_address, emergency_contact_relationship, emergency_contact_mobile_no, net_salary_effective_date, salary_start_day, first_salary_strategy, salary_generation_type, salary_start_date) FROM stdin;
\.


--
-- Data for Name: employment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employment (id, name, phone, "position") FROM stdin;
\.


--
-- Data for Name: farder_webhook_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.farder_webhook_logs (id, delivery_partner_id, waybill_id, ref_url, response, created_at) FROM stdin;
\.


--
-- Data for Name: grn_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grn_header (grn_id, grn_date, po_id, supplier_id, status, total_received_qty, total_amount, remark, received_by, received_date, authorized_by, authorized_date, created_at, returned_total) FROM stdin;
\.


--
-- Data for Name: grn_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grn_items (grn_item_id, grn_id, po_item_id, product_id, variant_id, batch_number, ordered_qty, received_qty, unit_cost, created_at, po_id, returned_qty, measurement_unit, amount_per_unit, line_total) FROM stdin;
\.


--
-- Data for Name: hero_section; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hero_section (id, sub_title, title, icon, icon_title, image, text_color, bg_color, status) FROM stdin;
\.


--
-- Data for Name: holidays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.holidays (holiday_id, holiday_date, holiday_name, holiday_type, occasion, employment_status, department_ids, designation_ids, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: increments_and_promotions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.increments_and_promotions (id, employee_id, change_type, amount, note, effective_date, new_designation_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ingredients_stock_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredients_stock_details (id, sheet_id, ingredient_id, prev_stock, change_stock, current_stock, created_at) FROM stdin;
\.


--
-- Data for Name: ingredients_stock_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredients_stock_header (id, user_id, stock_type, remark, created_at, outlet_id) FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory (inventory_id, variant_id, outlet_id, updated_by, comment, system_module, previous_quantity, adjust_quantity, new_quantity, status, last_updated, merchant_id, user_id, created_at, batch_number) FROM stdin;
\.


--
-- Data for Name: inventory_strategy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_strategy (inventory_strategy_id, name, status) FROM stdin;
1	FIFO	Active
2	LIFO	Active
3	MANUAL	Active
\.


--
-- Data for Name: invoice_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_details (id, invoice_id, product_id, variant_id, name, description, item_weight, quantity, unit_price, discount, total_price, is_free, free_quantity, is_custom, amount_per_unit, unit_type, batch_no, invoice_item_uid, return_qty) FROM stdin;
\.


--
-- Data for Name: invoice_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_header (id, customer_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, dimensions, cod, payment_gateway_responce, payment_status, currency, sender_name, sender_phone, sender_email, sender_address, sender_city, sender_postal_code, sender_country, recipient_contact_two, cancelled_by, cancelled_date, created_at, paid_at, updated_at, note, delivery_fee, discount, user_id, tax_percentage, full_amount, bank_slip, discount_type, loyalty_points_earned, loyalty_points_spent, merchant_id, payment_reference, tax, pos_terminal_id, interface, payments, salespersons, discount_details, balance, till_id, add_to_points, invoice_link, inventory_deduct, sender_addrees_2, table_id, outlet_id) FROM stdin;
\.


--
-- Data for Name: invoice_payment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_payment_history (id, date, invoice_id, user_id, method_id, amount, reference, doc, status, type, loyalty_points_earned, loyalty_points_spent, acc_id, till_id) FROM stdin;
\.


--
-- Data for Name: job; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job (id, job_name, job_description, status, created_at, customer_id, hold_reason, assigned_users, admin_note, deleted_at) FROM stdin;
\.


--
-- Data for Name: job_bill_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_bill_item (id, job_id, item_type, product_id, item_name, quantity, unit_price, total_price) FROM stdin;
\.


--
-- Data for Name: job_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_log (log_id, job_id, action, description, performed_by, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_other_service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_other_service (id, job_id, service_name, amount) FROM stdin;
\.


--
-- Data for Name: kitchen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kitchen (id, name, outlet_id, display_id, status, created_at, updated_at, kot_printer_id) FROM stdin;
1	Main Kitchen	1	KIT-001	Active	2026-02-27 04:37:42.631668	2026-02-27 04:37:42.631668	\N
\.


--
-- Data for Name: kitchen_order_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kitchen_order_lines (id, invoice_id, product_id, kitchen_id, qty, is_reprint, order_line_id) FROM stdin;
\.


--
-- Data for Name: kitchen_order_lines_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kitchen_order_lines_header (id, sent_by, sent_at, status) FROM stdin;
\.


--
-- Data for Name: kitchen_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kitchen_products (kitchen_id, product_id, status) FROM stdin;
\.


--
-- Data for Name: leave_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_types (leave_type_id, name, days_per_year, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leaves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leaves (leave_id, employee_id, leave_type_id, from_date, to_date, reason, admin_note, status, created_at, updated_at, paid_status, duration_type, designation_id) FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logs (id, user_id, log, date, title) FROM stdin;
\.


--
-- Data for Name: material_inventory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_inventory (id, material_id, prev_stock, adjust_stock, current_stock, by, date, module, outlet_id, note, type) FROM stdin;
\.


--
-- Data for Name: measurements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.measurements (measurement_id, measurement_value, status, created_at) FROM stdin;
1	pcs	active	2025-06-25 09:53:41.668448
2	kg	active	2025-06-25 09:53:41.668448
3	g	active	2025-06-25 09:53:41.668448
4	ml	active	2025-06-25 09:53:41.668448
5	l	active	2025-06-25 09:53:41.668448
\.


--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.merchants (store_name, created_at, merchant_id, user_id) FROM stdin;
TestStore	2025-06-21 07:26:40.475913	20001	1
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (notification_id, user_id, module, event_type, channel, message_template, created_at, updated_at, status) FROM stdin;
\.


--
-- Data for Name: order_bulk_prints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_bulk_prints (bulk_id, generated_by, generated_at, order_count) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (order_item_id, order_id, product_id, variant_id, item_weght, quantity, unit_price, discount, total_price, is_free, free_quantity) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (order_id, customer_id, merchant_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, dimensions, cod, payment_gateway_responce, payment_status, currency, sender_address, delivery_partner_id, delivery_completed_date, delivery_type, tracking_id, currier_handover_date, currier_status, currier_payment_status, descline_orders, cancelled_by, cancelled_date, returned_date, returned_person, confirmed_date, created_at, paid_at, updated_at, recipient_name, recipient_contact, recipient_email, recipient_address, payment_reference, order_module, delivery_fee, discount, recipient_city, recipient_postal_code, recipient_country, user_id, managed_by, confiremed_by, storepickup, dispatched_date, processing_date, order_note, reason_id, bulk_id, bulk_dispatched_id, sender_name, sender_city, sender_phone, sender_email, sender_phone_two, recipient_contact_two, sender_country, tax_percentage, tax, purchase_count, full_amount, bank_slip, discount_type, loyalty_points_earned, loyalty_points_spent, recipient_addrees_2, sender_addrees_2, outlet_id) FROM stdin;
\.


--
-- Data for Name: outlets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outlets (outlet_id, name, address, geocode, hotline, email, opening_hours_from, opening_hours_to, tel_number, is_active, created_at, updated_at, merchant_id) FROM stdin;
1	Main Outlet No.1	Address	\N	\N	company_name@gmail.com	08:00:00	17:00:00	0700000000	t	2025-11-27 11:53:25.659595	2025-11-27 11:53:25.659595	20001
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, title, slug, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_methods (payment_method_id, method_name, payment_type, logo, tagline, payment_intraduction, transaction_fixed_fee, transaction_fee, discount, last_responce, status, api_array, category, web_show, pos_show) FROM stdin;
5	Cash	offline	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1755512855945-images.png	\N	{"details:cash","notes:cash details"}	0.00	0.00	0.00	\N	active	\N	Cash	\N	\N
3	COD	offline	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1752906172610-9789bd10c4ecbde7b61e5f6024c408cc.jpg	\N	{"details":"cod","notes":"jdfhwegurfhwejfwytfg"}	0.00	0.00	0.00	\N	active	\N	COD	\N	\N
4	Bank Transfer	offline	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1752906051195-bank-icon-logo-design-vector.jpg	\N	{"details:Account Number - 88556699","notes:Bank Name  - BOC\nBranch Name  - Kurunegala \nAccount Name -  Amila Parinda"}	0.00	0.00	0.00	\N	active	\N	Bank Transfer	\N	\N
2	Stripe	online	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1753172237234-Logo-1728997222.png	\N	\N	0.00	0.00	0.00	\N	inactive	{"sandbox": true, "merchant_id": "pk_test_51Rq7SQ1tDQQWe3JTCeWi9Vx0SiHSCTZEHYczj9EcD4ayTrc2HaQ9V5td7d9x8JYpPVpO3mfCfGnZibskFQp8WySH00DPJzE6NJ", "merchantSecret": "sk_test_51Rq7SQ1tDQQWe3JTiBGOUybtphvu0TGo4120wpYhAewl6b1w75NQVLxAAssQKUBefIGjkTuxxENVyFQQSYS118YD00cecuQjSL"}	Card	\N	\N
1	PayHere	online	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1753171948999-images.png	\N	\N	0.00	0.00	0.00	\N	active	{"sandbox": false, "merchant_id": "1231430", "merchantSecret": "MzU3MjU0NDg0Mjg3NTkxOTM4MTUwNDE4NDU1MzM5NTAyMTE0MjY="}	Card	\N	\N
6	Voucher	offline	\N	\N	\N	0.00	0.00	0.00	\N	active	\N	Voucher	f	t
7	Token	offline	\N	\N	\N	0.00	0.00	0.00	\N	active	\N	Token	f	t
8	Credit Card	online	\N	\N	\N	0.00	0.00	0.00	\N	active	\N	Card	f	t
9	Points	offline	\N	\N	\N	0.00	0.00	0.00	\N	active	\N	Points	f	t
\.


--
-- Data for Name: payroll_template_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_template_details (id, earning_deduction_id, type, amount, created_at, updated_at, payroll_template_id, value, earning_deduction_name) FROM stdin;
\.


--
-- Data for Name: payroll_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_templates (id, name, status, created_by, created_date, earnings, deductions, payroll_type, value, percentage_base, ot_hour_rate, holiday_ot_hour_rate, no_pay_deduction_rate) FROM stdin;
\.


--
-- Data for Name: paysheet_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paysheet_details (paysheet_detail_id, paysheet_id, earning_deduction_id, type, amount, created_at, updated_at, earning_deduction_name) FROM stdin;
\.


--
-- Data for Name: paysheet_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paysheet_invoices (paysheet_invoice_id, paysheet_detail_id, payment_reference, paid_by, payment_status, admin_note, payslip_url, created_at, account_id, account_name, bank_account, payment_method) FROM stdin;
\.


--
-- Data for Name: paysheets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paysheets (paysheet_id, employee_id, employee_name, salary_range_start, salary_range_end, payroll_month, payroll_year, pay_date, total_working_days, present_days, half_days, absent_days, paid_leave_days, unpaid_leave_days, late_count, total_earnings, total_deductions, net_salary, payroll_status, generated_at, approved_at, paid_at, created_at, updated_at, payroll_template_id) FROM stdin;
\.


--
-- Data for Name: pick_from_client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pick_from_client (id, job_id, equipment_name, note, serial_number) FROM stdin;
\.


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugins (plugin_id, plugin_name, information, logo, status, created_at) FROM stdin;
1	WhatsApp	+94770000000	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/2025-12-15/16-42-40-md_5b321c98efaa6.jpg	active	2025-12-16 04:06:58.395383
\.


--
-- Data for Name: po_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.po_header (po_id, po_date, expected_date, status, supplier_id, po_qty, remark, supplier_instructions, po_total_amount, generated_user, authorized_by, authorized_date, created_at) FROM stdin;
\.


--
-- Data for Name: po_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.po_items (po_item_id, po_id, variant_id, product_id, batch_number, unit_cost, req_qty, measurement_unit, amount_per_unit, line_total) FROM stdin;
\.


--
-- Data for Name: points_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points_logs (id, comment, prev_amount, adjust_amount, new_amount, customer_id, date) FROM stdin;
\.


--
-- Data for Name: portal_interface; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_interface (interface_id, name, route, status) FROM stdin;
2	POS	/pos	active
1	Admin	/welcome	active
\.


--
-- Data for Name: pos_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_settings (id, sound, restaurant_mode, created_at, updated_at, logo_url, return_policy, quantity_dialog, scan_code) FROM stdin;
1	t	f	2026-02-02 10:58:27.319092	2026-02-02 10:58:27.319092	\N	\N	f	all
\.


--
-- Data for Name: prn_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prn_header (prn_id, prn_date, grn_id, po_id, supplier_id, status, total_return_qty, total_return_amount, remark, returned_by, returned_date, authorized_by, authorized_date, created_at) FROM stdin;
\.


--
-- Data for Name: prn_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prn_items (prn_item_id, prn_id, grn_item_id, po_item_id, product_id, variant_id, batch_number, ordered_qty, received_qty, return_qty, unit_cost, reason, created_at) FROM stdin;
\.


--
-- Data for Name: product_brands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_brands (product_id, brand_id, status) FROM stdin;
\.


--
-- Data for Name: product_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_category (category_id, product_id) FROM stdin;
\.


--
-- Data for Name: product_collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_collections (collection_id, product_id) FROM stdin;
\.


--
-- Data for Name: product_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_media (media_id, media_url, media_type, created_at, product_id, status, variant_id, main) FROM stdin;
\.


--
-- Data for Name: product_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_reviews (review_id, customer_name, user_id, review, comment, status, product_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_tags (tag_id, product_id, status) FROM stdin;
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variants (variant_type, variant_value, sku, barcode, price, compare_at_price, inventory_quantity, track_quantity, shop_location_selling, continue_selling_oos, is_physical_product, weight, weight_unit, customs_info, created_at, updated_at, product_id, variant_id, cost_per_item, system_barcode, reorder_level, status, view_count) FROM stdin;
\.


--
-- Data for Name: production_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_details (id, production_id, ingredient_id, quantity, unit) FROM stdin;
\.


--
-- Data for Name: production_details_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_details_product (id, production_id, product_id, quantity, unit, raw_id) FROM stdin;
\.


--
-- Data for Name: production_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_header (id, kitchen_id, created_at, by, status) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (title, description, status, publishing_online, price, compare_at_price, charge_tax_on_product, cost_per_item, profit, margin, search_engine_title, search_engine_desc, type, vendor, theme_template, created_at, updated_at, publishing_pos, product_id, merchant_id, measurement_id, default_weight, view_count, amount_per_unit, default_barcode, publish_to_web, similar_keywords) FROM stdin;
\.


--
-- Data for Name: quotation_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotation_details (id, quotation_id, product_id, variant_id, name, description, item_weight, quantity, unit_price, discount, total_price, is_free, free_quantity, is_custom, amount_per_unit, unit_type) FROM stdin;
\.


--
-- Data for Name: quotation_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotation_header (id, customer_id, status, total_value, total_item, total_weight, currency, sender_name, sender_phone, sender_email, sender_address, sender_city, sender_postal_code, sender_country, cancelled_by, cancelled_date, created_at, updated_at, note, discount, user_id, tax_percentage, tax, time_period, full_amount, discount_type, merchant_id, recipent_note, quotation_date, quotation_link, discount_id, invoice_id) FROM stdin;
\.


--
-- Data for Name: raw_material; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.raw_material (id, name, weight, reorder_level, measurement_unit, status) FROM stdin;
\.


--
-- Data for Name: reasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reasons (reason_id, reason_type, reason_detail, created_at) FROM stdin;
1	return	Item was damaged	2025-07-24 05:16:12.18001
2	return	Wrong item delivered to customer	2025-07-24 05:16:12.18001
3	return	Customer refused the parcel at the doorstep	2025-07-24 05:16:12.18001
4	cancel	Customer canceled due to change of mind	2025-07-24 05:46:02.939446
5	reschedule	Recipient requested delivery on a different day	2025-07-24 05:46:02.939446
6	return	Customer returned product due to defect	2025-11-13 05:42:58.241895
7	return	Wrong item delivered to customer	2025-11-13 05:42:58.241895
8	return	Product did not match description	2025-11-13 05:42:58.241895
9	return	Product damaged during shipping	2025-11-13 05:42:58.241895
10	return	Customer changed mind after purchase	2025-11-13 05:42:58.241895
11	return	Incorrect size or color received	2025-11-13 05:42:58.241895
\.


--
-- Data for Name: recipe; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipe (id, product_id, variant_id, raw_id, quantity, measurement_unit, by, date, status) FROM stdin;
\.


--
-- Data for Name: reorder_level; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reorder_level (id, product_id, variant_id, outlet_id, reorder_level, reorder_level_reached_days, current_stock, last_ordered_date, last_ordered_quantity, action, updated_at) FROM stdin;
\.


--
-- Data for Name: reorder_level_removed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reorder_level_removed (id, product_id, variant_id, outlet_id, reorder_level, reorder_level_reached_days, current_stock, last_ordered_date, last_ordered_quantity, action, updated_at) FROM stdin;
\.


--
-- Data for Name: restaurant_tables; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.restaurant_tables (id, name, table_id, note, seats, outlet_id, status, created_at, updated_at) FROM stdin;
1	Table 01	TBL-01	Near Window	4	1	Active	2026-02-27 04:45:31.1325	2026-02-27 04:45:31.1325
\.


--
-- Data for Name: return_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_token (id, date, by, amount, old_inv_id, used_amount, used_inv_id, status, returned_items, comment, type) FROM stdin;
\.


--
-- Data for Name: role_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_list (id, role_name, date, status, privileges, dashboard_access, created_at, updated_at, user_id, portal_interface) FROM stdin;
1	Super Admin	2025-02-03 12:51:06.618	active	{1,2,3,4,5,6,7,8,9,14,15,16,18,19,20,21,22,23,24,25,26,27,28,30,31,32,33,34,35,54,55,56,57,58,61,62,63,64,65,66,67,68,71,72,73,74,75,76,77,80,81,82,83,84,85,86,87,88,89,98,99,102,103,104,106,107,108,109,111,112,113,114,123,125,129,130,133,135,136,138,139,140,146,250}	{dashboard}	2025-02-03 12:51:06.636692	2025-02-03 12:51:06.636692	\N	\N
\.


--
-- Data for Name: sales_channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_channel (id, sales_name, outlet_id, comment, added_by, type, login_url, store_domain, merchant_id, template_id, updated_at) FROM stdin;
1	Facebook Sales Channel	1	Main Facebook page sales	101	web	https://facebook.com/login-page	facebook.myshop.com	20001	3	2025-08-14 12:35:27.969579
\.


--
-- Data for Name: send_email_temp_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.send_email_temp_log (id, email, msg, status, date, sentdate, batche_id, action, subject) FROM stdin;
\.


--
-- Data for Name: send_sms_temp_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.send_sms_temp_log (id, mobileno, msg, status, date, sentdate, batche_id, action) FROM stdin;
\.


--
-- Data for Name: shift_roster; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shift_roster (roster_id, employee_id, shift_id, roster_date, remarks, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shifts (id, shift_name, weekday, shift_in_time, shift_out_time, grace_period_minutes, early_ot_minutes, after_ot_minutes, created_at, updated_at, max_ot_minutes, holiday_ot_minutes) FROM stdin;
\.


--
-- Data for Name: shopping_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shopping_list (id, production_id, ingredient_id, quantity, unit, date) FROM stdin;
\.


--
-- Data for Name: site_section_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_section_configs (id, merchant_id, template_id, template_section_id, sort_order, enabled, config, created_at, updated_at) FROM stdin;
34	20001	3	31	0	t	{}	2025-08-14 05:55:04.614706+00	2025-08-15 15:36:03.410434+00
28	20001	3	29	0	t	{}	2025-08-13 12:54:34.475518+00	2025-11-17 06:36:58.861377+00
180	20001	2	13	0	t	{}	2025-09-01 05:04:45.71871+00	2025-09-01 05:04:45.71871+00
170	20001	2	16	0	t	{}	2025-08-30 09:01:04.308437+00	2025-09-01 07:03:58.879099+00
25	20001	3	27	0	t	{}	2025-08-13 09:35:58.818714+00	2025-10-25 07:00:17.843996+00
37	20001	3	26	0	t	{}	2025-08-14 07:29:15.525412+00	2025-11-11 03:57:03.277512+00
4	20001	3	24	0	t	{}	2025-08-12 08:00:27.468444+00	2025-10-24 12:20:42.24077+00
20	20001	3	25	0	t	{}	2025-08-12 17:25:57.09166+00	2025-11-11 03:59:42.009033+00
26	20001	3	28	0	t	{}	2025-08-13 10:55:22.437878+00	2025-11-11 04:00:35.961589+00
33	20001	3	30	0	t	{}	2025-08-14 05:48:14.991734+00	2025-08-14 07:42:09.065322+00
35	20001	3	32	0	t	{}	2025-08-14 06:11:17.690863+00	2025-08-14 07:42:16.034211+00
226	20001	5	47	0	t	{}	2025-10-04 08:48:57.821718+00	2025-10-07 05:27:08.900426+00
1	20001	3	23	0	t	{}	2025-08-12 05:16:49.701062+00	2025-11-20 08:26:43.271767+00
213	20001	2	17	0	t	{}	2025-09-01 13:33:37.433245+00	2025-09-01 15:57:43.87074+00
173	20001	2	18	0	t	{}	2025-08-31 13:57:03.084013+00	2025-09-01 15:58:47.899175+00
177	20001	2	15	0	t	{}	2025-08-31 14:49:54.205771+00	2025-09-01 15:56:29.399193+00
150	20001	2	12	0	t	{}	2025-08-29 05:35:51.254683+00	2025-09-01 06:33:58.755047+00
178	20001	2	14	0	t	{}	2025-08-31 15:25:31.729824+00	2025-09-01 15:59:39.101695+00
\.


--
-- Data for Name: sms_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_action (id, name, status) FROM stdin;
1	New Order Placed	Active
2	Order Confirmed & Assigned	Active
3	Order Dispatched	Active
4	Order Completed	Active
5	Order Cancelled	Active
6	Order Returned	Active
7	Order Link	Active
9	User Registration	Active
10	Order Paid	Active
8	Guest Registration	Active
11	Send Quotation	Active
12	Send Invoice	Active
13	Invoice Link	Active
14	Leave Approve	Active
15	Leave Reject	Active
16	Shift Roster	Active
17	Paysheet	Active
18	Employee Onboarding	Active
\.


--
-- Data for Name: sms_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_template (id, msg, action, admin, client, "user", status, addby, createddate, updateddate, employee) FROM stdin;
4	Hi [name],Your order has been successfully delivered. For any questions or feedback, please contact us [Hotline] .Thank you	4	Yes	Yes	1	Active	1	2025-11-10 04:22:00.525633+00	2025-11-26 09:40:07.987246	
1	Welcome to [Webname] and thank you for your purchase!	1	Yes	Yes	1	Active	1	2025-11-10 04:20:16.721626+00	2025-11-27 06:20:46.563807	
6	Dear [name], we’ve received your return request for order ID [order_id] . Our team is processing it. For any clarification please contact us via [Hotline] [Webname] Team\t	6	Yes	Yes	1	Active	1	2025-11-10 04:23:54.115178+00	2025-11-28 11:40:10.596261	
5	Hi [name], your order ID [order_id] placed, has been cancelled due to [reason]. For support or reorder, Please contact [Hotline]. [Webname] Team\t	5	Yes	Yes	1	Active	1	2025-11-10 04:23:19.660177+00	2025-11-28 11:40:20.717435	
3	Hi [name],Your order ID [order_id] has been dispatched and is on its way to you. Thank you for shopping with us! For any clarification please contact us via [Hotline] [Webname] Team\t	3	Yes	Yes	1	Active	1	2025-11-10 04:21:33.867735+00	2025-11-28 11:40:44.12713	
2	Hi [name], your order ID [order_id] has been confirmed. Thank you for shopping with us! For any clarification please contact us via [Hotline] [Webname] Team\t	2	Yes	Yes	1	Active	1	2025-11-10 04:20:55.503892+00	2025-11-28 11:40:56.809216	
\.


--
-- Data for Name: stock_sheet_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_sheet_details (sheet_details_id, sheet_id, product_id, variant_id, previous_stock, current_stock, changed_qty, sku, batch_number, barcode, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_sheet_header; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_sheet_header (sheet_id, user_id, stock_type, remark, created_at, outlet_id) FROM stdin;
\.


--
-- Data for Name: supplier_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_payments (payment_id, paid_amount, po_id, supplier_id, payment_note, slip_url, voucher_id, status, grn_id, po_amount, due_amount, by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (supplier_id, business_name, address, status, created_at, responsible_person, mobile_no, contact_no, email, credit_limit, credit, reg_date, reg_by, account_no, bank, branch, acc_holders_name, country, city, note) FROM stdin;
\.


--
-- Data for Name: system_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_log (id, date, module, log, user_id) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, default_timezone, date_format, currency, auto_logout_time, sms_gateway_name, sms_user_id, sms_sender_id, sms_api_endpoint, sms_api_key, sms_notification_status, billing_email, system_email, support_email, email_notification_status, postmark_server_token, smtp_host, smtp_port, smtp_username, smtp_password, smtp_encryption, new_client_sms_status, new_client_email_status, new_client_activation_sms_status, new_client_activation_email_status, created_at, updated_at, backoffice_maintenance_status, backoffice_maintenance_msg, webstore_maintenance_status, pos_maintenance_status, pos_maintenance_msg, full_maintenance_status, full_maintenance_msg, sell_international, tax, tax_value, tax_on_web, default_country, enabled_google, google_mode, gtm_container_id, ga4_measurement_id, enabled_meta, meta_pixel_id, meta_capi_enabled, meta_capi_access_token, terms_conditions, enabled_google_tag, admin_alert_sms_status, admin_alert_email_status, notification_mobile_numbers, notification_emails, webstore_maintenance_msg, suspend_status, suspend_reason, billing_pay_status, suspend_date, loyalty_point, points_given, amount_spend, field_config, terms_conditions_quotations, time_period, time_period_enabled, inventory_strategy_id, s3_region, s3_endpoint, s3_access_key, s3_secret_key, s3_bucket_name, s3_public_key, billing_client_id, billing_servise_id, billing_pid, billing_base_url) FROM stdin;
1	Asia/Colombo	MM/DD/YY	LKR	00:00:30	OZoneSender	1	oZoneSender	https://api.ozonesender.com	oii7qfm4ompLzuY	enabled	system@simpleexpress.lk	system@example.com	support@example.com	enabled	d47e5a98-dce7-4b34-8403-2b2120df7cc7	smtp.mailtrap.io	587	smtp_user	smtp_pass_123	TLS	disabled	disabled	disabled	disabled	2025-05-21 07:23:19.481506	2025-08-27 11:07:33.606805	disabled	{"title":"","message":""}	disabled	disabled	{"title":"","message":""}	disabled	{"title":"","message":""}	t	f	{"VAT & Tax": "10"}	f	Sri Lanka	t	\N	GTM-KC234ZP4	G-8BVKSQ8CZY	t	123456789123456	\N	\N	["[\\"[\\\\\\"[\\\\\\\\\\\\\\"[\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"[\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sentence 1\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sentence 2\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sentence 3\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"]\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"]\\\\\\\\\\\\\\"]\\\\\\"]\\"]"]	t	active	active	{94773671596}	{raveendrapushpakumaraspark@gmail.com}	{"title":"","message":""}	f	\N	\N	\N	f	0.00	0.00	{}	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	75	229	CLT-393268A9	https://clientview.sparkglobalsolutions.net
\.


--
-- Data for Name: table_management; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.table_management (id, name, chairs, assignto, ongoing_status, session_start_time, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (tag_id, name, status, merchant_id) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (transaction_id, transaction_type, category_id, account_id, transaction_date, amount, transaction_fee, note, by, created_at, updated_at, status, reference_id, payer_payee_id, payment_status, file_url, outlet_id) FROM stdin;
\.


--
-- Data for Name: uimenudata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.uimenudata (id, parent_id, name, route, icon, sidebar_order, show, package_show) FROM stdin;
130	\N	Update Invoice	/update-invoice/*	\N	100	f	t
138	\N	Delete Invoice	#	\N	120	f	t
89	\N	Billing & Support	https://tekoraclientview.sparkglobalsolutions.net	mdi:help-circle-outline	21	t	t
35	23	Re-Order	/reOrder	\N	8.7	t	t
140	14	Navigation Order	/menu_items	\N	20	t	t
15	14	Branding Settings	/branding_settings	\N	5.1	t	t
30	4	Admin Logs	/admin_log	\N	6.1	t	t
67	65	Moving Report	/moving_report	\N	13.2	t	t
66	65	Product Based Revenue	/sales_report	\N	13.1	t	t
58	55	Inactive Customers	/inactive_customer	\N	12.3	t	t
56	55	Add Customer	/add_customer	\N	12.1	t	t
64	55	Reviews	/approve_reviews	\N	12.4	t	t
88	71	Vouchers	/voucher_managament	\N	14.11	t	t
6	3	Add User	/add_user	add-user-icon	4.1	t	t
8	3	User List	/user_list	list-icon	4.2	t	t
7	3	Add Role	/add_role	role-icon	4.3	t	t
9	3	User Role	/role_list	role-list-icon	4.4	t	t
114	111	Categories	/accounts_categories	\N	20.3	t	t
123	111	Payer/Payee	/payer_payee	\N	20.4	t	t
125	111	Transactions Report	/transactions_report	\N	20.5	t	t
99	98	Recipe	/recipe	\N	1	t	t
107	98	Kitchen	/kitchen	\N	4	t	t
104	98	Raw Material	/raw_material	\N	6	t	t
93	92	Employee Profile	/employee_profile	\N	7	t	f
137	92	Upcoming Salary	/upcomingsalary	\N	13	f	f
115	92	Designation	/designation	\N	3	t	f
116	92	Shift	/shift	\N	4	t	f
117	92	Attendance	/attendance	\N	5	t	f
118	92	Payroll Template	/payroll	\N	6	t	f
119	92	Employee Onboarding	/add_employee	\N	2	t	f
120	92	Leave	/leave	\N	8	t	f
121	92	ShiftRoster	/shiftroster	\N	9	t	f
122	92	Holiday	/holiday	\N	10	t	f
126	92	EMS Dashboard	/emsdashboard	\N	1	t	f
127	92	Earning & Deduction	/earning_deduction	\N	11	t	f
128	92	PaySheet	/paysheettemplate	\N	12	t	f
91	90	New PO	/purchasing_manager/new_purchase_order	\N	17.1	t	f
94	90	PO List	/purchasing_manager/all_purchase_orders	\N	17.2	t	f
95	90	New GRN	/purchasing_manager/add_new_grn	\N	17.3	t	f
97	90	Supplier	/purchasing_manager/supplier_list	\N	17.7	t	f
106	98	Material Inventory	/material_inventory		7	t	t
129	98	All Recipe	/all_recipe		2	t	t
108	98	Restaurant Tables	/restaurant_tables	\N	3	t	t
109	98	Kitchen Release	/kitchen_release		5	t	t
61	18	Inactive Products	/InactiveProducts	\N	3.3	t	t
19	18	Active Products	/products	\N	3.2	t	t
20	18	Collections	/collections	\N	3.5	t	t
32	18	Add Product	/products/add_products	\N	3.1	t	t
34	18	Brands	/brands	\N	3.6	t	t
22	18	Variants	/variants	\N	3.5	t	t
21	18	Categories	/categories	\N	3.4	t	t
84	23	Batch Management	/batch_management	\N	8.8	t	t
68	65	Payment Overview	/payment_overview	\N	13.3	t	t
102	65	Sales Summary	/sales_summary_report		13.4	t	t
57	55	Active Customers	/active_customer	\N	12.2	t	t
139	71	Delete Invoice	/delete-invoice		15	t	t
48	43	Bulk Print	/bulk_print	\N	10.1	t	f
46	43	Dispatch to Courier	/bulk_dispatch	\N	10.2	t	f
47	43	Dispatch List	/dispatch_list	\N	10.3	t	f
134	\N	Page Elementor	/page_elementor/*	\N	104	f	f
49	43	Delivery Partners	/delivery_partners	\N	10.4	t	f
132	\N	Update Orders	/update_orders/*	\N	102	f	f
44	36	All Orders	/all_orders	\N	9.82	t	f
100	90	New PRN	/purchasing_manager/add_return_note	\N	17.5	t	f
79	50	Plugins	/plugins	\N	11.4	t	f
40	36	Processing Orders	/processing_orders	\N	9.4	t	f
98	\N	Restaurant Management	#	ic:sharp-table-restaurant	13	t	t
2	\N	Welcome Page	/welcome	mdi:home	1	t	t
1	\N	Dashboard	/dashboard/analytics	iconoir:home-simple	2	t	t
18	\N	Product Management	#	fluent-mdl2:product-variant	4	t	t
133	\N	Update Product	/products/update_product	\N	103	f	t
135	\N	Product View	/products/product_view/*	\N	105	f	t
77	\N	POS	#	fontisto:shopping-pos-machine	16	t	t
51	50	Template	/template	\N	11.1	t	f
45	36	Cancelled Orders	/cancel_orders	\N	9.9	t	f
38	36	Pending Orders	/pending_orders	\N	9.2	t	f
53	36	Returned Orders	/returned_orders	\N	9.81	t	f
101	90	PRN List	/purchasing_manager/return_note_list	\N	17.6	t	f
136	\N	Discount Other	/discounts/*	\N	106	f	t
23	\N	Inventory Management	#	mdi:home	5	t	t
55	\N	Customer Management	#	material-symbols:group	6	t	t
146	98	Material Stock In/Out	/material_stock_in_out	\N	8	t	t
75	71	All Invoices	/invoices	\N	14.3	t	t
36	\N	Order Management	/complete_orders	fluent-mdl2:product-list	3	t	f
73	71	Order Invoice	/invoice	\N	14.5	t	t
81	71	Cancel Order Invoice	/cancel-invoice	\N	14.6	t	t
96	90	GRN List	/purchasing_manager/grn_list	\N	17.4	t	f
143	142	Create Job	/create-job	\N	21.1	t	f
144	142	Active Job List	/job-list	\N	21.2	t	f
145	142	Deleted Job List	/deleted-job-list	\N	21.3	t	f
92	\N	Employee Management	#	mdi:account-group-outline	12	t	f
142	\N	Service Management	/service-management	mdi:tools	20	t	f
131	\N	Update Quotations	/update_quotations/*	\N	101	f	f
39	36	Confirmed Orders	/confirmed_orders	\N	9.3	t	f
41	36	Dispatched Orders	/dispatch_orders	\N	9.5	t	f
42	36	Completed Orders	/complete_orders	\N	9.6	t	f
37	36	Add Order	/add_orders	\N	9.1	t	f
60	43	Delivery Fee	/delivery_fee	\N	10.5	t	f
43	\N	Delivery Management	#	fluent-mdl2:delivery-truck	7	t	f
50	\N	Webstore Management	#	fluent-mdl2:shop	8	t	f
52	50	Pages	/cms	\N	11.2	t	f
70	50	Components	/components	\N	11.3	t	f
82	71	Cancel Invoice	/cancell-invoice	\N	14.4	t	t
72	71	Discounts	/discounts	\N	14.1	t	t
74	71	New Quotations	/new_quotations	\N	14.7	t	t
83	71	Ongoing Quotation	/all_quotations	\N	14.8	t	t
85	71	Rejected Quotation	/canceled_quotations	\N	14.9	t	t
113	111	Transactions	/transactions	\N	20.2	t	t
112	111	Accounts	/accounts	\N	20.1	t	t
16	14	System Settings	/system_settings	\N	5.2	t	t
250	77	Display	/display	\N	21	t	t
80	77	Go To POS	/pos	\N	15.1	t	t
86	77	Device Management	/device_management	\N	15.2	t	t
87	77	POS Settings	/pos_settings	\N	15.3	t	t
103	18	Variants & Barcodes	/variantsAndBarcodes		3.7	t	t
24	23	Inventory Search	/inventory_search		8.1	t	t
25	23	Inventory Status	/inventory_status		8.2	t	t
26	23	Stock In/Out	/stock_in_out		8.3	t	t
27	23	Outlets	/outlets		8.4	t	t
28	23	Movement History	/movement_history		8.5	t	t
76	71	Add Invoices	/add_invoice	\N	14.2	t	t
54	14	Payment Gateway	/payment_getway	\N	5.3	t	t
33	4	System Logs	/system_log	\N	6.3	t	t
31	4	Client Logs	/client_log	\N	6.2	t	t
62	14	SMS Notification	/sms_notification	\N	5.4	t	t
63	14	Email Notification	/email_notification	\N	5.5	t	t
90	\N	Purchasing Management	#	iconoir:compact-disc	11	t	f
65	\N	Reports Management	#	material-symbols:docs-outline-sharp	9	t	t
71	\N	Sales Management	#	iconoir:compact-disc	10	t	t
111	\N	Accounts Management	#	iconoir:compact-disc	14	t	t
3	\N	User Management	#	iconoir:compact-disc	15	t	t
5	\N	Profile	/profile	material-symbols:person-apron	17	t	t
4	\N	Logs	#	material-symbols:docs-outline-sharp	18	t	t
14	\N	Settings	#	iconoir:compact-disc	19	t	t
\.


--
-- Data for Name: user_backup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_backup (user_id, first_name, last_name, username, password, mobile, role_id, status, email, outlet_id, created_at, updated_at, merchant_id_int) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (user_id, first_name, last_name, username, password, mobile, role_id, status, email, branch_id, created_at, updated_at, merchant_id, outlet_id, picture, otp, otp_expires_at) FROM stdin;
1	admin	devadmin	admin	$2b$10$VIPhPLDh.V4.e9FLU3Vo8uj7AqL0zX2aBSHTDtE2CEHQDIwuyJfRW	94715266478	1	Active	devsspark@gmail.com	1	2025-02-07 13:48:30.231975	2026-03-24 16:27:15.254385	20001	1	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1755603481407-blue-circle-with-white-user_78370-4707.avif	440553	2025-11-26 04:29:21.172
\.


--
-- Data for Name: variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.variants (id, option_name, "values", status) FROM stdin;
\.


--
-- Data for Name: voucher; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.voucher (id, date, by, amount, used_amount, used_inv_id, status, voucher_id) FROM stdin;
\.


--
-- Data for Name: waybills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waybills (waybill_id, d_partner_id, waybill, status, order_id, upload_date, import_by, customer_id) FROM stdin;
\.


--
-- Data for Name: web_page_components; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_page_components (id, page_id, component_id, "order", props_json, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: web_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_pages (id, title, slug, content_html, is_homepage, created_at, updated_at, status) FROM stdin;
3	T&C	terms-and-conditions	<h2>📄 Terms and Conditions</h2><p><strong>Insert your terms and conditions here.</strong></p><p><br></p><h3>1. Introduction</h3><p>Welcome to <strong>eComece</strong>. By accessing or using our website, you agree to comply with and be bound by the following terms and conditions. Please read them carefully before using our services.</p><p><br></p><h3>2. Use of Website</h3><ul><li>You must be at least 18 years old to use this site or have permission from a legal guardian.</li><li>You agree not to misuse the website for unlawful purposes or violate any applicable laws.</li></ul><h3>.</h3><p><img src="https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1753687295032-wildflower-terms-and-conditions.png"></p>	t	2025-07-14 07:39:16.669507	2025-07-14 07:39:16.669507	active
5	About Us	about-us	<h2>🏪 About Us</h2><p><strong>Information about our company.</strong></p><p><br></p><p>Welcome to <strong>eComece</strong> — your trusted destination for quality products, exceptional service, and a seamless online shopping experience.</p><h3>🌟 Who We Are</h3><p>At eComece, we are more than just an online store. We are a passionate team dedicated to delivering value, variety, and convenience to our customers across Sri Lanka and beyond.</p><p>Founded with a vision to make quality products easily accessible to everyone, we bring together a curated selection of items — from everyday essentials to exclusive finds — all in one place.</p><p><br></p><h3>🚚 What We Offer</h3><ul><li>A wide range of <strong>products</strong>, carefully selected for quality and value</li><li>Reliable <strong>nationwide delivery</strong></li><li>Secure <strong>online payment</strong> options</li><li>Friendly <strong>customer support</strong> whenever you need it</li></ul><p><img src="https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1753687025795-ABOUT-US.jpg"></p>	t	2025-07-14 07:39:16.669507	2025-07-15 10:34:08.239937	active
4	Privacy Policy	privacy-policy	<h2>🔒 Privacy Policy</h2><p><strong>Our privacy policy content goes here.</strong></p><p><br></p><h3>1. Introduction</h3><p>We value your privacy and are committed to protecting your personal information. This policy outlines how we collect, use, and safeguard your data when you interact with our website or services.</p><p><br></p><h3>2. Information We Collect</h3><p>We may collect the following types of information:</p><ul><li>👤 Personal details (name, email, phone number)</li><li>🌐 Technical data (IP address, browser type)</li><li>📦 Order and transaction details</li><li>🧭 Location data (if applicable)</li></ul><p><br></p><p><img src="https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1753686921863-7-places-to-add-your-privacy-policy.png"></p>	t	2025-07-14 07:39:16.669507	2025-07-14 07:39:16.669507	active
2	Shop	shop	<h2>🛍️ Shop</h2><p><strong>Our amazing products go here.</strong></p><p><br></p><p>Welcome to the <strong>eComece Shop</strong>, your one-stop destination for quality, variety, and unbeatable value.</p><p>Whether you're searching for the latest trends, everyday essentials, or special gifts, our curated selection of products is designed to meet all your needs — and more.</p><p>✨ <strong>What You’ll Find Here:</strong></p><ul><li>Trending fashion and accessories</li><li>Home &amp; lifestyle essentials</li><li>Electronics and gadgets</li><li>Beauty, wellness, and more</li></ul><p>Each item is handpicked to ensure top quality and satisfaction. We update our collection regularly, so there’s always something new to discover.</p><p><img src="https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1753687370086-neo.jpg"></p>	f	2025-07-14 07:39:16.669507	2025-07-14 07:39:16.669507	active
6	Contact Us	contact-us	<h2>📝 Contact Us</h2><p><strong>Contact information and form.</strong></p><p><br></p><p><em>Your support matters. We're always here for you.</em>We are always here to help. Whether you have a question about our services, need assistance with an order, or simply want to give feedback — don’t hesitate to reach out.</p><p>📧 <strong>Email:</strong>support@example.com</p><p>📞 <strong>Phone:</strong> +94 77 123 4567</p><p>🕘 <strong>Business Hours:</strong> Monday to Friday, 9:00 AM – 5:00 PM</p><p><br></p><p>Alternatively, fill out the contact form below with your name, email address, and message, and one of our team members will get back to you within <strong>24 hours</strong>.</p><p>We value your thoughts and strive to respond promptly to every inquiry.</p><p>Your voice helps us grow, improve, and serve you betters2.</p><p><br></p><p><img src="https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1753686774465-using-laptop-show-icon-address-600nw-2521386695.webp"></p>	t	2025-07-14 07:39:16.669507	2025-07-14 07:39:16.669507	active
1	Home	home	<h1>Welcome to Our Website</h1><p>This is the home page content.</p><p><br></p><p><img src="https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1752570801320-ChatGPT_Image_Jul_14__2025__08_57_33_PM-removebg-preview.png"></p><p>This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.</p><p><br></p><p><strong>This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.This is the home page content.</strong></p><p><br></p>	f	2025-07-14 07:39:16.669507	2025-07-15 09:14:35.129243	active
\.


--
-- Data for Name: web_template_sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_template_sections (id, template_id, section_key, name, image, status, "order", display, updated_at, config_schema, ui_schema, default_config) FROM stdin;
30	3	BeautyTestimonial	Beauty Testimonial	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170751-3_8.png	active	\N	f	2025-08-14 12:35:27.969579	{"type": "object", "properties": {"show_rating": {"type": "boolean", "default": true}, "show_comment": {"type": "boolean", "default": true}, "show_profile_anonymous": {"type": "boolean", "default": true}}, "additionalProperties": false}	{"form": {"fields": [{"name": "show_rating", "type": "switch", "label": "Show rating stars", "default": true}, {"name": "show_comment", "type": "switch", "label": "Show customer comment text", "default": true}, {"name": "show_profile_anonymous", "type": "switch", "label": "Show profile as \\"Anonymous\\"", "default": true, "description": "If ON, show avatar/role but mask the name. If OFF, hide the profile block."}]}}	{"show_rating": true, "show_comment": true, "show_profile_anonymous": true}
26	3	ProductArea	Product Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170372-3_4.png	active	3	t	2025-08-14 12:35:27.969579	{"type": "object", "properties": {"limit": {"type": "integer", "default": 8, "maximum": 8, "minimum": 1}, "collection_id": {"type": "integer", "const": 4, "default": 4}, "background_color": {"type": "string", "default": "#ffffff", "pattern": "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$"}, "selected_product_ids": {"type": "array", "items": {"type": "integer"}, "maxItems": 8, "uniqueItems": true}}, "additionalProperties": false}	{"form": {"fields": [{"name": "selected_product_ids", "type": "async-checkboxes", "label": "Select bestselling products", "source": "/web/bestselling_products", "labelKey": "name_with_price", "valueKey": "product_id", "description": "Choose up to 8 items from the Bestselling collection."}, {"max": 8, "min": 1, "name": "limit", "step": 1, "type": "number", "label": "Max items to show", "default": 8}, {"name": "background_color", "type": "color", "label": "Background color", "default": "#ffffff", "description": "Pick a background color for this section."}]}}	{"limit": 8, "collection_id": 4, "background_color": "#ffffff", "selected_product_ids": []}
11	1	Testimonial	Testimonial		inactive	\N	f	2025-07-22 06:30:23.270655	{}	{}	{}
10	1	Blog	Blog		inactive	\N	f	2025-07-22 06:30:23.270655	{}	{}	{}
18	2	PopularProducts	Popular Products	https://d8y1.c2.e2-9.dev/spark-files/1754576398383-20250807141959-2_3.png	active	2	t	2025-08-07 14:14:10.057525	{}	{}	{}
15	2	ProductArea	Product Area	https://d8y1.c2.e2-9.dev/spark-files/1754576520978-20250807142201-2_4.png	active	3	t	2025-08-07 14:14:10.057525	{}	{}	{}
14	2	WeeksFeatured	Weeks Featured	https://d8y1.c2.e2-9.dev/spark-files/1754576577270-20250807142258-2_5.png	active	4	t	2025-08-07 14:14:10.057525	{}	{}	{}
17	2	TrendingProducts	Trending Products	https://d8y1.c2.e2-9.dev/spark-files/1754576692499-20250807142453-2_6.png	active	5	t	2025-08-07 14:14:10.057525	{}	{}	{}
33	3	Testimonial	Testimonial		inactive	11	t	\N	{}	{}	{}
20	2	BestSellerProducts	Best Seller Products	https://d8y1.c2.e2-9.dev/spark-files/1754576753576-20250807142554-2_7.png	active	6	t	2025-08-07 14:14:10.057525	{}	{}	{}
22	2	FashionTestimonial	Fashion Testimonial	https://d8y1.c2.e2-9.dev/spark-files/1754576773247-20250807142614-2_8.png	active	7	t	2025-08-07 14:14:10.057525	{}	{}	{}
21	2	BlogArea	Blog	https://d8y1.c2.e2-9.dev/spark-files/1754576787840-20250807142628-2_9.png	active	8	t	2025-08-07 14:14:10.057525	{}	{}	{}
39	4	OfferProducts	Offer Products	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580396984-4_6.png	active	5	t	2025-08-09 06:30:25.727235	{}	{}	{}
40	4	ProductGadgetArea	Product Gadget	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580397053-4_7.png	active	6	t	2025-08-09 06:30:25.727235	{}	{}	{}
41	4	ProductBanner	Product Banner	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580397137-4_8.png	active	7	t	2025-08-09 06:30:25.727235	{}	{}	{}
42	4	NewArrivals	New Arrivals	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580397232-4_9.png	active	8	t	2025-08-09 06:30:25.727235	{}	{}	{}
36	4	FeatureArea	Feature	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580396709-4_3.png	active	1	t	2025-08-09 06:30:25.727235	{}	{}	{}
1	1	JewelryBanner	Banner	https://d8y1.c2.e2-9.dev/spark-files/1753112465799-20250721154102-image_19.png	active	0	t	2025-08-11 10:16:35.5452	{}	{}	{}
2	1	FeatureAreaThree	Feature Area	https://d8y1.c2.e2-9.dev/spark-files/1753157346602-20250722040905-image_9.png	active	1	t	2025-08-11 10:16:35.5452	{}	{}	{}
8	1	JewelryAbout	Jewelry About	https://d8y1.c2.e2-9.dev/spark-files//1753158474263-20250722042752-Group_7.png	active	2	t	2025-08-11 10:16:35.5452	{}	{}	{}
4	1	PopularProducts	Popular Products	https://d8y1.c2.e2-9.dev/spark-files/1753160231190-20250722045710-Group_6.png	active	3	t	2025-08-11 10:16:35.5452	{}	{}	{}
35	4	ElectronicCategory	Electronic Category	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580396641-4_2.png	active	2	t	2025-08-09 06:30:25.727235	{}	{}	{}
37	4	ProductArea	Product Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580396779-4_4.png	active	3	t	2025-08-09 06:30:25.727235	{}	{}	{}
38	4	BannerArea	Banner Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580396908-4_5.png	active	4	t	2025-08-09 06:30:25.727235	{}	{}	{}
43	4	ProductSmArea	Product Sm Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580397313-4_10.png	active	9	t	2025-08-09 06:30:25.727235	{}	{}	{}
13	2	FeatureAreaTwo	Feature	https://d8y1.c2.e2-9.dev/spark-files/1754576802400-20250807142644-2_10.png	active	9	t	2025-08-07 14:14:10.057525	{}	{}	{}
19	2	InstagramAreaTwo	Instagram	https://d8y1.c2.e2-9.dev/spark-files/1754576821048-20250807142702-2_11.png	active	10	t	2025-08-07 14:14:10.057525	{}	{}	{}
12	2	BannerTwo	BannerTwo	https://d8y1.c2.e2-9.dev/spark-files/1754575671851-20250807140752-2_1.png	active	0	t	2025-08-07 14:14:10.057525	{}	{}	{}
16	2	Category	Category	https://d8y1.c2.e2-9.dev/spark-files/1754575959843-20250807141240-2_2.png	active	1	t	2025-08-07 14:14:10.057525	{}	{}	{}
34	4	HomeHeroSlider	Hero Slider	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754580396298-4_1.png	active	0	t	2025-08-09 06:30:25.727235	{}	{}	{}
44	4	BlogArea	Blog Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754582017997-4_11.png	active	10	t	2025-08-09 06:30:25.727235	{}	{}	{}
45	4	InstagramArea	Instagram Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754582018392-4_12.png	active	11	t	2025-08-09 06:30:25.727235	{}	{}	{}
46	4	CtaArea	Cta Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754582018468-4_13.png	active	12	t	2025-08-09 06:30:25.727235	{}	{}	{}
5	1	ProductArea	Product Area	https://d8y1.c2.e2-9.dev/spark-files/1753159311389-20250722044150-Group_8.png	active	4	t	2025-08-11 10:16:35.5452	{}	{}	{}
7	1	JewelryCollectionBanner	Jewelry Collection Banner	https://d8y1.c2.e2-9.dev/spark-files/1753160159994-20250722045558-Group_5.png	active	5	t	2025-08-11 10:16:35.5452	{}	{}	{}
6	1	BestSellerPrd	Best Seller	https://d8y1.c2.e2-9.dev/spark-files/1753159143394-20250722043901-Group_4.png	active	6	t	2025-08-11 10:16:35.5452	{}	{}	{}
3	1	TrendingProduct	Trending...	https://d8y1.c2.e2-9.dev/spark-files/1753158194197-20250722042312-image_10.png	active	7	t	2025-08-11 10:16:35.5452	{}	{}	{}
9	1	JewelryBrands	Jewelry Brands	https://d8y1.c2.e2-9.dev/spark-files/1753160401755-20250722050001-image_17.png	active	8	t	2025-08-11 10:16:35.5452	{}	{}	{}
24	3	BeautyCategory	Beauty Category	https://d8y1.c2.e2-9.dev/spark-files/1754578093279-20250807144814-3_2.png	active	1	t	2025-08-14 12:35:27.969579	{"type": "object", "properties": {"limit": {"type": "integer", "default": 8, "maximum": 24, "minimum": 1}, "order_by": {"enum": ["product_count_desc", "name_asc", "created_desc"], "type": "string", "default": "product_count_desc"}, "selected_category_ids": {"type": "array", "items": {"type": "integer"}, "minItems": 5, "uniqueItems": true}}, "additionalProperties": false}	{"form": {"fields": [{"name": "selected_category_ids", "type": "async-checkboxes", "label": "Categories to show", "source": "/web/categories-with-count", "labelKey": "name_with_count", "minItems": 5, "valueKey": "category_id", "description": "Pick at least 5. If left empty, all active categories will be shown."}, {"max": 24, "min": 1, "name": "limit", "step": 1, "type": "number", "label": "Max categories to show", "default": 8}, {"name": "order_by", "type": "select", "label": "Order by", "default": "product_count_desc", "options": [["product_count_desc", "Most products first"], ["name_asc", "Name A–Z"], ["created_desc", "Newest first"]]}]}}	{"limit": 8, "order_by": "product_count_desc", "selected_category_ids": [12, 15, 17]}
25	3	BeautyFeatured	Beauty Featured	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170069-3_3.png	active	2	t	2025-08-14 12:35:27.969579	{"type": "object", "properties": {"limit": {"type": "integer", "default": 3, "maximum": 12, "minimum": 1}, "selected_product_ids": {"type": "array", "items": {"type": "integer"}, "minItems": 3, "uniqueItems": true}}, "additionalProperties": false}	{"form": {"fields": [{"name": "selected_product_ids", "type": "async-checkboxes", "label": "Pick featured products", "source": "/web/featured_products", "labelKey": "name_with_price", "minItems": 3, "valueKey": "product_id", "description": "Choose up to 12. If left empty, we will show the top products in the Featured collection."}, {"max": 12, "min": 1, "name": "limit", "step": 1, "type": "number", "label": "Max items to show", "default": 3}]}}	{"limit": 3, "selected_product_ids": []}
27	3	BeautyOfferBanner	Beauty Offer Banner	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170486-3_5.png	active	4	t	2025-08-14 12:35:27.969579	{"type": "object", "required": ["banners"], "properties": {"banners": {"type": "array", "items": {"type": "object", "required": ["collection_id", "image_url"], "properties": {"image_url": {"type": "string"}, "collection_id": {"type": "integer"}}, "additionalProperties": false}, "maxItems": 2, "minItems": 2}}, "additionalProperties": false}	{"form": {"fields": [{"name": "banners", "type": "async-collection-banners", "label": "Pick exactly 2 collections and add a banner image for each", "limit": 2, "source": "/web/getallcollections", "labelKey": "name", "valueKey": "collection_id", "imageLabel": "Banner image URL"}]}}	{"banners": []}
28	3	ProductAreaTwo	Product Area Two	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170609-3_6.png	active	5	t	2025-08-14 12:35:27.969579	{"type": "object", "required": ["groups"], "properties": {"groups": {"type": "array", "items": {"type": "object", "required": ["collection_id", "product_ids"], "properties": {"product_ids": {"type": "array", "items": {"type": "integer"}, "maxItems": 8, "minItems": 1, "uniqueItems": true}, "collection_id": {"type": "integer"}}, "additionalProperties": false}, "maxItems": 4, "minItems": 1}}, "additionalProperties": false}	{"form": {"fields": [{"name": "groups", "type": "collection-products-picker", "label": "Pick up to 4 collections, then choose up to 8 products in each", "products": {"source": "/web/collections/{collection_id}/products", "descKey": "search_engine_desc", "imageKey": "media_url", "labelKey": "title", "priceKey": "price", "valueKey": "product_id"}, "collections": {"source": "/web/getallcollections", "labelKey": "name", "valueKey": "collection_id"}, "productLimit": 8, "collectionLimit": 4}]}}	{"groups": []}
29	3	TrendingSpecialPrd	Special Product	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170681-3_7.png	active	6	t	2025-08-14 12:35:27.969579	{"type": "object", "required": ["left_image_url", "right_bg_color"], "properties": {"left_image_url": {"type": "string", "format": "uri"}, "right_bg_color": {"type": "string", "pattern": "^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$"}, "selected_product_ids": {"type": "array", "items": {"type": "integer"}, "default": [], "maxItems": 4, "minItems": 0, "uniqueItems": true}}, "additionalProperties": false}	{"form": {"fields": [{"name": "left_image_url", "type": "image", "label": "Left banner image"}, {"name": "right_bg_color", "type": "text", "label": "Right panel background color (HEX)", "default": "#E9EEF6"}, {"name": "selected_product_ids", "type": "async-checkboxes", "label": "Products to show", "source": "/web/special_products", "labelKey": "name_with_price", "maxItems": 4, "valueKey": "product_id", "description": "Pick up to 4 products."}]}}	{"left_image_url": "", "right_bg_color": "#E9EEF6", "selected_product_ids": []}
31	3	FeatureAreaTwo	Feature Area	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170822-3_9.png	active	7	t	2025-08-14 12:35:27.969579	{"type": "object", "required": ["features"], "properties": {"features": {"type": "array", "items": {"type": "object", "required": ["icon_url", "title", "description"], "properties": {"title": {"type": "string", "maxLength": 28}, "icon_url": {"type": "string", "format": "uri"}, "description": {"type": "string", "maxLength": 80}}, "additionalProperties": false}, "maxItems": 4, "minItems": 4}}, "additionalProperties": false}	{"form": {"fields": [{"max": 4, "min": 4, "name": "features", "type": "array", "label": "Service highlights (exactly 4)", "fields": [{"name": "icon_url", "type": "image", "label": "Icon URL (PNG/SVG)"}, {"max": 28, "name": "title", "type": "text", "label": "Title", "description": "Keep short (≤ 28 characters) for a tidy layout."}, {"max": 80, "name": "description", "type": "textarea", "label": "Description", "description": "One concise line (≤ 80 characters)."}], "itemLabel": "Item"}]}}	{"features": [{"title": "Free Delivery", "icon_url": "https://example.com/icons/truck.svg", "description": "Orders from all items"}, {"title": "Return & Refund", "icon_url": "https://example.com/icons/return.svg", "description": "Money-back guarantee"}, {"title": "Member Discount", "icon_url": "https://example.com/icons/badge.svg", "description": "On every order over $140"}, {"title": "Support 24/7", "icon_url": "https://example.com/icons/headset.svg", "description": "Contact us any time"}]}
32	3	InstagramAreaThree	Instagram	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/1754578170888-3_10.png	active	\N	f	2025-08-14 12:35:27.969579	{"type": "object", "required": ["images"], "properties": {"images": {"type": "array", "items": {"type": "object", "required": ["image_url"], "properties": {"alt": {"type": "string", "maxLength": 80}, "link_url": {"type": "string", "format": "uri"}, "image_url": {"type": "string", "format": "uri"}}, "additionalProperties": false}, "maxItems": 6, "minItems": 3}}, "additionalProperties": false}	{"form": {"fields": [{"max": 6, "min": 3, "name": "images", "type": "array", "label": "Gallery images (3–6)", "fields": [{"name": "image_url", "type": "image", "label": "Image URL (required)"}, {"max": 80, "name": "alt", "type": "text", "label": "Alt text (optional)"}, {"name": "link_url", "type": "url", "label": "Link URL (optional)"}], "itemLabel": "Image"}]}}	{"images": [{"alt": "Gallery image 1", "link_url": "", "image_url": "https://picsum.photos/seed/beauty-1/800/600"}, {"alt": "Gallery image 2", "link_url": "", "image_url": "https://picsum.photos/seed/beauty-2/800/600"}, {"alt": "Gallery image 3", "link_url": "", "image_url": "https://picsum.photos/seed/beauty-3/800/600"}]}
23	3	BeautyBanner	Beauty Banner	https://d8y1.c2.e2-9.dev/spark-files/1754578075654-20250807144755-3_1.png	active	0	t	2025-10-02 12:07:02.80323	{"type": "object", "required": ["slides"], "properties": {"slides": {"type": "array", "items": {"type": "object", "required": ["background_image", "title"], "properties": {"icon": {"type": "string", "title": "Icon", "format": "uri"}, "title": {"type": "string", "title": "Title", "maxLength": 120}, "subtitle": {"type": "string", "title": "Subtitle", "maxLength": 240}, "icon_title": {"type": "string", "title": "Icon Title", "maxLength": 120}, "background_image": {"type": "string", "title": "Background Image", "format": "uri"}, "background_mobile_image": {"type": "string", "title": "Background Mobile Image", "format": "uri"}}}}, "autoplay": {"type": "boolean", "default": true}, "interval_ms": {"type": "integer", "default": 5000, "minimum": 1000}, "title_color": {"type": "string", "default": "#111111"}, "subtitle_color": {"type": "string", "default": "#555555"}, "icon_title_color": {"type": "string", "default": "#222222"}}}	{"form": {"fields": [{"name": "autoplay", "type": "switch", "label": "Autoplay", "default": true}, {"name": "interval_ms", "type": "number", "label": "Interval (ms)", "default": 5000}, {"name": "title_color", "type": "color", "label": "Title Color"}, {"name": "subtitle_color", "type": "color", "label": "Subtitle Color"}, {"name": "icon_title_color", "type": "color", "label": "Icon Title Color"}, {"name": "slides", "type": "array", "label": "Slides", "fields": [{"name": "background_image", "type": "image", "label": "Background Image"}, {"name": "background_mobile_image", "type": "image", "label": "Background Mobile Image"}, {"name": "icon", "type": "image", "label": "Icon"}, {"name": "title", "type": "text", "label": "Title"}, {"name": "icon_title", "type": "text", "label": "Icon Title"}, {"name": "subtitle", "type": "text", "label": "Subtitle"}]}]}}	{"slides": [{"icon": "https://example.com/icon.png", "title": "Winter Collection 2025", "subtitle": "A world of beauty", "icon_title": "Diamond Necklaces", "background_image": "https://example.com/slider.png"}], "autoplay": true, "interval_ms": 5000, "title_color": "#111111", "subtitle_color": "#555555", "icon_title_color": "#222222"}
\.


--
-- Data for Name: web_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_templates (id, name, description, image, status) FROM stdin;
3	Beauty & Cosmetics	Creative Visual Designer Portfolio	https://d8y1.c2.e2-9.dev/spark-files/1752303996290-20250712070634-temp3.png	active
1	Jewellery	Restaurant & Bistro HTML5 Template	https://d8y1.c2.e2-9.dev/spark-files/1752303780110-20250712070258-temp1.png	inactive
2	Fashion	Creative Portfolio Template	https://d8y1.c2.e2-9.dev/spark-files/1752303874601-20250712070433-temp2.png	inactive
4	Electonics and Mobile	Multipurpose Admin Dashboard Template	https://d8y1.c2.e2-9.dev/spark-files/1752304045817-20250712070724-temp4.png	inactive
5	Small Business	Multipurpose Small Business Website Template	https://d8y1.c2.e2-9.dev/ozonefiles/Product_Media/17597492067077-template5.webp	inactive
\.


--
-- Data for Name: zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.zone (id, zone_name, status) FROM stdin;
\.


--
-- Name: Ingredients_stock_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Ingredients_stock_header_id_seq"', 1, false);


--
-- Name: account_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_categories_category_id_seq', 1, true);


--
-- Name: account_statement_acc_statement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_statement_acc_statement_id_seq', 1, true);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_id_seq', 6, true);


--
-- Name: accounts_payer_payee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_payer_payee_id_seq', 2, true);


--
-- Name: admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_log_id_seq', 1, true);


--
-- Name: admin_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_user_id_seq', 40, true);


--
-- Name: appreciations_appreciation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.appreciations_appreciation_id_seq', 1, true);


--
-- Name: attendance_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_attendance_id_seq', 1, true);


--
-- Name: attendance_status_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_status_status_id_seq', 1, true);


--
-- Name: batch_management_batch_management_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_management_batch_management_id_seq', 1, true);


--
-- Name: branch_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branch_branch_id_seq', 1, true);


--
-- Name: brand_brand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.brand_brand_id_seq', 1, true);


--
-- Name: branding_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branding_settings_id_seq', 2, true);


--
-- Name: bulk_dispatched_history_bulk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bulk_dispatched_history_bulk_id_seq', 1, true);


--
-- Name: card_terminal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.card_terminal_id_seq', 2, true);


--
-- Name: card_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.card_types_id_seq', 5, true);


--
-- Name: categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_category_id_seq', 1, true);


--
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_client_id_seq', 1, false);


--
-- Name: collections_collection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.collections_collection_id_seq', 6, true);


--
-- Name: components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.components_id_seq', 3, true);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.countries_id_seq', 190, true);


--
-- Name: credit_card_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_card_transaction_id_seq', 1, true);


--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 1, true);


--
-- Name: dashboard_widgets_widget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dashboard_widgets_widget_id_seq', 11, true);


--
-- Name: delivery_fee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delivery_fee_id_seq', 3, true);


--
-- Name: delivery_partners_partner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delivery_partners_partner_id_seq', 5, true);


--
-- Name: departments_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departments_department_id_seq', 1, false);


--
-- Name: designations_designation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.designations_designation_id_seq', 1, true);


--
-- Name: designations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.designations_id_seq', 1, false);


--
-- Name: device_management_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_management_device_id_seq', 4, true);


--
-- Name: device_management_till_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_management_till_id_seq', 1, false);


--
-- Name: discount_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.discount_usage_id_seq', 1, true);


--
-- Name: discounts_discount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.discounts_discount_id_seq', 1, true);


--
-- Name: earnings_deductions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.earnings_deductions_id_seq', 1, true);


--
-- Name: email_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_template_id_seq', 7, true);


--
-- Name: employee_documents_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_documents_document_id_seq', 1, true);


--
-- Name: employee_logs_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_logs_log_id_seq', 1, true);


--
-- Name: employee_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_profiles_id_seq', 1, true);


--
-- Name: employee_remarks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_remarks_id_seq', 1, true);


--
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 1, true);


--
-- Name: employment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employment_id_seq', 1, true);


--
-- Name: farder_webhook_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.farder_webhook_logs_id_seq', 1, true);


--
-- Name: grn_header_grn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grn_header_grn_id_seq', 1, true);


--
-- Name: grn_items_grn_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grn_items_grn_item_id_seq', 1, true);


--
-- Name: hero_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hero_section_id_seq', 1, true);


--
-- Name: holidays_holiday_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.holidays_holiday_id_seq', 1, true);


--
-- Name: increments_and_promotions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.increments_and_promotions_id_seq', 1, true);


--
-- Name: ingredients_stock_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ingredients_stock_details_id_seq', 1, true);


--
-- Name: ingredients_stock_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ingredients_stock_header_id_seq', 1, true);


--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_inventory_id_seq', 1, true);


--
-- Name: inventory_strategy_inventory_strategy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_strategy_inventory_strategy_id_seq', 4, true);


--
-- Name: invoice_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_details_id_seq', 1, true);


--
-- Name: invoice_details_order_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_details_order_item_id_seq', 1, false);


--
-- Name: invoice_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_header_id_seq', 1, true);


--
-- Name: invoice_header_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_header_order_id_seq', 1, false);


--
-- Name: invoice_payment_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_payment_history_id_seq', 1, true);


--
-- Name: job_bill_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_bill_item_id_seq', 1, true);


--
-- Name: job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_id_seq', 1, false);


--
-- Name: job_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_log_log_id_seq', 1, true);


--
-- Name: job_other_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_other_service_id_seq', 1, true);


--
-- Name: kitchen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kitchen_id_seq', 2, true);


--
-- Name: kitchen_order_lines_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kitchen_order_lines_header_id_seq', 1, true);


--
-- Name: kitchen_order_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kitchen_order_lines_id_seq', 1, true);


--
-- Name: leave_types_leave_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_types_leave_type_id_seq', 1, true);


--
-- Name: leaves_leave_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leaves_leave_id_seq', 1, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logs_id_seq', 1, true);


--
-- Name: material_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_inventory_id_seq', 1, true);


--
-- Name: measurements_measurement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.measurements_measurement_id_seq', 6, true);


--
-- Name: merchant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.merchant_id_seq', 20000, false);


--
-- Name: merchants_merchant_id_int_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.merchants_merchant_id_int_seq', 20001, true);


--
-- Name: merchants_merchant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.merchants_merchant_id_seq', 20002, true);


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_notification_id_seq', 1, true);


--
-- Name: order_bulk_prints_bulk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_bulk_prints_bulk_id_seq', 1, true);


--
-- Name: order_items_order_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_order_item_id_seq', 1, true);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 1, true);


--
-- Name: outlets_outlet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.outlets_outlet_id_seq', 2, true);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pages_id_seq', 1, true);


--
-- Name: payment_methods_payment_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_methods_payment_method_id_seq', 7, true);


--
-- Name: payroll_template_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_template_details_id_seq', 1, true);


--
-- Name: payroll_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_templates_id_seq', 1, true);


--
-- Name: paysheet_details_paysheet_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paysheet_details_paysheet_detail_id_seq', 1, true);


--
-- Name: paysheet_invoices_paysheet_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paysheet_invoices_paysheet_invoice_id_seq', 1, true);


--
-- Name: paysheets_paysheet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paysheets_paysheet_id_seq', 1, true);


--
-- Name: pick_from_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pick_from_client_id_seq', 1, true);


--
-- Name: plugins_plugin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plugins_plugin_id_seq', 2, true);


--
-- Name: po_header_po_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.po_header_po_header_id_seq', 1, false);


--
-- Name: po_header_po_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.po_header_po_id_seq', 1, true);


--
-- Name: po_items_po_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.po_items_po_item_id_seq', 1, true);


--
-- Name: points_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_logs_id_seq', 1, true);


--
-- Name: portal_interface_interface_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.portal_interface_interface_id_seq', 2, true);


--
-- Name: prn_header_prn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.prn_header_prn_id_seq', 1, true);


--
-- Name: prn_items_prn_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.prn_items_prn_item_id_seq', 1, true);


--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_id_seq', 100, false);


--
-- Name: product_media_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_media_media_id_seq', 1, true);


--
-- Name: product_reviews_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_reviews_review_id_seq', 1, true);


--
-- Name: product_variants_variant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_variants_variant_id_seq', 1, true);


--
-- Name: production_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_details_id_seq', 1, true);


--
-- Name: production_details_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_details_product_id_seq', 1, true);


--
-- Name: production_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_header_id_seq', 1, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_product_id_seq', 1, true);


--
-- Name: quotation_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotation_details_id_seq', 1, true);


--
-- Name: quotation_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotation_header_id_seq', 1, true);


--
-- Name: raw_material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.raw_material_id_seq', 1, true);


--
-- Name: reasons_reason_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reasons_reason_id_seq', 11, true);


--
-- Name: recipe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recipe_id_seq', 1, true);


--
-- Name: reorder_level_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reorder_level_id_seq', 1, false);


--
-- Name: reorder_level_removed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reorder_level_removed_id_seq', 1, true);


--
-- Name: restaurant_tables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.restaurant_tables_id_seq', 2, true);


--
-- Name: return_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.return_token_id_seq', 1, true);


--
-- Name: role_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_list_id_seq', 2, true);


--
-- Name: sales_channel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_channel_id_seq', 2, true);


--
-- Name: send_email_temp_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.send_email_temp_log_id_seq', 1, true);


--
-- Name: send_sms_temp_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.send_sms_temp_log_id_seq', 1, true);


--
-- Name: shift_roster_roster_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shift_roster_roster_id_seq', 1, true);


--
-- Name: shifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shifts_id_seq', 1, true);


--
-- Name: shopping_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shopping_list_id_seq', 1, true);


--
-- Name: site_section_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_section_configs_id_seq', 227, true);


--
-- Name: sms_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_action_id_seq', 14, true);


--
-- Name: sms_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_template_id_seq', 7, true);


--
-- Name: stock_sheet_details_sheet_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_sheet_details_sheet_details_id_seq', 1, true);


--
-- Name: stock_sheet_header_sheet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_sheet_header_sheet_id_seq', 1, true);


--
-- Name: supplier_payments_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_payments_payment_id_seq', 1, true);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_supplier_id_seq', 1, true);


--
-- Name: system_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_log_id_seq', 1, false);


--
-- Name: system_settings_billing_servise_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_billing_servise_id_seq', 1, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 2, true);


--
-- Name: table_management_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.table_management_id_seq', 1, true);


--
-- Name: tags_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_tag_id_seq', 1, true);


--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_transaction_id_seq', 1, true);


--
-- Name: uimenudata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.uimenudata_id_seq', 251, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_id_seq', 2, true);


--
-- Name: variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.variants_id_seq', 1, true);


--
-- Name: voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.voucher_id_seq', 1, true);


--
-- Name: waybills_waybill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.waybills_waybill_id_seq', 1, true);


--
-- Name: web_page_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.web_page_components_id_seq', 1, true);


--
-- Name: web_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.web_pages_id_seq', 7, true);


--
-- Name: web_template_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.web_template_sections_id_seq', 47, true);


--
-- Name: web_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.web_templates_id_seq', 6, true);


--
-- Name: zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.zone_id_seq', 1, true);


--
-- Name: ingredients_stock_header Ingredients_stock_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_stock_header
    ADD CONSTRAINT "Ingredients_stock_header_pkey" PRIMARY KEY (id);


--
-- Name: account_categories account_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_categories
    ADD CONSTRAINT account_categories_pkey PRIMARY KEY (category_id);


--
-- Name: account_statement account_statement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_statement
    ADD CONSTRAINT account_statement_pkey PRIMARY KEY (acc_statement_id);


--
-- Name: accounts_payer_payee accounts_payer_payee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payer_payee
    ADD CONSTRAINT accounts_payer_payee_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: admin_log admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_log
    ADD CONSTRAINT admin_log_pkey PRIMARY KEY (id);


--
-- Name: users admin_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT admin_user_pkey PRIMARY KEY (user_id);


--
-- Name: users admin_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT admin_user_username_key UNIQUE (username);


--
-- Name: appreciations appreciations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appreciations
    ADD CONSTRAINT appreciations_pkey PRIMARY KEY (appreciation_id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (attendance_id);


--
-- Name: attendance_status attendance_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_status
    ADD CONSTRAINT attendance_status_pkey PRIMARY KEY (status_id);


--
-- Name: batch_management batch_management_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_management
    ADD CONSTRAINT batch_management_pkey PRIMARY KEY (batch_management_id);


--
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (branch_id);


--
-- Name: brand brand_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand
    ADD CONSTRAINT brand_name_key UNIQUE (name);


--
-- Name: brand brand_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand
    ADD CONSTRAINT brand_pkey PRIMARY KEY (brand_id);


--
-- Name: branding_settings branding_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_settings
    ADD CONSTRAINT branding_settings_pkey PRIMARY KEY (id);


--
-- Name: bulk_dispatched_history bulk_dispatched_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_dispatched_history
    ADD CONSTRAINT bulk_dispatched_history_pkey PRIMARY KEY (bulk_id);


--
-- Name: card_terminal card_terminal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_terminal
    ADD CONSTRAINT card_terminal_pkey PRIMARY KEY (id);


--
-- Name: card_types card_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_types
    ADD CONSTRAINT card_types_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (category_id);


--
-- Name: customer client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT client_pkey PRIMARY KEY (customer_id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (collection_id);


--
-- Name: components components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.components
    ADD CONSTRAINT components_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: credit_card_transaction credit_card_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_card_transaction
    ADD CONSTRAINT credit_card_transaction_pkey PRIMARY KEY (id);


--
-- Name: dashboard_widgets dashboard_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_pkey PRIMARY KEY (widget_id);


--
-- Name: delivery_fee delivery_fee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_fee
    ADD CONSTRAINT delivery_fee_pkey PRIMARY KEY (id);


--
-- Name: delivery_partners delivery_partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_partners
    ADD CONSTRAINT delivery_partners_pkey PRIMARY KEY (partner_id);


--
-- Name: departments departments_department_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_department_name_key UNIQUE (department_name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_id);


--
-- Name: designations designations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.designations
    ADD CONSTRAINT designations_pkey PRIMARY KEY (designation_id);


--
-- Name: device_management device_management_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_management
    ADD CONSTRAINT device_management_pkey PRIMARY KEY (device_id);


--
-- Name: discount_usage discount_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_usage
    ADD CONSTRAINT discount_usage_pkey PRIMARY KEY (id);


--
-- Name: discounts discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discounts
    ADD CONSTRAINT discounts_pkey PRIMARY KEY (discount_id);


--
-- Name: earnings_deductions earnings_deductions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earnings_deductions
    ADD CONSTRAINT earnings_deductions_pkey PRIMARY KEY (id);


--
-- Name: email_template email_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_pkey PRIMARY KEY (id);


--
-- Name: employee_documents employee_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents
    ADD CONSTRAINT employee_documents_pkey PRIMARY KEY (document_id);


--
-- Name: employee_logs employee_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_logs
    ADD CONSTRAINT employee_logs_pkey PRIMARY KEY (log_id);


--
-- Name: employee_profiles employee_profiles_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_profiles
    ADD CONSTRAINT employee_profiles_email_key UNIQUE (email);


--
-- Name: employee_profiles employee_profiles_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_profiles
    ADD CONSTRAINT employee_profiles_employee_id_key UNIQUE (employee_id);


--
-- Name: employee_profiles employee_profiles_nic_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_profiles
    ADD CONSTRAINT employee_profiles_nic_key UNIQUE (nic);


--
-- Name: employee_profiles employee_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_profiles
    ADD CONSTRAINT employee_profiles_pkey PRIMARY KEY (id);


--
-- Name: employee_remarks employee_remarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_remarks
    ADD CONSTRAINT employee_remarks_pkey PRIMARY KEY (id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_nic_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_nic_key UNIQUE (nic);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: employment employment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employment
    ADD CONSTRAINT employment_pkey PRIMARY KEY (id);


--
-- Name: farder_webhook_logs farder_webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farder_webhook_logs
    ADD CONSTRAINT farder_webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: grn_header grn_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_header
    ADD CONSTRAINT grn_header_pkey PRIMARY KEY (grn_id);


--
-- Name: grn_items grn_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items
    ADD CONSTRAINT grn_items_pkey PRIMARY KEY (grn_item_id);


--
-- Name: hero_section hero_section_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_section
    ADD CONSTRAINT hero_section_pkey PRIMARY KEY (id);


--
-- Name: holidays holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.holidays
    ADD CONSTRAINT holidays_pkey PRIMARY KEY (holiday_id);


--
-- Name: increments_and_promotions increments_and_promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.increments_and_promotions
    ADD CONSTRAINT increments_and_promotions_pkey PRIMARY KEY (id);


--
-- Name: ingredients_stock_details ingredients_stock_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_stock_details
    ADD CONSTRAINT ingredients_stock_details_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id);


--
-- Name: inventory_strategy inventory_strategy_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_strategy
    ADD CONSTRAINT inventory_strategy_name_key UNIQUE (name);


--
-- Name: inventory_strategy inventory_strategy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_strategy
    ADD CONSTRAINT inventory_strategy_pkey PRIMARY KEY (inventory_strategy_id);


--
-- Name: invoice_details invoice_details_invoice_item_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_details
    ADD CONSTRAINT invoice_details_invoice_item_uid_key UNIQUE (invoice_item_uid);


--
-- Name: invoice_details invoice_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_details
    ADD CONSTRAINT invoice_details_pkey PRIMARY KEY (id);


--
-- Name: invoice_header invoice_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_pkey PRIMARY KEY (id);


--
-- Name: invoice_payment_history invoice_payment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payment_history
    ADD CONSTRAINT invoice_payment_history_pkey PRIMARY KEY (id);


--
-- Name: job_bill_item job_bill_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_bill_item
    ADD CONSTRAINT job_bill_item_pkey PRIMARY KEY (id);


--
-- Name: job_log job_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_log
    ADD CONSTRAINT job_log_pkey PRIMARY KEY (log_id);


--
-- Name: job_other_service job_other_service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_other_service
    ADD CONSTRAINT job_other_service_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (id);


--
-- Name: kitchen_order_lines_header kitchen_order_lines_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kitchen_order_lines_header
    ADD CONSTRAINT kitchen_order_lines_header_pkey PRIMARY KEY (id);


--
-- Name: kitchen_order_lines kitchen_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kitchen_order_lines
    ADD CONSTRAINT kitchen_order_lines_pkey PRIMARY KEY (id);


--
-- Name: kitchen kitchen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kitchen
    ADD CONSTRAINT kitchen_pkey PRIMARY KEY (id);


--
-- Name: leave_types leave_types_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_name_key UNIQUE (name);


--
-- Name: leave_types leave_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_pkey PRIMARY KEY (leave_type_id);


--
-- Name: leaves leaves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leaves
    ADD CONSTRAINT leaves_pkey PRIMARY KEY (leave_id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: material_inventory material_inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_inventory
    ADD CONSTRAINT material_inventory_pkey PRIMARY KEY (id);


--
-- Name: measurements measurements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.measurements
    ADD CONSTRAINT measurements_pkey PRIMARY KEY (measurement_id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (merchant_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: order_bulk_prints order_bulk_prints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_bulk_prints
    ADD CONSTRAINT order_bulk_prints_pkey PRIMARY KEY (bulk_id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (order_item_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: outlets outlets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outlets
    ADD CONSTRAINT outlets_pkey PRIMARY KEY (outlet_id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key UNIQUE (slug);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (payment_method_id);


--
-- Name: payroll_template_details payroll_template_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_template_details
    ADD CONSTRAINT payroll_template_details_pkey PRIMARY KEY (id);


--
-- Name: payroll_templates payroll_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_templates
    ADD CONSTRAINT payroll_templates_pkey PRIMARY KEY (id);


--
-- Name: paysheet_details paysheet_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_details
    ADD CONSTRAINT paysheet_details_pkey PRIMARY KEY (paysheet_detail_id);


--
-- Name: paysheet_invoices paysheet_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_invoices
    ADD CONSTRAINT paysheet_invoices_pkey PRIMARY KEY (paysheet_invoice_id);


--
-- Name: paysheets paysheets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheets
    ADD CONSTRAINT paysheets_pkey PRIMARY KEY (paysheet_id);


--
-- Name: pick_from_client pick_from_client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pick_from_client
    ADD CONSTRAINT pick_from_client_pkey PRIMARY KEY (id);


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (plugin_id);


--
-- Name: po_header po_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_header
    ADD CONSTRAINT po_header_pkey PRIMARY KEY (po_id);


--
-- Name: po_items po_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_items
    ADD CONSTRAINT po_items_pkey PRIMARY KEY (po_item_id);


--
-- Name: points_logs points_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_logs
    ADD CONSTRAINT points_logs_pkey PRIMARY KEY (id);


--
-- Name: portal_interface portal_interface_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_interface
    ADD CONSTRAINT portal_interface_pkey PRIMARY KEY (interface_id);


--
-- Name: pos_settings pos_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT pos_settings_pkey PRIMARY KEY (id);


--
-- Name: prn_header prn_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_header
    ADD CONSTRAINT prn_header_pkey PRIMARY KEY (prn_id);


--
-- Name: prn_items prn_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_items
    ADD CONSTRAINT prn_items_pkey PRIMARY KEY (prn_item_id);


--
-- Name: product_brands product_brands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_brands
    ADD CONSTRAINT product_brands_pkey PRIMARY KEY (product_id, brand_id);


--
-- Name: product_media product_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_media
    ADD CONSTRAINT product_media_pkey PRIMARY KEY (media_id);


--
-- Name: product_reviews product_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_pkey PRIMARY KEY (review_id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (variant_id);


--
-- Name: production_details production_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_details
    ADD CONSTRAINT production_details_pkey PRIMARY KEY (id);


--
-- Name: production_details_product production_details_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_details_product
    ADD CONSTRAINT production_details_product_pkey PRIMARY KEY (id);


--
-- Name: production_header production_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_header
    ADD CONSTRAINT production_header_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: quotation_details quotation_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_details
    ADD CONSTRAINT quotation_details_pkey PRIMARY KEY (id);


--
-- Name: quotation_header quotation_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_header
    ADD CONSTRAINT quotation_header_pkey PRIMARY KEY (id);


--
-- Name: raw_material raw_material_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.raw_material
    ADD CONSTRAINT raw_material_pkey PRIMARY KEY (id);


--
-- Name: reasons reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reasons
    ADD CONSTRAINT reasons_pkey PRIMARY KEY (reason_id);


--
-- Name: recipe recipe_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT recipe_pkey PRIMARY KEY (id);


--
-- Name: reorder_level reorder_level_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reorder_level
    ADD CONSTRAINT reorder_level_pkey PRIMARY KEY (id);


--
-- Name: restaurant_tables restaurant_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_tables
    ADD CONSTRAINT restaurant_tables_pkey PRIMARY KEY (id);


--
-- Name: return_token return_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_token
    ADD CONSTRAINT return_token_pkey PRIMARY KEY (id);


--
-- Name: role_list role_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_list
    ADD CONSTRAINT role_list_pkey PRIMARY KEY (id);


--
-- Name: sales_channel sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_channel
    ADD CONSTRAINT sales_channel_pkey PRIMARY KEY (id);


--
-- Name: send_email_temp_log send_email_temp_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.send_email_temp_log
    ADD CONSTRAINT send_email_temp_log_pkey PRIMARY KEY (id);


--
-- Name: send_sms_temp_log send_sms_temp_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.send_sms_temp_log
    ADD CONSTRAINT send_sms_temp_log_pkey PRIMARY KEY (id);


--
-- Name: shift_roster shift_roster_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_roster
    ADD CONSTRAINT shift_roster_pkey PRIMARY KEY (roster_id);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (id);


--
-- Name: shopping_list shopping_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_list
    ADD CONSTRAINT shopping_list_pkey PRIMARY KEY (id);


--
-- Name: site_section_configs site_section_configs_merchant_id_template_section_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_section_configs
    ADD CONSTRAINT site_section_configs_merchant_id_template_section_id_key UNIQUE (merchant_id, template_section_id);


--
-- Name: site_section_configs site_section_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_section_configs
    ADD CONSTRAINT site_section_configs_pkey PRIMARY KEY (id);


--
-- Name: sms_action sms_action_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_action
    ADD CONSTRAINT sms_action_pkey PRIMARY KEY (id);


--
-- Name: sms_template sms_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_template
    ADD CONSTRAINT sms_template_pkey PRIMARY KEY (id);


--
-- Name: stock_sheet_details stock_sheet_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_details
    ADD CONSTRAINT stock_sheet_details_pkey PRIMARY KEY (sheet_details_id);


--
-- Name: stock_sheet_header stock_sheet_header_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_header
    ADD CONSTRAINT stock_sheet_header_pkey PRIMARY KEY (sheet_id);


--
-- Name: supplier_payments supplier_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_pkey PRIMARY KEY (payment_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplier_id);


--
-- Name: system_log system_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_log
    ADD CONSTRAINT system_log_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: table_management table_management_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_management
    ADD CONSTRAINT table_management_name_key UNIQUE (name);


--
-- Name: table_management table_management_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_management
    ADD CONSTRAINT table_management_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (tag_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: uimenudata uimenudata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uimenudata
    ADD CONSTRAINT uimenudata_pkey PRIMARY KEY (id);


--
-- Name: shift_roster unique_employee_shift_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_roster
    ADD CONSTRAINT unique_employee_shift_date UNIQUE (employee_id, shift_id, roster_date);


--
-- Name: product_category unique_product_category; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT unique_product_category UNIQUE (product_id);


--
-- Name: product_collections unique_product_collections; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_collections
    ADD CONSTRAINT unique_product_collections UNIQUE (product_id, collection_id);


--
-- Name: product_variants unique_product_variant_type_value; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT unique_product_variant_type_value UNIQUE (product_id, variant_type, variant_value);


--
-- Name: user_backup users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_backup
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: user_backup users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_backup
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: user_backup users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_backup
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: variants variants_option_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variants
    ADD CONSTRAINT variants_option_name_key UNIQUE (option_name);


--
-- Name: variants variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variants
    ADD CONSTRAINT variants_pkey PRIMARY KEY (id);


--
-- Name: waybills waybills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_pkey PRIMARY KEY (waybill_id);


--
-- Name: web_page_components web_page_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_components
    ADD CONSTRAINT web_page_components_pkey PRIMARY KEY (id);


--
-- Name: web_pages web_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_pages
    ADD CONSTRAINT web_pages_pkey PRIMARY KEY (id);


--
-- Name: web_pages web_pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_pages
    ADD CONSTRAINT web_pages_slug_key UNIQUE (slug);


--
-- Name: web_template_sections web_template_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_template_sections
    ADD CONSTRAINT web_template_sections_pkey PRIMARY KEY (id);


--
-- Name: web_templates web_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_templates
    ADD CONSTRAINT web_templates_pkey PRIMARY KEY (id);


--
-- Name: zone zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zone
    ADD CONSTRAINT zone_pkey PRIMARY KEY (id);


--
-- Name: idx_job_bill_item_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_job_bill_item_job_id ON public.job_bill_item USING btree (job_id);


--
-- Name: idx_shifts_weekday; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shifts_weekday ON public.shifts USING btree (weekday);


--
-- Name: idx_site_section_configs_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_section_configs_gin ON public.site_section_configs USING gin (config);


--
-- Name: idx_site_section_configs_merchant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_section_configs_merchant ON public.site_section_configs USING btree (merchant_id);


--
-- Name: idx_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_status ON public.send_sms_temp_log USING btree (status);


--
-- Name: branding_settings set_timestamp; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_timestamp BEFORE UPDATE ON public.branding_settings FOR EACH ROW EXECUTE FUNCTION public.update_timestamp_column();


--
-- Name: orders trg_set_status_timestamps; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_status_timestamps BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.set_status_timestamps();


--
-- Name: accounts trg_update_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_update_accounts_updated_at BEFORE UPDATE ON public.accounts FOR EACH ROW EXECUTE FUNCTION public.update_accounts_updated_at();


--
-- Name: users trigger_update_admin_user; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_admin_user BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: attendance attendance_attendance_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_attendance_status_id_fkey FOREIGN KEY (attendance_status_id) REFERENCES public.attendance_status(status_id) ON DELETE SET NULL;


--
-- Name: attendance_status attendance_status_holiday_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_status
    ADD CONSTRAINT attendance_status_holiday_id_fkey FOREIGN KEY (holiday_id) REFERENCES public.holidays(holiday_id) ON DELETE SET NULL;


--
-- Name: attendance_status attendance_status_leave_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_status
    ADD CONSTRAINT attendance_status_leave_id_fkey FOREIGN KEY (leave_id) REFERENCES public.leaves(leave_id) ON DELETE SET NULL;


--
-- Name: bulk_dispatched_history bulk_dispatched_history_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_dispatched_history
    ADD CONSTRAINT bulk_dispatched_history_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: bulk_dispatched_history bulk_dispatched_history_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_dispatched_history
    ADD CONSTRAINT bulk_dispatched_history_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.delivery_partners(partner_id) ON DELETE CASCADE;


--
-- Name: categories categories_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id);


--
-- Name: collections collections_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id);


--
-- Name: discount_usage discount_usage_discount_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_usage
    ADD CONSTRAINT discount_usage_discount_id_fkey FOREIGN KEY (discount_id) REFERENCES public.discounts(discount_id);


--
-- Name: discount_usage discount_usage_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_usage
    ADD CONSTRAINT discount_usage_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: account_statement fk_account; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_statement
    ADD CONSTRAINT fk_account FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_categories fk_account_categories_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_categories
    ADD CONSTRAINT fk_account_categories_created_by FOREIGN KEY (created_by) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accounts fk_accounts_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT fk_accounts_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users fk_admin_user_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_admin_user_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON DELETE SET NULL;


--
-- Name: appreciations fk_appreciation_employee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appreciations
    ADD CONSTRAINT fk_appreciation_employee FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: attendance fk_attendance_employee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT fk_attendance_employee FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: attendance fk_attendance_roster; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT fk_attendance_roster FOREIGN KEY (roster_id) REFERENCES public.shift_roster(roster_id) ON DELETE SET NULL;


--
-- Name: attendance fk_attendance_shift; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT fk_attendance_shift FOREIGN KEY (shift_id) REFERENCES public.shifts(id) ON DELETE RESTRICT;


--
-- Name: batch_management fk_batch_management_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_management
    ADD CONSTRAINT fk_batch_management_created_by FOREIGN KEY (created_by) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: batch_management fk_batch_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_management
    ADD CONSTRAINT fk_batch_product FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: batch_management fk_batch_variant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_management
    ADD CONSTRAINT fk_batch_variant FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payroll_template_details fk_earning_deduction; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_template_details
    ADD CONSTRAINT fk_earning_deduction FOREIGN KEY (earning_deduction_id) REFERENCES public.earnings_deductions(id) ON DELETE CASCADE;


--
-- Name: employee_logs fk_employee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_logs
    ADD CONSTRAINT fk_employee FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: employee_remarks fk_employee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_remarks
    ADD CONSTRAINT fk_employee FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: employees fk_employee_designation; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employee_designation FOREIGN KEY (designation_id) REFERENCES public.designations(designation_id) ON DELETE RESTRICT;


--
-- Name: employee_documents fk_employee_document_employee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents
    ADD CONSTRAINT fk_employee_document_employee FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: employees fk_employee_payroll_template; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employee_payroll_template FOREIGN KEY (payroll_template_id) REFERENCES public.payroll_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employee_profiles fk_employee_profiles_designation; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_profiles
    ADD CONSTRAINT fk_employee_profiles_designation FOREIGN KEY (designation_id) REFERENCES public.designations(designation_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees fk_employee_shift; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employee_shift FOREIGN KEY (shift_id) REFERENCES public.shifts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees fk_employees_department; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employees_department FOREIGN KEY (department_id) REFERENCES public.departments(department_id) ON DELETE RESTRICT;


--
-- Name: employees fk_employees_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employees_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON DELETE RESTRICT;


--
-- Name: grn_header fk_grn_authorized_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_header
    ADD CONSTRAINT fk_grn_authorized_by FOREIGN KEY (authorized_by) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: grn_items fk_grn_items_grn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items
    ADD CONSTRAINT fk_grn_items_grn FOREIGN KEY (grn_id) REFERENCES public.grn_header(grn_id) ON DELETE CASCADE;


--
-- Name: grn_items fk_grn_items_measurement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items
    ADD CONSTRAINT fk_grn_items_measurement FOREIGN KEY (measurement_unit) REFERENCES public.measurements(measurement_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: grn_items fk_grn_items_po; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items
    ADD CONSTRAINT fk_grn_items_po FOREIGN KEY (po_id) REFERENCES public.po_header(po_id) ON DELETE RESTRICT;


--
-- Name: grn_items fk_grn_items_po_item; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items
    ADD CONSTRAINT fk_grn_items_po_item FOREIGN KEY (po_item_id) REFERENCES public.po_items(po_item_id) ON DELETE RESTRICT;


--
-- Name: grn_items fk_grn_items_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items
    ADD CONSTRAINT fk_grn_items_product FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE RESTRICT;


--
-- Name: grn_items fk_grn_items_variant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_items
    ADD CONSTRAINT fk_grn_items_variant FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id) ON DELETE SET NULL;


--
-- Name: grn_header fk_grn_po; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_header
    ADD CONSTRAINT fk_grn_po FOREIGN KEY (po_id) REFERENCES public.po_header(po_id) ON DELETE RESTRICT;


--
-- Name: grn_header fk_grn_received_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_header
    ADD CONSTRAINT fk_grn_received_by FOREIGN KEY (received_by) REFERENCES public.users(user_id) ON DELETE RESTRICT;


--
-- Name: grn_header fk_grn_supplier; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_header
    ADD CONSTRAINT fk_grn_supplier FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id) ON DELETE RESTRICT;


--
-- Name: waybills fk_import_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT fk_import_by FOREIGN KEY (import_by) REFERENCES public.users(user_id);


--
-- Name: job_bill_item fk_job_bill_item_job; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_bill_item
    ADD CONSTRAINT fk_job_bill_item_job FOREIGN KEY (job_id) REFERENCES public.job(id) ON DELETE CASCADE;


--
-- Name: job_bill_item fk_job_bill_item_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_bill_item
    ADD CONSTRAINT fk_job_bill_item_product FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE SET NULL;


--
-- Name: job_log fk_job_log_job; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_log
    ADD CONSTRAINT fk_job_log_job FOREIGN KEY (job_id) REFERENCES public.job(id) ON DELETE CASCADE;


--
-- Name: job_other_service fk_job_other_service_job; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_other_service
    ADD CONSTRAINT fk_job_other_service_job FOREIGN KEY (job_id) REFERENCES public.job(id) ON DELETE CASCADE;


--
-- Name: kitchen fk_kitchen_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kitchen
    ADD CONSTRAINT fk_kitchen_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON DELETE CASCADE;


--
-- Name: leaves fk_leave_employee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leaves
    ADD CONSTRAINT fk_leave_employee FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: leaves fk_leave_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leaves
    ADD CONSTRAINT fk_leave_type FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(leave_type_id) ON DELETE RESTRICT;


--
-- Name: leaves fk_leaves_designation; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leaves
    ADD CONSTRAINT fk_leaves_designation FOREIGN KEY (designation_id) REFERENCES public.designations(designation_id) ON DELETE SET NULL;


--
-- Name: products fk_measurement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_measurement FOREIGN KEY (measurement_id) REFERENCES public.measurements(measurement_id);


--
-- Name: merchants fk_merchants_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT fk_merchants_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: payroll_template_details fk_payroll_template; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_template_details
    ADD CONSTRAINT fk_payroll_template FOREIGN KEY (payroll_template_id) REFERENCES public.payroll_templates(id) ON DELETE CASCADE;


--
-- Name: paysheet_invoices fk_paysheet_detail; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_invoices
    ADD CONSTRAINT fk_paysheet_detail FOREIGN KEY (paysheet_detail_id) REFERENCES public.paysheet_details(paysheet_detail_id) ON DELETE CASCADE;


--
-- Name: paysheet_invoices fk_paysheet_invoice_account; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_invoices
    ADD CONSTRAINT fk_paysheet_invoice_account FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: paysheets fk_paysheets_payroll_template; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheets
    ADD CONSTRAINT fk_paysheets_payroll_template FOREIGN KEY (payroll_template_id) REFERENCES public.payroll_templates(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pick_from_client fk_pick_job; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pick_from_client
    ADD CONSTRAINT fk_pick_job FOREIGN KEY (job_id) REFERENCES public.job(id) ON DELETE CASCADE;


--
-- Name: po_header fk_po_authorized_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_header
    ADD CONSTRAINT fk_po_authorized_user FOREIGN KEY (authorized_by) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: po_header fk_po_generated_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_header
    ADD CONSTRAINT fk_po_generated_user FOREIGN KEY (generated_user) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: po_items fk_po_items_measurement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_items
    ADD CONSTRAINT fk_po_items_measurement FOREIGN KEY (measurement_unit) REFERENCES public.measurements(measurement_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: po_items fk_po_items_po; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_items
    ADD CONSTRAINT fk_po_items_po FOREIGN KEY (po_id) REFERENCES public.po_header(po_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: po_items fk_po_items_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_items
    ADD CONSTRAINT fk_po_items_product FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: po_items fk_po_items_variant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.po_items
    ADD CONSTRAINT fk_po_items_variant FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: prn_header fk_prn_grn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_header
    ADD CONSTRAINT fk_prn_grn FOREIGN KEY (grn_id) REFERENCES public.grn_header(grn_id) ON DELETE CASCADE;


--
-- Name: prn_items fk_prn_items_grn_item; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_items
    ADD CONSTRAINT fk_prn_items_grn_item FOREIGN KEY (grn_item_id) REFERENCES public.grn_items(grn_item_id);


--
-- Name: prn_items fk_prn_items_po_item; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_items
    ADD CONSTRAINT fk_prn_items_po_item FOREIGN KEY (po_item_id) REFERENCES public.po_items(po_item_id);


--
-- Name: prn_items fk_prn_items_prn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_items
    ADD CONSTRAINT fk_prn_items_prn FOREIGN KEY (prn_id) REFERENCES public.prn_header(prn_id) ON DELETE CASCADE;


--
-- Name: prn_header fk_prn_po; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_header
    ADD CONSTRAINT fk_prn_po FOREIGN KEY (po_id) REFERENCES public.po_header(po_id);


--
-- Name: prn_header fk_prn_supplier; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prn_header
    ADD CONSTRAINT fk_prn_supplier FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: employee_remarks fk_remark_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_remarks
    ADD CONSTRAINT fk_remark_by FOREIGN KEY (remark_by) REFERENCES public.users(user_id);


--
-- Name: restaurant_tables fk_restaurant_tables_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_tables
    ADD CONSTRAINT fk_restaurant_tables_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON DELETE CASCADE;


--
-- Name: role_list fk_role_list_portal_interface; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_list
    ADD CONSTRAINT fk_role_list_portal_interface FOREIGN KEY (portal_interface) REFERENCES public.portal_interface(interface_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_channel fk_sales_channel_merchant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_channel
    ADD CONSTRAINT fk_sales_channel_merchant FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id) ON DELETE SET NULL;


--
-- Name: stock_sheet_details fk_stock_details_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_details
    ADD CONSTRAINT fk_stock_details_product FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE RESTRICT;


--
-- Name: stock_sheet_details fk_stock_details_sheet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_details
    ADD CONSTRAINT fk_stock_details_sheet FOREIGN KEY (sheet_id) REFERENCES public.stock_sheet_header(sheet_id) ON DELETE CASCADE;


--
-- Name: stock_sheet_details fk_stock_details_variant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_details
    ADD CONSTRAINT fk_stock_details_variant FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id) ON DELETE RESTRICT;


--
-- Name: stock_sheet_header fk_stock_sheet_header_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_sheet_header
    ADD CONSTRAINT fk_stock_sheet_header_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_payments fk_supplier_payments_grn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT fk_supplier_payments_grn FOREIGN KEY (grn_id) REFERENCES public.grn_header(grn_id) ON DELETE SET NULL;


--
-- Name: supplier_payments fk_supplier_payments_po; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT fk_supplier_payments_po FOREIGN KEY (po_id) REFERENCES public.po_header(po_id) ON DELETE CASCADE;


--
-- Name: supplier_payments fk_supplier_payments_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT fk_supplier_payments_user FOREIGN KEY (by_user_id) REFERENCES public.users(user_id) ON DELETE RESTRICT;


--
-- Name: system_settings fk_system_settings_inventory_strategy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT fk_system_settings_inventory_strategy FOREIGN KEY (inventory_strategy_id) REFERENCES public.inventory_strategy(inventory_strategy_id);


--
-- Name: transactions fk_transactions_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transactions_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions fk_transactions_reference; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transactions_reference FOREIGN KEY (reference_id) REFERENCES public.transactions(transaction_id) ON DELETE SET NULL;


--
-- Name: transactions fk_transactions_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transactions_user FOREIGN KEY (by) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: account_statement fk_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_statement
    ADD CONSTRAINT fk_user FOREIGN KEY (by) REFERENCES public.users(user_id);


--
-- Name: user_backup fk_users_outlet; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_backup
    ADD CONSTRAINT fk_users_outlet FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id) ON DELETE SET NULL;


--
-- Name: increments_and_promotions increments_and_promotions_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.increments_and_promotions
    ADD CONSTRAINT increments_and_promotions_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: increments_and_promotions increments_and_promotions_new_designation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.increments_and_promotions
    ADD CONSTRAINT increments_and_promotions_new_designation_id_fkey FOREIGN KEY (new_designation_id) REFERENCES public.designations(designation_id);


--
-- Name: inventory inventory_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id);


--
-- Name: inventory inventory_outlet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_outlet_id_fkey FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id);


--
-- Name: inventory inventory_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id);


--
-- Name: invoice_details invoice_details_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_details
    ADD CONSTRAINT invoice_details_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_header(id);


--
-- Name: invoice_details invoice_details_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_details
    ADD CONSTRAINT invoice_details_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: job job_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT job_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id) ON DELETE SET NULL;


--
-- Name: order_bulk_prints order_bulk_prints_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_bulk_prints
    ADD CONSTRAINT order_bulk_prints_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: order_items order_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id);


--
-- Name: orders orders_bulk_dispatched_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_bulk_dispatched_id_fkey FOREIGN KEY (bulk_dispatched_id) REFERENCES public.bulk_dispatched_history(bulk_id) ON DELETE SET NULL;


--
-- Name: orders orders_bulk_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_bulk_id_fkey FOREIGN KEY (bulk_id) REFERENCES public.order_bulk_prints(bulk_id) ON DELETE SET NULL;


--
-- Name: orders orders_confiremed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_confiremed_by_fkey FOREIGN KEY (confiremed_by) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: orders orders_delivery_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_delivery_partner_id_fkey FOREIGN KEY (delivery_partner_id) REFERENCES public.delivery_partners(partner_id);


--
-- Name: orders orders_managed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_managed_by_fkey FOREIGN KEY (managed_by) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: orders orders_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id);


--
-- Name: orders orders_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(payment_method_id);


--
-- Name: outlets outlets_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outlets
    ADD CONSTRAINT outlets_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id);


--
-- Name: paysheet_details paysheet_details_earning_deduction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_details
    ADD CONSTRAINT paysheet_details_earning_deduction_id_fkey FOREIGN KEY (earning_deduction_id) REFERENCES public.earnings_deductions(id);


--
-- Name: paysheet_details paysheet_details_paysheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheet_details
    ADD CONSTRAINT paysheet_details_paysheet_id_fkey FOREIGN KEY (paysheet_id) REFERENCES public.paysheets(paysheet_id) ON DELETE CASCADE;


--
-- Name: paysheets paysheets_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paysheets
    ADD CONSTRAINT paysheets_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: product_brands product_brands_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_brands
    ADD CONSTRAINT product_brands_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brand(brand_id) ON DELETE CASCADE;


--
-- Name: product_brands product_brands_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_brands
    ADD CONSTRAINT product_brands_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- Name: product_category product_category_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(category_id);


--
-- Name: product_category product_category_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: product_collections product_collections_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_collections
    ADD CONSTRAINT product_collections_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.collections(collection_id);


--
-- Name: product_collections product_collections_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_collections
    ADD CONSTRAINT product_collections_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: product_media product_media_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_media
    ADD CONSTRAINT product_media_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: product_media product_media_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_media
    ADD CONSTRAINT product_media_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id);


--
-- Name: product_reviews product_reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- Name: product_tags product_tags_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: product_tags product_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(tag_id);


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: products products_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id);


--
-- Name: reorder_level reorder_level_outlet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reorder_level
    ADD CONSTRAINT reorder_level_outlet_id_fkey FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id);


--
-- Name: reorder_level_removed reorder_level_outlet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reorder_level_removed
    ADD CONSTRAINT reorder_level_outlet_id_fkey FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id);


--
-- Name: reorder_level reorder_level_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reorder_level
    ADD CONSTRAINT reorder_level_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: reorder_level_removed reorder_level_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reorder_level_removed
    ADD CONSTRAINT reorder_level_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: reorder_level reorder_level_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reorder_level
    ADD CONSTRAINT reorder_level_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id);


--
-- Name: reorder_level_removed reorder_level_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reorder_level_removed
    ADD CONSTRAINT reorder_level_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(variant_id);


--
-- Name: sales_channel sales_channel_outlet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_channel
    ADD CONSTRAINT sales_channel_outlet_id_fkey FOREIGN KEY (outlet_id) REFERENCES public.outlets(outlet_id);


--
-- Name: sales_channel sales_channel_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_channel
    ADD CONSTRAINT sales_channel_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.web_templates(id);


--
-- Name: shift_roster shift_roster_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_roster
    ADD CONSTRAINT shift_roster_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;


--
-- Name: shift_roster shift_roster_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_roster
    ADD CONSTRAINT shift_roster_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.shifts(id) ON DELETE CASCADE;


--
-- Name: tags tags_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(merchant_id);


--
-- Name: uimenudata uimenudata_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uimenudata
    ADD CONSTRAINT uimenudata_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.uimenudata(id) ON DELETE CASCADE;


--
-- Name: waybills waybills_d_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_d_partner_id_fkey FOREIGN KEY (d_partner_id) REFERENCES public.delivery_partners(partner_id);


--
-- Name: waybills waybills_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: web_page_components web_page_components_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_components
    ADD CONSTRAINT web_page_components_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.components(id) ON DELETE CASCADE;


--
-- Name: web_page_components web_page_components_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_components
    ADD CONSTRAINT web_page_components_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: web_template_sections web_template_sections_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_template_sections
    ADD CONSTRAINT web_template_sections_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.web_templates(id);


--
-- PostgreSQL database dump complete
--

\unrestrict ATxPS2Neispih5iHhgmCw5QguCfVmyuWoWQ2HtrpIA4xg0o1CxBwMxmdgzGqh6i

